/************************************************************************/
/* MUI                      The.French.DJ                 November 2002 */
/************************************************************************/

package de.intensicode.mui;

import java.awt.Color;
import java.awt.Component;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.util.EventObject;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.ListCellRenderer;



public class MUIFileLister extends MUIObject
{
    protected File iCurrentDir = null;

    protected File[] iFileList = null;

    protected MUIGroupV iLister = null;

    protected MUIScrollView iScrollView = null;

    protected MUIList iList = null;

    protected MUIGroupH iPath = null;

    protected MUITextField iPathField = null;

    protected MUIImageButton iPathSelect = null;



    public MUIFileLister()
    {
        iPathSelect = new MUIImageButton( "images/dir.gif" );
        iPathField = new MUITextField();

        iPath = new MUIGroupH();
        iPath.addChild( iPathField );
        iPath.addChild( iPathSelect );

        iList = new MUIList();
        iList.setRenderer( new FileListRenderer() );
//        iTable.setAction( iTable.ON_DOUBLE_CLICK, new DoubleClick());
//        iTable.setAction( iTable.ON_KEY_TYPED, new KeyTyped());

        iScrollView = new MUIScrollView( iList );

        iLister = new MUIGroupV();
        iLister.addChild( iScrollView );
        iLister.addChild( iPath );

        super.iJava = iLister.getJava();
        super.iDefaults = MUIPrefs.getMUIFileListerDefaults();
    }

    public MUIFileLister( File dir )
    {
        this();
        setDirectory( dir );
    }

    public MUIFileLister setDirectory( File dir )
    {
        iCurrentDir = dir;
        try
        {
            iFileList = listFiles( dir );
            iList.setData( listFiles( dir ) );
            iPathField.setText( dir.getCanonicalPath() );
        }
        catch ( IOException ioEx )
        {

        }
        return this;
    }



    public static /*inner*/ class FileListRenderer extends JLabel implements ListCellRenderer
    {
        final static ImageIcon dirIcon = new ImageIcon( "images/file.gif" );

        final static ImageIcon fileIcon = new ImageIcon( "images/dir.gif" );



        public Component getListCellRendererComponent
            ( JList list, Object value, int index, boolean isSelected, boolean cellHasFocus )
        {
            File file = ( File ) value;

            setText( file.getName() );

            if ( ( ( File ) value ).isDirectory() == true )
            {
                setIcon( fileIcon );
                if ( isSelected )
                {
                    setBackground( Color.blue );
                    setForeground( Color.white );
                }
                else
                {
                    setBackground( Color.white );
                    setForeground( Color.blue );
                }
            }
            else
            {
                setIcon( dirIcon );
                if ( isSelected )
                {
                    setBackground( Color.black );
                    setForeground( Color.white );
                }
                else
                {
                    setBackground( Color.white );
                    setForeground( Color.black );
                }
            }

            setEnabled( list.isEnabled() );
            setFont( list.getFont() );
            setOpaque( true );

            return this;
        }
    }



    private static File[] listFiles( File dir )
    {
        File[] temp = dir.listFiles();

        if ( temp == null ) return ( null );

        File[] result = new File[ temp.length + 1 ];
        result[ 0 ] = new File( ".." );

        int done = 1;

        for ( int idx = 0; idx < temp.length; idx++ )
            if ( temp[ idx ].isDirectory() == true )
                result[ done++ ] = ( temp[ idx ] );

        for ( int idx = 0; idx < temp.length; idx++ )
            if ( temp[ idx ].isDirectory() == false )
                result[ done++ ] = ( temp[ idx ] );

        return result;
    }



    protected /*inner*/ class DoubleClick implements OnActionListener
    {
        public void onAction( MUIComponent comp, MUIAction action, EventObject e )
        {
            MUIList mui = ( MUIList ) comp;
            JList list = ( JList ) mui.getJava();

            File selected = ( File ) list.getSelectedValue();
            if ( selected == null )
            {
                return;
            }

            if ( selected.isDirectory() == false )
            {
                return;
            }

            if ( iCurrentDir != null )
            {
                selected = new File( iCurrentDir, selected.getName() );
            }
            setDirectory( selected );
        }
    }



    protected /*inner*/ class KeyTyped implements OnActionListener
    {
        public void onAction( MUIComponent aComponent, MUIAction aAction, EventObject aEvent )
        {
            MUIList mui = ( MUIList ) aComponent;
            JList list = ( JList ) mui.getJava();
            File selected = ( File ) list.getSelectedValue();

            KeyEvent event = ( KeyEvent ) aEvent;
            if ( event.getKeyChar() == 8 )
            {
                selected = new File( ".." );
            }
            else if ( event.getKeyChar() != 10 )
            {
                selected = preselect( list, event.getKeyChar() );
                if ( selected != null ) list.setSelectedValue( selected, true );
                return;
            }

            if ( selected == null )
            {
                return;
            }
            if ( selected.isDirectory() == false )
            {
                return;
            }
            if ( iCurrentDir != null )
            {
                selected = new File( iCurrentDir, selected.getName() );
            }

            setDirectory( selected );
            lastPrefixChange = 0;
        }



        // DO NOT LOOK BELOW HERE. IT'S CRAP..

        private long lastPrefixChange = 0;

        private StringBuffer currentPrefix = new StringBuffer();

        private File preselect( JList list, char nextChar )
        {
            long now = System.currentTimeMillis();
            if ( now - lastPrefixChange > 333 )
            {
                currentPrefix = new StringBuffer();
            }

            currentPrefix.append( nextChar );
            lastPrefixChange = now;

            int startIdx = Math.max( list.getSelectedIndex(), 0 );

            File result = lookup( list, startIdx, iFileList.length );
            return result;
        }

        private File lookup( JList list, int startIdx, int length )
        {
            for ( int idx = startIdx; idx < startIdx + length; idx++ )
            {
                int nextIdx = idx % iFileList.length;

                String name = iFileList[ nextIdx ].getName().toLowerCase();

                if ( name.startsWith( currentPrefix.toString() ) )
                {
                    if ( iFileList[ nextIdx ].equals( list.getSelectedValue() ) )
                    {
                        int sndNextIdx = ( nextIdx + 1 ) % iFileList.length;

                        File result = lookup( list, sndNextIdx, length - 1 );
                        if ( result != null ) return ( result );
                    }
                    return iFileList[ nextIdx ];
                }
            }
            return null;
        }
    }
}
