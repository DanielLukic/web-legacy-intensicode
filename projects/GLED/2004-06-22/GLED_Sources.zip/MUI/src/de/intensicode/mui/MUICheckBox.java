/************************************************************************/
/* MUI                 www.intensicode.de                 Dezember 2003 */
/************************************************************************/

package de.intensicode.mui;

import javax.swing.JCheckBox;



public class MUICheckBox extends MUIObject
{
    private JCheckBox iCheckBox;



    public MUICheckBox( String name )
    {
        iCheckBox = new JCheckBox( name );
        iCheckBox.addActionListener( this );

        init( iCheckBox, MUIPrefs.getMUICheckBoxDefaults() );
    }

    public boolean isSelected()
    {
        return iCheckBox.isSelected();
    }

    public MUIComponent setSelected( boolean aSelectedFlag )
    {
        iCheckBox.setSelected( aSelectedFlag );
        return this;
    }

    public void setEnabled( boolean aEnabledFlag )
    {
        iJava.setEnabled( aEnabledFlag );
    }
}
