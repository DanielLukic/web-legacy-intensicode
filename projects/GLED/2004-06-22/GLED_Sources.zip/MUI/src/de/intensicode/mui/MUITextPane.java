/************************************************************************/
/* MUI                      The.French.DJ                    Maerz 2003 */
/************************************************************************/

package de.intensicode.mui;

import de.intensicode.core.ResourceManager;

import java.io.IOException;
import java.net.URL;

import javax.swing.JTextPane;
import javax.swing.event.HyperlinkListener;
import javax.swing.event.HyperlinkEvent;



/**
 * Stellt eine Textanzeigekomponente bereit.
 */
public class MUITextPane extends MUIObject implements HyperlinkListener {

    protected JTextPane textPane = null;



    public MUITextPane( String ressourceName ) throws IOException {

        this( ResourceManager.getResource( ressourceName ) );

    } // MUITextPane( String )



    public MUITextPane( URL url ) throws IOException {

        textPane = new JTextPane();
        textPane.setEditable( false );
        textPane.setPage( url );

        init( textPane, MUIPrefs.getMUITextPaneDefaults() );

        textPane.addHyperlinkListener( this );

    } // MUITextPane( URL )



    public void hyperlinkUpdate( HyperlinkEvent event ) {

        HyperlinkEvent.EventType type = event.getEventType();

        if ( type.equals( type.ACTIVATED ) ) {

            try {

                textPane.setPage( event.getURL() );

            } catch ( IOException e ) {

                textPane.setText( "Unavailable. Failed to load document" );
            }
        }

    } // void hyperlinkUpdate( HyperlinkEvent )

} // class MUITextPane
