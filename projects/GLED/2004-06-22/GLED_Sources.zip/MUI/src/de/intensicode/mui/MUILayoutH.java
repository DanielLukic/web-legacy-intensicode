/************************************************************************/
/* MUI                  www.intensicode.de                November 2002 */
/************************************************************************/

package de.intensicode.mui;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.Insets;
import java.awt.Point;



public class MUILayoutH extends MUILayout
{
    public MUILayoutH( MUIConstraints defaults )
    {
        super( defaults );
    }

    // From MUILayout

    /**
     * Aktualisiert die Position <code>pos</code> unter Betrachtung der
     * Groesse der gerade auszulegenden Komponente.
     */
    protected void prepareLayout( Point pos, Dimension size )
    {
        pos.x += size.getWidth();
        pos.x += iDefaults.iSpacing.getWidth();
    }

    protected StretchData determineStretchDataH( Point usedSpace, Container parent )
    {
        StretchData result = new StretchData();
        result.weightDeltaH = 1.0;
        result.weightOffsetH = 1.0;
        result.askWidth = false;
        return result;
    }

    protected StretchData determineStretchDataV( Point usedSpace, Container parent )
    {
        StretchData result = new StretchData();
        result.weightDeltaV = 1.0;
        result.weightOffsetV = 0.0;
        result.askHeight = true;
        return result;
    }

    /**
     * Aktualisiert die PreferredSize unter Betrachtung einer horizontalen
     * Auslegung der Komponenten.
     */
    protected void calculateLayoutSize( CalculatedSize pref, Dimension size, Insets insets )
    {
        pref.width += size.getWidth();
        pref.height = Math.max( pref.height, insets.top + size.getHeight() );
        pref.width += iDefaults.iSpacing.getWidth();
    }
}
