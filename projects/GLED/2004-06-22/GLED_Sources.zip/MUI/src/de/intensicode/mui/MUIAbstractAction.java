/************************************************************************/
/* MUI                  www.intensicode.de                November 2002 */
/************************************************************************/

package de.intensicode.mui;

import java.util.ArrayList;
import java.util.EventObject;



public class MUIAbstractAction implements MUIAction
{
    protected ArrayList iReceivers = new ArrayList();

    protected MUIObject iTarget;



    protected MUIAbstractAction( MUIObject aTarget )
    {
        iTarget = aTarget;
    }



    // From MUIAction

    public void install( OnActionListener aReceiver )
    {
        synchronized ( iReceivers )
        {
            iReceivers.add( aReceiver );
        }
    }

    // Implementation

    protected void broadcast( EventObject aEvent )
    {
        synchronized ( iReceivers )
        {
            for ( int idx = 0; idx < iReceivers.size(); idx++ )
            {
                OnActionListener receiver = ( OnActionListener ) iReceivers.get( idx );
                receiver.onAction( iTarget, this, aEvent );
            }
        }
    }
}
