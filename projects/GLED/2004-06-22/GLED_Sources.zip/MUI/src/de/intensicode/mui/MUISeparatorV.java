/************************************************************************/
/* MUI                      The.French.DJ                 November 2002 */
/************************************************************************/

package de.intensicode.mui;

import javax.swing.JSeparator;
import javax.swing.SwingConstants;

/**
 *
 */
public class MUISeparatorV extends MUIObject {

  public MUISeparatorV() {

    super.iJava = new JSeparator(SwingConstants.VERTICAL);
    super.iDefaults = MUIPrefs.getMUISeparatorVDefaults();

  } // MUISeparatorV(String)

} // class MUISeparatorV
