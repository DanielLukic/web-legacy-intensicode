/************************************************************************/
/* MUI                      The.French.DJ                 November 2002 */
/************************************************************************/

package de.intensicode.mui;

import javax.swing.JPanel;



/**
 *
 */
public class MUISpacerV extends MUIObject {

    public MUISpacerV() {

        super.iJava = new JPanel();
        super.iDefaults = MUIPrefs.getMUISpacerDefaults();
        super.iDefaults.iWeightV = 1.0;

        init( iJava, iDefaults );

    } // MUISpacerV(String)

} // class MUISpacerV
