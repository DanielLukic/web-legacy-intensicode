/************************************************************************/
/* MUI                   www.intensicode.de               November 2002 */
/************************************************************************/

package de.intensicode.mui;

import java.awt.Dimension;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.security.AccessControlException;

import javax.swing.JFrame;



public class MUIFrame extends JFrame
{
    public MUIFrame( String title )
    {
        super( title );

        try
        {
            setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
        }
        catch ( AccessControlException acEx )
        {
            // Assume applet context.
            setDefaultCloseOperation( JFrame.DISPOSE_ON_CLOSE );
        }
        getContentPane().setBackground( MUIPrefs.getBackgroundColor() );
    }

    public void addChild( MUIComponent comp )
    {
        getContentPane().add( comp.getJava() );
        pack();
    }

    public void setMenu( MUIMenu menu )
    {
        setJMenuBar( menu.getJavaMenu() );
    }

    public void centerFrame()
    {
        Dimension frame = getSize();
        Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();

        Point offset = new Point();
        offset.x = ( screen.width - frame.width ) / 2;
        offset.y = ( screen.height - frame.height ) / 2;

        Rectangle bounds = new Rectangle( offset, frame );
        setBounds( bounds );
    }

    public void recenterWithSize( int width, int height )
    {
        Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
        int xOffset = ( screen.width - width ) / 2;
        int yOffset = ( screen.height - height ) / 2;
        setBounds( xOffset, yOffset, width, height );
    }

    public void recenterWithPercentage( int aPercentage )
    {
        if ( aPercentage < 25 || aPercentage > 100 )
        {
            throw new IllegalArgumentException( "Invalid percentage: " + aPercentage );
        }

        Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
        int width = screen.width * aPercentage / 100;
        int height = screen.height * aPercentage / 100;

        int x = ( screen.width - width ) / 2;
        int y = ( screen.height - height ) / 2;

        setBounds( x, y, width, height );
    }
}
