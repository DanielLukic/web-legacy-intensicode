/************************************************************************/
/* MUI                      The.French.DJ                 November 2002 */
/************************************************************************/

package de.intensicode.mui;

import de.intensicode.core.config.Configuration;

import java.awt.Graphics;
import java.awt.Font;

import javax.swing.JLabel;
import javax.swing.border.EmptyBorder;



/**
 * Einfaches Label zum anzeigen von Texten.
 */
public class MUILabel extends MUIObject {

    /**
     * Das bereitgestellte JLabel.
     */
    private JLabel label = null;



    /**
     * Erzeugt ein neues Label zur Darstellung des angegebenen Texts.
     */
    public MUILabel( String name ) {

        label = new JLabel( name );

        init();

    } // MUILabel(String)



    /**
     * Erzeugt ein Label, welches den dargestellten Text aus der
     * angegebenen Konfiguration und dem angegebenen Schluessel bestimmt.
     */
    public MUILabel( String key, Configuration config ) {

        label = new AutoUpdateLabel( key, config );

        init();

    } // MUILabel(String)



    /**
     * Initialisiert die MUI-Komponente.
     */
    private void init() {

        Font font = label.getFont();
        Font plain = new Font( font.getName(), Font.PLAIN, font.getSize() );
        label.setFont( plain );

        super.iJava = label;
        super.iDefaults = MUIPrefs.getMUILabelDefaults();

        label.setBorder( new EmptyBorder( iDefaults.iInsets ) );

    } // void init()



    /**
     * Legt einen neuen darzustellenden Text fest.
     */
    public void setText( String text ) {

        label.setText( text );

    } // void setText( String )



    /**
     * Hilfsklasse fuer ein sich automatisch aktualisierendes Label. Das
     * Label prueft vor jedem Zeichnen ob sich der Eintrag in der
     * Konfiguration geaendert hat.
     */
    class AutoUpdateLabel extends JLabel {

        /**
         * Der Key des aus der Konfiguration zu lesenden Wertes.
         */
        private String key = null;

        /**
         * Die auszulesende Konfiguration.
         */
        private Configuration config = null;



        /**
         * Initialisiert das Label mit der angegebenen Konfiguration.
         */
        public AutoUpdateLabel( String key, Configuration config ) {

            this.key = key;
            this.config = config;

            String entry = config.getProperty( key );
            if ( entry == null ) entry = "";

            super.setText( entry );

        } // AutoUpdateLabel( String, Configuration )



        public void paint( Graphics g ) {

            String entry = config.getProperty( key );
            if ( entry == null ) entry = "";

            String text = getText();
            if ( text == null ) text = "";

            if ( text.equals( entry ) == false ) super.setText( entry );

            super.paint( g );

        } // void paintInto( Graphics )

    } // inner class AutoUpdateLabel

} // class MUILabel
