/************************************************************************/
/* MUI                  www.intensicode.de                November 2002 */
/************************************************************************/

package de.intensicode.mui;

import java.awt.*;
import java.util.ArrayList;
import java.util.HashMap;



public abstract class MUILayout implements LayoutManager2
{
    /**
     * Default-Einstellungen fuer das Layout. Diese gelten wann immer keine
     * Constraints oder Settings gegeben sind.
     */
    protected MUIConstraints iDefaults = null;

    /**
     * Enthaelt fuer alle bekannten Komponenten die zugehoerigen Constraints.
     * Diese ueberschreiben die gesetzten {@link #iDefaults iDefaults}.
     */
    protected HashMap iKnownConstraints = new HashMap();

    /**
     * Enthaelt absolute Vorgaben fuer das Layout. Diese Einstellungen
     * ueberschreiben die {@link #iDefaults iDefaults} <strong>und</strong> die
     * {@link #iKnownConstraints iKnownConstraints} der enthaltenen Komponenten.
     */
    protected ArrayList iSettings = new ArrayList();

    private Dimension iInvisibleSize = new Dimension( 0, 0 );



    protected MUILayout( MUIConstraints aDefaults )
    {
        iDefaults = aDefaults;
    }

    public double getWeightH( Component aComponent )
    {
        if ( aComponent.isVisible() == false )
        {
            return 0;
        }
        try
        {
            MUIComponent mui = ( MUIComponent ) aComponent;
            return mui.getWeightH();
        }
        catch ( ClassCastException ccEx )
        {
            MUIConstraints constraints = ( MUIConstraints ) this.iKnownConstraints.get( aComponent );
            if ( constraints == null )
            {
                return ( 0 );
            }
            return constraints.iWeightH;
        }
    }

    public double getWeightV( Component aComponent )
    {
        if ( aComponent.isVisible() == false )
        {
            return 0;
        }
        try
        {
            MUIComponent mui = ( MUIComponent ) aComponent;
            return mui.getWeightV();
        }
        catch ( ClassCastException ccEx )
        {
            MUIConstraints constraints = ( MUIConstraints ) this.iKnownConstraints.get( aComponent );
            if ( constraints == null )
            {
                return 0;
            }
            return constraints.iWeightV;
        }
    }

    /**
     * Liefert die MUIConstraints des Layout-Managers selbst zurueck. Dies
     * sind im Allgemeinen auch die MUIConstraints der Grupper der dieser
     * LayoutManager angehoert.
     */
    public MUIConstraints getDefaults()
    {
        return iDefaults;
    }

    public MUIConstraints getConstraints( Component comp )
    {
        MUIConstraints result = ( MUIConstraints ) iKnownConstraints.get( comp );
        if ( result == null )
        {
            return new MUIConstraints();
        }
        return result;
    }

    // From LayoutManager2

    public void addLayoutComponent( Component aComponent, Object aConstraints )
    {
        if ( aConstraints != null )
        {
            addKnownConstraint( aComponent, aConstraints );
        }
    }

    public void addLayoutComponent( String aName, Component aComponent )
    {
        addKnownConstraint( aComponent, iDefaults );
    }

    public void removeLayoutComponent( Component aComponent )
    {
        iKnownConstraints.remove( aComponent );
    }

    public float getLayoutAlignmentX( Container aTarget )
    {
        return 0;
    }

    public float getLayoutAlignmentY( Container aTarget )
    {
        return 0;
    }

    public void invalidateLayout( Container aTarget )
    {
        // We have no state. No need to invalidate!
    }

    public Dimension maximumLayoutSize( Container aTarget )
    {
        return aTarget.getMaximumSize();
    }

    public void layoutContainer( Container aContainer )
    {
        Rectangle data = prepareLayout( aContainer );
        adjustSizes( data.getSize(), aContainer );
        stretchToFit( data.getLocation(), aContainer );
        spaceToFit( data.getLocation(), aContainer );
    }

    /**
     * Calculates the minimum size dimensions for the specified panel given
     * the components in the specified parent container.
     */
    public Dimension minimumLayoutSize( Container parent )
    {
        Insets insets = determineInsets( parent );
        CalculatedSize min = new CalculatedSize( insets.left, insets.top );

        Component[] components = parent.getComponents();
        for ( int idx = 0; idx < components.length; idx++ )
        {
            Dimension size = components[ idx ].getMinimumSize();
            calculateLayoutSize( min, size, insets );
        }

        min.width += insets.right;
        min.height += insets.bottom;
        return min.getDimension();
    }

    /**
     * Calculates the preferred size dimensions for the specified panel given
     * the components in the specified parent container.
     */
    public Dimension preferredLayoutSize( Container parent )
    {
        Insets insets = determineInsets( parent );
        CalculatedSize pref = new CalculatedSize( insets.left, insets.top );

        Component[] components = parent.getComponents();
        for ( int idx = 0; idx < components.length; idx++ )
        {
            Dimension size = components[ idx ].getPreferredSize();
            calculateLayoutSize( pref, size, insets );
        }

        pref.width += insets.right;
        pref.height += insets.bottom;
        return pref.getDimension();
    }

    // Protected Interface

    /**
     * Muss von Unterklassen implementiert werden und wird fuer die
     * Durchfuehrung des Layoutings fuer jede enthaltene Komponente
     * nacheinander aufgerufen. Die Unterklasse muss dabei <code>pos</code>
     * entsprechend fuer jede Komponente aktualisieren.
     */
    protected abstract void prepareLayout( Point aPosition, Dimension aSize );

    protected abstract StretchData determineStretchDataH( Point usedSpace, Container parent );

    protected abstract StretchData determineStretchDataV( Point usedSpace, Container parent );

    /**
     * Muss von Unterklassen implementiert werden und wird fuer die
     * Bestimmung der PreferredSize fuer jede enthaltene Komponente
     * nacheinander aufgerufen. Die Unterklasse muss dabei <code>pref</code>
     * entsprechend fuer jede Komponente aktualisieren.
     */
    protected abstract void calculateLayoutSize( CalculatedSize pref, Dimension size, Insets insets );

    /**
     * Bestimmt die Insets des zu bearbeitenden Containers und beachtet dabei
     * die zusaetzlichen Insets aus den {@link #iDefaults iDefaults}.
     */
    protected Insets determineInsets( Container parent )
    {
        Insets result = parent.getInsets();
        result.left += iDefaults.iInsets.left;
        result.top += iDefaults.iInsets.top;
        result.right += iDefaults.iInsets.right;
        result.bottom += iDefaults.iInsets.bottom;
        return result;
    }

    // Implementation

    /**
     * Interne Methode zum initialen Auslegen der Komponenten - ohne
     * Beachtung der Constraints und Settings.
     *
     * @return Die jeweils maximale aufgetretene Breite und Hoehe der
     *         enthaltenen Komponente.
     */
    private Rectangle prepareLayout( Container aParent )
    {
        Insets insets = determineInsets( aParent );

        int maxWidth = 0;
        int maxHeight = 0;

        Point pos = new Point( insets.left, insets.top );

        Component[] components = aParent.getComponents();

        for ( int idx = 0; idx < components.length; idx++ )
        {
            Component comp = components[ idx ];
            Dimension size = getComponentSize( comp );

            int width = ( int ) size.getWidth();
            int height = ( int ) size.getHeight();
            comp.setBounds( pos.x, pos.y, width, height );

            prepareLayout( pos, size );

            maxWidth = Math.max( maxWidth, width );
            maxHeight = Math.max( maxHeight, height );
        }

        pos.x += insets.right;
        pos.y += insets.bottom;

        Dimension size = new Dimension( maxWidth, maxHeight );
        return new Rectangle( pos, size );
    }

    /**
     * Liefert die fuer eine Komponente sinnvollerweise bereitzustellende
     * Groesse. Dabei handelt es sich im Idealfall um die minimale Groesse
     * und nur wenn diese nicht gesetzt ist um die gewuenschte Groesse.
     */
    private Dimension getComponentSize( Component aComponent )
    {
        if ( aComponent.isVisible() == false )
        {
            return iInvisibleSize;
        }
        Dimension min = aComponent.getMinimumSize();
        if ( min != null )
        {
            return min;
        }
        return aComponent.getPreferredSize();
    }

    /**
     * Passt die Groesse der im Container enthaltenen Komponenten aneinander
     * an - falls dies in den Constraints so definiert ist.
     */
    private void adjustSizes( Dimension aSize, Container aParent )
    {
        Component[] components = aParent.getComponents();

        if ( iDefaults.iSameSizeH == true )
        {
            for ( int idx = 0; idx < components.length; idx++ )
            {
                Component comp = components[ idx ];
                Rectangle bounds = comp.getBounds();
                if ( comp.isVisible() )
                {
                    bounds.width = ( int ) Math.round( aSize.getWidth() );
                }
                else
                {
                    bounds.width = bounds.height = 0;
                }
                comp.setBounds( bounds );
            }
        }
        if ( iDefaults.iSameSizeV == true )
        {
            for ( int idx = 0; idx < components.length; idx++ )
            {
                Component comp = components[ idx ];
                Rectangle bounds = comp.getBounds();
                if ( comp.isVisible() )
                {
                    bounds.height = ( int ) Math.round( aSize.getHeight() );
                }
                else
                {
                    bounds.width = bounds.height = 0;
                }
                comp.setBounds( bounds );
            }
        }
    }

    /**
     * Streckt alle Komponenten die entsprechend markiert sind:
     * {@link MUIConstraints#iStretchToFitH iStretchToFitH} und
     * {@link MUIConstraints#iStretchToFitV iStretchToFitV}.
     */
    private void stretchToFit( Point aUsedSpace, Container aParent )
    {
        Insets insets = determineInsets( aParent );

        Component[] components = aParent.getComponents();

        if ( iDefaults.iStretchToFitH == true && components.length > 0 )
        {
            double delta = aParent.getWidth() - aUsedSpace.x;
            if ( delta > 0 )
            {
                StretchData stretch = determineStretchDataH( aUsedSpace, aParent );

                int offset = 0;
                double weightFull = getWeightH( aParent );
                if ( weightFull > 0 )
                {
                    for ( int idx = 0; idx < components.length; idx++ )
                    {
                        Component comp = components[ idx ];

                        double weight = getWeightH( comp ) / weightFull;

                        Rectangle bounds = comp.getBounds();
                        bounds.x += offset;
                        if ( stretch.askWidth == false )
                        {
                            bounds.width += delta * weight;
                        }
                        else
                        {
                            int xDelta = aParent.getWidth() - bounds.width - insets.left - insets.right;
                            if ( xDelta <= 0 ) continue;
                            bounds.width += xDelta * stretch.weightDeltaH;
                        }
                        comp.setBounds( bounds );

                        offset += delta * weight * stretch.weightOffsetH;
                    }
                } // if stretch is possible
            } // if room to stretch
        }

        if ( iDefaults.iStretchToFitV == true && components.length > 0 )
        {
            double delta = aParent.getHeight() - aUsedSpace.y;
            if ( delta > 0 )
            {
                StretchData stretch = determineStretchDataV( aUsedSpace, aParent );

                int offset = 0;
                double weightFull = getWeightV( aParent );
                if ( weightFull > 0 )
                {
                    for ( int idx = 0; idx < components.length; idx++ )
                    {
                        Component comp = components[ idx ];

                        double weight = getWeightV( comp ) / weightFull;

                        Rectangle bounds = comp.getBounds();
                        bounds.y += offset;
                        if ( stretch.askHeight == false )
                        {
                            bounds.height += delta * weight;
                        }
                        else
                        {
                            int yDelta = aParent.getHeight() - bounds.height - insets.top - insets.bottom;
                            if ( yDelta <= 0 ) continue;
                            bounds.height += yDelta * stretch.weightDeltaV;
                        }
                        comp.setBounds( bounds );

                        offset += delta * weight * stretch.weightOffsetV;
                    }
                } // if stretch is possible
            } // if room to stretch
        }
    }

    /**
     * Zentriert alle Komponenten die entsprechend markiert sind:
     * {@link MUIConstraints#iSpaceToFitH iSpaceToFitH} und
     * {@link MUIConstraints#iSpaceToFitV iSpaceToFitV}.
     */
    private void spaceToFit( Point aUsedSpace, Container aParent )
    {
        Component[] components = aParent.getComponents();

        if ( iDefaults.iSpaceToFitH == true && components.length > 0 )
        {
            double delta = aParent.getWidth() - aUsedSpace.x;
            if ( delta > 0 )
            {
                StretchData stretch = determineStretchDataH( aUsedSpace, aParent );

                int offset = 0;
                int deltaOffset = ( int ) ( delta / components.length * stretch.weightOffsetH );
                for ( int idx = 0; idx < components.length; idx++ )
                {
                    Component comp = components[ idx ];
                    Rectangle bounds = comp.getBounds();
                    bounds.x += offset;
                    bounds.x += deltaOffset / 2;
                    comp.setBounds( bounds );
                    offset += deltaOffset;
                }
            }
        }

        if ( iDefaults.iSpaceToFitV == true && components.length > 0 )
        {
            double delta = aParent.getHeight() - aUsedSpace.y;
            if ( delta > 0 )
            {
                StretchData stretch = determineStretchDataV( aUsedSpace, aParent );

                int offset = 0;
                int deltaOffset = ( int ) ( delta / components.length * stretch.weightOffsetV );
                for ( int idx = 0; idx < components.length; idx++ )
                {
                    Component comp = components[ idx ];
                    Rectangle bounds = comp.getBounds();
                    bounds.y += offset;
                    bounds.y += deltaOffset / 2;
                    comp.setBounds( bounds );
                    offset += deltaOffset;
                }
            }
        }
    }

    private void addKnownConstraint( Component comp, Object constraints )
    {
        iKnownConstraints.put( comp, constraints );
    }



    /**
     * Hilfklasse fuer die Berechnung der PreferredSize eines Containers.
     */
    protected /*inner*/ class CalculatedSize
    {
        public double width;

        public double height;



        public CalculatedSize( double aWidth, double aHeight )
        {
            this.width = aWidth;
            this.height = aHeight;
        }

        public Dimension getDimension()
        {
            Dimension result = new Dimension();
            result.setSize( width, height );
            return result;
        }
    }



    protected /*inner*/ class StretchData
    {
        protected double weightDeltaH = 0.0;

        protected double weightDeltaV = 0.0;

        protected double weightOffsetH = 0.0;

        protected double weightOffsetV = 0.0;

        protected boolean askWidth = false;

        protected boolean askHeight = false;



        // From Object

        public String toString()
        {
            StringBuffer result = new StringBuffer();
            result.append( getClass().getName() );
            result.append( " (weightDeltaH=" + weightDeltaH );
            result.append( ", weightDeltaV=" + weightDeltaV );
            result.append( ", weightOffsetH=" + weightOffsetH );
            result.append( ", weightOffsetV=" + weightOffsetV );
            result.append( ", askWidth=" + askWidth );
            result.append( ", askHeight=" + askHeight );
            result.append( ")" );
            return result.toString();
        }
    }
}
