/************************************************************************/
/* MUI                    www.intensicode.de              November 2002 */
/************************************************************************/

package de.intensicode.mui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Insets;



public class MUIPrefs
{
    private static Color iBackgroundColor = new Color( 222, 222, 222 );

    private static Color iTextBackgroundColor = new Color( 255, 255, 255 );

    private static Color iSelectedBackgroundColor = new Color( 200, 200, 200 );



    public static Color getBackgroundColor()
    {
        return iBackgroundColor;
    }

    public static Color getTextBackgroundColor()
    {
        return iTextBackgroundColor;
    }

    public static Color getSelectedBackgroundColor()
    {
        return iSelectedBackgroundColor;
    }

    public static MUIConstraints getMUIMenuDefaults()
    {
        MUIConstraints defaults = new MUIConstraints();
        defaults.iSpacing = new Dimension( 2, 1 );
        defaults.iWeightH = 1.0;
        defaults.iWeightV = 0.0;
        defaults.iStretchToFitH = true;
        defaults.iStretchToFitV = false;
        return defaults;
    }

    public static MUIConstraints getMUITabsDefaults()
    {
        MUIConstraints defaults = new MUIConstraints();
        defaults.iSpacing = new Dimension( 2, 1 );
        defaults.iWeightH = 0.10;
        defaults.iWeightV = 0.10;
        defaults.iStretchToFitH = true;
        defaults.iStretchToFitV = true;
        return defaults;
    }

    public static MUIConstraints getMUICheckBoxDefaults()
    {
        MUIConstraints defaults = new MUIConstraints();
        return defaults;
    }

    public static MUIConstraints getMUISubMenuDefaults()
    {
        MUIConstraints defaults = new MUIConstraints();
        return defaults;
    }

    public static MUIConstraints getMUIMenuEntryDefaults()
    {
        MUIConstraints defaults = new MUIConstraints();
        return defaults;
    }

    public static MUIConstraints getMUIMenuSeparatorDefaults()
    {
        MUIConstraints defaults = new MUIConstraints();
        return defaults;
    }

    public static MUIConstraints getMUILabelDefaults()
    {
        MUIConstraints defaults = new MUIConstraints();
        return defaults;
    }

    public static MUIConstraints getMUITextFieldDefaults()
    {
        MUIConstraints defaults = new MUIConstraints();
        defaults.iWeightH = 1.0;
        defaults.iStretchToFitH = true;
        return defaults;
    }

    public static MUIConstraints getMUITextAreaDefaults()
    {
        MUIConstraints defaults = new MUIConstraints();
        defaults.iWeightH = 1.0;
        defaults.iWeightV = 1.0;
        defaults.iStretchToFitH = true;
        defaults.iStretchToFitV = true;
        return defaults;
    }

    public static MUIConstraints getMUIImageButtonDefaults()
    {
        MUIConstraints defaults = new MUIConstraints();
        defaults.iStretchToFitH = true;
        return defaults;
    }

    public static MUIConstraints getMUIComboBoxDefaults()
    {
        MUIConstraints defaults = new MUIConstraints();
        defaults.iStretchToFitH = true;
        return defaults;
    }

    public static MUIConstraints getMUIButtonDefaults()
    {
        MUIConstraints defaults = new MUIConstraints();
        defaults.iStretchToFitH = true;
        return defaults;
    }

    public static MUIConstraints getMUIRadioButtonDefaults()
    {
        MUIConstraints defaults = new MUIConstraints();
        defaults.iInsets = new Insets( 2, 4, 2, 4 );
        defaults.iStretchToFitH = true;
        return defaults;
    }

    public static MUIConstraints getMUISliderDefaults()
    {
        MUIConstraints defaults = new MUIConstraints();
        defaults.iStretchToFitH = true;
        defaults.iWeightH = 0.25;
        return defaults;
    }

    public static MUIConstraints getMUIProgressDefaults()
    {
        MUIConstraints defaults = new MUIConstraints();
        defaults.iStretchToFitH = true;
        defaults.iStretchToFitV = false;
        defaults.iSpaceToFitV = true;
        defaults.iWeightH = 1;
        defaults.iWeightV = 0;
        return defaults;
    }

    public static MUIConstraints getMUISeparatorHDefaults()
    {
        MUIConstraints defaults = new MUIConstraints();
        defaults.iInsets = new Insets( 6, 12, 6, 12 );
        defaults.iSpacing = new Dimension( 0, 0 );
        defaults.iWeightH = 0;
        defaults.iWeightV = 0;
        defaults.iStretchToFitH = true;
        defaults.iStretchToFitV = false;
        return defaults;
    }

    public static MUIConstraints getMUISeparatorVDefaults()
    {
        MUIConstraints defaults = new MUIConstraints();
        defaults.iInsets = new Insets( 6, 12, 6, 12 );
        defaults.iSpacing = new Dimension( 0, 0 );
        defaults.iWeightH = 0;
        defaults.iWeightV = 0;
        defaults.iStretchToFitH = false;
        defaults.iStretchToFitV = true;
        return defaults;
    }

    public static MUIConstraints getMUISpacerDefaults()
    {
        MUIConstraints defaults = new MUIConstraints();
        defaults.iInsets = new Insets( 0, 0, 0, 0 );
        defaults.iSpacing = new Dimension( 0, 0 );
        defaults.iWeightH = 0;
        defaults.iWeightV = 0;
        defaults.iStretchToFitH = true;
        defaults.iStretchToFitV = true;
        return defaults;
    }

    public static MUIConstraints getMUIListDefaults()
    {
        MUIConstraints defaults = new MUIConstraints();
        defaults.iInsets = new Insets( 3, 6, 3, 6 );
        defaults.iSpacing = new Dimension( 4, 2 );
        defaults.iWeightH = 1.0;
        defaults.iWeightV = 1.0;
        defaults.iStretchToFitH = true;
        defaults.iStretchToFitV = true;
        return defaults;
    }

    public static MUIConstraints getMUIGroupDefaults()
    {
        MUIConstraints defaults = new MUIConstraints();
        defaults.iSpacing = new Dimension( 2, 1 );
        defaults.iWeightH = 1.0;
        defaults.iWeightV = 1.0;
        defaults.iStretchToFitH = true;
        defaults.iStretchToFitV = true;
        return defaults;
    }

    public static MUIConstraints getMUIGroupHDefaults()
    {
        MUIConstraints defaults = getMUIGroupDefaults();
        defaults.iSameSizeV = true;
        return defaults;
    }

    public static MUIConstraints getMUIGroupVDefaults()
    {
        MUIConstraints defaults = getMUIGroupDefaults();
        defaults.iSameSizeH = true;
        return defaults;
    }

    public static MUIConstraints getMUIToolbarDefaults()
    {
        MUIConstraints defaults = new MUIConstraints();
        defaults.iInsets = new Insets( 1, 2, 1, 2 );
        defaults.iSpacing = new Dimension( 2, 1 );
        defaults.iWeightH = 0.0;
        defaults.iWeightV = 0.0;
        defaults.iStretchToFitH = false;
        defaults.iStretchToFitV = false;
        return defaults;
    }

    public static MUIConstraints getMUIToolbarHDefaults()
    {
        MUIConstraints defaults = getMUIToolbarDefaults();
        defaults.iWeightH = 1.0;
        defaults.iSameSizeV = true;
        defaults.iStretchToFitH = true;
        return defaults;
    }

    public static MUIConstraints getMUIToolbarVDefaults()
    {
        MUIConstraints defaults = getMUIToolbarDefaults();
        defaults.iWeightV = 1.0;
        defaults.iSameSizeH = true;
        defaults.iStretchToFitV = true;
        return defaults;
    }

    public static MUIConstraints getMUIScrollViewDefaults()
    {
        MUIConstraints defaults = new MUIConstraints();
        defaults.iInsets = new Insets( 0, 0, 0, 0 );
        defaults.iSpacing = new Dimension( 0, 0 );
        defaults.iWeightH = 1.0;
        defaults.iWeightV = 1.0;
        defaults.iStretchToFitH = true;
        defaults.iStretchToFitV = true;
        return defaults;
    }

    public static MUIConstraints getMUIImageViewDefaults()
    {
        MUIConstraints defaults = new MUIConstraints();
        defaults.iInsets = new Insets( 3, 6, 3, 6 );
        defaults.iSpacing = new Dimension( 4, 2 );
        defaults.iWeightH = 1.0;
        defaults.iWeightV = 1.0;
        defaults.iStretchToFitH = true;
        defaults.iStretchToFitV = true;
        return defaults;
    }

    public static MUIConstraints getCanvasDefaults()
    {
        MUIConstraints defaults = new MUIConstraints();
        defaults.iInsets = new Insets( 3, 6, 3, 6 );
        defaults.iSpacing = new Dimension( 4, 2 );
        defaults.iWeightH = 1.0;
        defaults.iWeightV = 1.0;
        defaults.iStretchToFitH = true;
        defaults.iStretchToFitV = true;
        return defaults;
    }

    public static MUIConstraints getMUIStatusDefaults()
    {
        MUIConstraints defaults = new MUIConstraints();
        defaults.iInsets = new Insets( 3, 6, 3, 6 );
        defaults.iSpacing = new Dimension( 4, 2 );
        defaults.iWeightH = 1.0;
        defaults.iWeightV = 0.0;
        defaults.iStretchToFitH = true;
        defaults.iStretchToFitV = false;
        defaults.iSameSizeH = true;
        defaults.iSameSizeV = true;
        return defaults;
    }

    public static MUIConstraints getMUIFileListerDefaults()
    {
        MUIConstraints defaults = new MUIConstraints();
        defaults.iInsets = new Insets( 3, 6, 3, 6 );
        defaults.iSpacing = new Dimension( 4, 2 );
        defaults.iWeightH = 1.0;
        defaults.iWeightV = 1.0;
        defaults.iStretchToFitH = true;
        defaults.iStretchToFitV = true;
        return defaults;
    }

    public static MUIConstraints getMUISplitterDefaults()
    {
        MUIConstraints defaults = new MUIConstraints();
        defaults.iSpacing = new Dimension( 2, 1 );
        defaults.iWeightH = 1.0;
        defaults.iWeightV = 1.0;
        defaults.iStretchToFitH = true;
        defaults.iStretchToFitV = true;
        return defaults;
    }

    public static MUIConstraints getMUISplitterHDefaults()
    {
        MUIConstraints defaults = getMUIGroupDefaults();
        defaults.iSameSizeV = true;
        return defaults;
    }

    public static MUIConstraints getMUISplitterVDefaults()
    {
        MUIConstraints defaults = getMUIGroupDefaults();
        defaults.iSameSizeH = true;
        return defaults;
    }

    public static MUIConstraints getMUITextPaneDefaults()
    {
        MUIConstraints defaults = new MUIConstraints();
        defaults.iSpacing = new Dimension( 2, 1 );
        defaults.iWeightH = 0.0;
        defaults.iWeightV = 0.0;
        defaults.iStretchToFitH = false;
        defaults.iStretchToFitV = false;
        return defaults;
    }
}
