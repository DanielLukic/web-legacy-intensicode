/************************************************************************/
/* MUI                    www.intensicode.de              November 2002 */
/************************************************************************/

package de.intensicode.mui;

import java.awt.Dimension;



/**
 * Stellt eine Bildansicht fuer die Anzeige eines ggf uebergrossen Bildes
 * bereit und versieht diese wenn notwendig mit Scrollbars.
 */
public class MUIImageView extends MUIObject
{
    /**
     * Uebernimmt die Bereitstellung der Scrollbars falls
     * {@link #iCanvas iCanvas} zu gross ist.
     */
    protected MUIScrollView iScrollView = null;

    /**
     * Dient der Anzeige der eigentlichen Bilddaten.
     */
    protected MUICanvas iCanvas = null;



    /**
     * Initialisiert die Bildansicht.
     */
    public MUIImageView()
    {
        this( new MUICanvas() );
    }

    /**
     * Initialisiert die Bildansicht.
     */
    public MUIImageView( Dimension aSize )
    {
        this( new MUICanvas( aSize ) );
    }

    protected MUIImageView( MUICanvas aCanvas )
    {
        iCanvas = aCanvas;
        iScrollView = new MUIScrollView( iCanvas );
        init( iScrollView.getJava(), MUIPrefs.getMUIImageViewDefaults() );
    }
}
