/************************************************************************/
/* MUI                 www.intensicode.de                 November 2002 */
/************************************************************************/

package de.intensicode.mui;

import java.awt.Component;
import java.awt.LayoutManager;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;

import javax.swing.BorderFactory;
import javax.swing.JComponent;
import javax.swing.JToolBar;



public abstract class MUIToolbar extends JToolBar implements MUIComponent
{
    protected CommandQueue actionQueue = new CommandQueue();

    protected MUILayout layout = null;



    protected MUIToolbar()
    {
        setBackground( MUIPrefs.getBackgroundColor() );
        setBorder( BorderFactory.createEtchedBorder() );
    }

    protected MUIToolbar( MUILayout layout )
    {
        this();
        setLayout( layout );
    }

    public void addChild( MUIComponent component )
    {
        MUIConstraints constraints = component.getConstraints();
        add( component.getJava(), constraints );
    }

    public double getWeightH( Component comp )
    {
        try
        {
            MUIComponent mui = ( MUIComponent ) comp;
            return mui.getWeightH();
        }
        catch ( ClassCastException ccEx )
        {
            MUIConstraints constraints = layout.getConstraints( comp );
            return constraints.iWeightH;
        }
    }

    public double getWeightV( Component comp )
    {
        try
        {
            MUIComponent mui = ( MUIComponent ) comp;
            return mui.getWeightV();
        }
        catch ( ClassCastException ccEx )
        {
            MUIConstraints constraints = layout.getConstraints( comp );
            return constraints.iWeightV;
        }
    }

    // From Container

    public void setLayout( LayoutManager layout )
    {
        try
        {
            MUILayout mui = ( MUILayout ) layout;
            super.setLayout( mui );
            this.layout = mui;
        }
        catch ( ClassCastException ccEx )
        {

        }
    }

    // From JComponent

    public void setEnabled( boolean flag )
    {
        for ( int idx = 0; idx < getComponentCount(); idx++ )
        {
            getComponent( idx ).setEnabled( flag );
        }
        super.setEnabled( flag );
    }

    // From MUIComponent

    public JComponent getJava()
    {
        return this;
    }

    public MUIConstraints getConstraints()
    {
        return layout.iDefaults;
    }

    public MUIComponent setActionCommand( Command cmd, Commandable main )
    {
        actionQueue.add( cmd, main );
        return this;
    }

    public void actionPerformed( ActionEvent event )
    {
        actionQueue.fire( event );
    }

    public MUIComponent setActionForwarding( MUIComponent receiver )
    {
        actionQueue.add( receiver );
        return this;
    }

    public MUIComponent setFocusability( boolean focusable )
    {
        this.setFocusable( focusable );
        return this;
    }

    public MUIComponent doEnable()
    {
        setEnabled( true );
        return this;
    }

    public MUIComponent doDisable()
    {
        setEnabled( false );
        return this;
    }

    public void setVisibleRect( Rectangle aBounds )
    {

    }
}
