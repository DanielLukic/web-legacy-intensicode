/************************************************************************/
/* MUI                      The.French.DJ                 November 2002 */
/************************************************************************/

package de.intensicode.mui;

import java.awt.Dimension;

import javax.swing.JTextArea;



/**
 * Stellt ein Textfeld bereit.
 */
public class MUITextArea extends MUIObject
{
    private SizedTextArea iTextArea = null;



    public MUITextArea()
    {
        iTextArea = new SizedTextArea();
        init( iTextArea, MUIPrefs.getMUITextAreaDefaults() );
    }

    public MUITextArea( String aText )
    {
        this();
        setText( aText );
    }
public MUITextArea( int rows, int columns )
    {
        iTextArea = new SizedTextArea( rows, columns );
        init( iTextArea, MUIPrefs.getMUITextAreaDefaults() );
    }

    public MUITextArea setText( String text )
    {
        iTextArea.setText( text );
        return this;
    }

    public String getText()
    {
        return iTextArea.getText();
    }

    public void setEditable( boolean editable )
    {
        iTextArea.setEditable( editable );
    }

    public void insert( String aMessage, int aIndex )
    {
        iTextArea.insert( aMessage, aIndex );
    }



    private /*inner*/ class SizedTextArea extends JTextArea
    {
        private int iPreferredHeight = -1;



        public SizedTextArea()
        {

        }

        public SizedTextArea( int aHeight, int aWidth )
        {
            super( aHeight, aWidth );

            iPreferredHeight = aHeight;
        }

        // From JComponent

        public Dimension getMinimumSize()
        {
            if ( iPreferredHeight == - 1)
            {
                return getPreferredScrollableViewportSize();
            }
            else
            {
                return getPreferredScrollableViewportSize();
            }
        }
    }
}
