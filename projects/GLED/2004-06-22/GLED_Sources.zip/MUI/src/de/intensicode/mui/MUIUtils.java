/************************************************************************/
/* MUI                   www.intensicode.de               November 2002 */
/************************************************************************/

package de.intensicode.mui;

import de.intensicode.core.logging.Log;

import java.awt.image.BufferedImage;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;



public class MUIUtils
{
    private static Log iLog = Log.getLog( "MUIUtils" );



    public static ImageIcon getIcon( String aResource )
    {
        try
        {
            InputStream resource = MUIUtils.class.getResourceAsStream( aResource );
            if ( resource == null )
            {
                throw new FileNotFoundException( aResource );
            }
            BufferedImage image = ImageIO.read( resource );
            return new ImageIcon( image );
        }
        catch ( IOException e )
        {
            iLog.warn( "Failed loading icon " + aResource );
            return null;
        }
    }
}
