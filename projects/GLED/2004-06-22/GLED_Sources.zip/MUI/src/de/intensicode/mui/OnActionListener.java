/************************************************************************/
/* MUI                  www.intensicode.de                November 2002 */
/************************************************************************/

package de.intensicode.mui;

import java.util.EventObject;



public interface OnActionListener
{
    public void onAction( MUIComponent aComponent, MUIAction aAction, EventObject aEvent );
}
