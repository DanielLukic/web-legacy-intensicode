/************************************************************************/
/* Gimolus3D          Vivatech Software Berlin GmbH         Januar 2003 */
/************************************************************************/

package de.intensicode.mui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;



/**
 * Hilfsklasse fuer - insbesondere GUI-Elemente - welche eine Liste von
 * Kommandos ausfuehren sollen, sobald ein bestimmtes Ereignis eintritt.
 */
public class CommandQueue {

    /**
     * Liste der registrierten Kommandos. Die Liste wird synchron mit der
     * {@link #commandables commandables} Liste der zuehoerigen
     * Commandable-Objekte gefuehrt.
     */
    private ArrayList commands = new ArrayList();

    /**
     * Liste der Empfaenger fuer die registrierten Kommandos. Die Liste
     * wird synchron mit der {@link #commands commands} Liste der
     * zuehoerigen Command-Objekte gefuehrt.
     */
    private ArrayList commandables = new ArrayList();

    /**
     * Fuer das ActionForwarding registrierte Empfaenger.
     */
    private ArrayList receivers = new ArrayList();



    /**
     * Registriert ein weiteres Kommando / Empfaenger Paar.
     */
    public void add( Command cmd, Commandable main ) {

        commands.add( cmd );
        commandables.add( main );

    } // void add( Command, Commandable )



    /**
     * Registriert einen weiteren Empfaenger fuer auftretende Events.
     */
    public void add( ActionListener receiver ) {

        receivers.add( receiver );

    } // void add( ActionListener )



    /**
     * Meldet des uebergebene Event indem zunaechst alle registrierten
     * Kommandos an ihre Empfaenger verschickt werden und dann alle
     * registrierten Event-Receiver das Event uebergeben bekommen.
     */
    public void fire( ActionEvent event ) {

        for ( int idx = 0; idx < commands.size(); idx ++ ) {

            Command cmd = ( Command ) commands.get( idx );
            Commandable main = ( Commandable ) commandables.get( idx );
            main.addCommand( cmd );

        }

        for ( int idx = 0; idx < receivers.size(); idx++ ) {

            ActionListener receiver =
                ( ActionListener ) receivers.get( idx );

            receiver.actionPerformed( event );

        }

    } // void fire( ActionEvent )

} // class CommandQueue
