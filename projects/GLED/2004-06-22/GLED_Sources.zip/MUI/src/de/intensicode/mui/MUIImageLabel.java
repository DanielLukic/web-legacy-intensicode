/*
 * Created by IntelliJ IDEA.
 * User: Lukic
 * Date: Jan 20, 2003
 * Time: 7:40:56 PM
 * To change template for new class use
 * Code Style | Class Templates options (Tools | IDE Options).
 */

package de.intensicode.mui;

import de.intensicode.core.ResourceManager;

import javax.swing.ImageIcon;
import javax.swing.JLabel;



public class MUIImageLabel extends MUIObject {

    public MUIImageLabel( String filename ) {

        JLabel label = new JLabel( new ImageIcon( ResourceManager.getResource( filename ) ) );

        init( label, MUIPrefs.getMUILabelDefaults() );

    } // MUIImageLabel( String )

} // class MUIImageLabel
