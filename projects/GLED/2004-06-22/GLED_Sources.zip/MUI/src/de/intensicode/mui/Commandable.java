/************************************************************************/
/* MUI                www.intensicode.de                    Januar 2003 */
/************************************************************************/

package de.intensicode.mui;

import java.util.ArrayList;
import java.util.Iterator;



/**
 * Basisklasse fuer Objekte die in einem eigenen Thread eingehende
 * Kommandos verarbeiten wollen. Kommandos werden dazu ueber
 * {@link #addCommand addCommand} der Kommando-Queue hinzugefuegt und dann
 * der Reihe nach abgearbeitet.
 * <p>
 * Kommandos werden dabei im Allgemeinen asynchron verarbeitet. Nur wenn
 * ein Kommando sich explizit als synchron auszeichnet wird es direkt im
 * Aufruf von {@link #addCommand addCommand} ausgefuehrt.
 * <p>
 * Warten bei hinzufuegen eines Kommandos bereits andere Kommandos der
 * gleichen Klasse, werden alle anderen geloscht. Dh von einem Kommando
 * befindet sich immer nur eines in der Queue.
 * <p>
 * Unterklassen sollten die Methode {@link #showError showError} sinnvoll
 * ueberschreiben. Ansonsten wird lediglich der StackTrace abgefangener
 * Fehler auf der Konsole ausgegeben.
 */
public class Commandable extends Thread
{
    /**
     * Liste der auf Ausfuehrung wartenden Kommandos.
     */
    private ArrayList commands = new ArrayList();

    /**
     * Enthaelt das aktuell in Ausfuehrung befindliche Kommando oder
     * <code>null</code>.
     */
    private Command currentCommand = null;



    /**
     * Konstruktor fuer die implementierenden Unterklassen. Startet die
     * Kommandoverarbeitung.
     */
    protected Commandable()
    {
        start();
    }

    /**
     * Fuegt der Kommando-Pipe ein neues Kommando zur Ausfuehrung hinzu.
     * Falls es sich dabei um ein synchrones Kommando handelt wird dieses
     * sofort ausgefuehrt und blockiert den aufrufenden Thread. Im
     * Allgemeinen wird es sich aber um ein asynchrones Komando handeln.
     * Dann wird es in der Queue abgelegt und zu einem spaeteren Zeitpunkt
     * abgearbeitet.
     */
    public void addCommand( Command command )
    {
        // Falls das Kommando synchron ist, sofort ausfuehren.
        if ( command.isAsync() == false )
        {
            execute( command );
            return;

        }

        // Kommando in die Queue haengen.
        synchronized ( commands )
        {
            Class commandClass = command.getClass();

            // Zuerst alle wartenden Kommandos gleichen Typs loeschen.
            Iterator waiting = commands.iterator();

            while ( waiting.hasNext() )
            {
                if ( commandClass.isInstance( waiting.next() ) )
                {
                    waiting.remove();
                }
            }

            // Jetzt das neue Kommando anhaengen.
            commands.add( command );
            commands.notifyAll();
        }
    }

    /**
     * Methode zum direkten Ausfuehren eines Kommandos. Das Kommando wird,
     * egal ob es sich als synchron oder asynchron ausgibt, sofort aus-
     * gefuehrt. Der Aufrufer hat sicherzustellen das keine Race-Conditions
     * oder aehnliche Probleme auftreten.
     */
    public void execute( Command command )
    {
        try
        {
            command.execute();
        }
        catch ( Throwable t )
        {
            showError( t );
        }
    }

    /**
     * Bricht die Verarbeitung des aktuellen Kommandos ab und loescht die
     * Liste der wartenden Kommandos.
     */
    public boolean abort()
    {
        synchronized ( commands )
        {
            commands.clear();
        }

        // Aktuelles Kommando abbrechen.
        synchronized ( this )
        {
            if ( currentCommand != null )
            {
                return currentCommand.abort();
            }
        }
        return true;
    }

    // From Thread

    /**
     * Hauptschleife der Kommandoverarbeitung.
     */
    public void run()
    {
        try
        {
            for ( ; ; )
            {
                Command command = null;
                synchronized ( commands )
                {
                    while ( commands.size() == 0 )
                    {
                        commands.wait();
                    }
                    command = ( Command ) commands.remove( 0 );
                }
                synchronized ( this )
                {
                    this.currentCommand = command;
                }

                execute( command );

                synchronized ( this )
                {
                    this.currentCommand = null;
                }
            }
        }
        catch ( InterruptedException iEx )
        {
            showError( iEx );
        }
    }

    // Implementation

    /**
     * Wird aufgerufen, falls ein Fehler auftritt. Sollte von Unterklassen
     * sinnvoll ueberschrieben werden (zB mit Ausgabe in Dialog-Box).
     */
    protected void showError( Throwable t )
    {
        t.printStackTrace();
    }
}
