/************************************************************************/
/* MUI                     www.intensicode.de             November 2002 */
/************************************************************************/

package de.intensicode.mui;

import de.intensicode.core.ResourceManager;

import java.awt.*;
import java.awt.event.*;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JPanel;



/**
 * Stellt einen Anzeigebereich bereit. Dieser kann insbesondere ein Bild
 * (als Hintergrund) anzeigen und eine Liste von
 * {@link de.intensicode.mui.Paintable Paintable} Objekten verwalten die
 * ueber das Bild (oder den leeren Hintergrund) gemalt werden.
 * <p>
 * Ein MUICanvas bietet mittels der Methoden
 * {@link #setMouseListener setMouseListener},
 * {@link #setMouseMotionListener setMouseMotionListener} und
 * {@link #setComponentListener setComponentListener} immer <strong>genau
 * einen</strong> Listener fuer diese Events zu registrieren. Dadurch kann
 * sozusagen der <i>Modus</i> des Canvas umgeschaltet werden.
 */
public class MUICanvas extends MUIObject
{
    protected SizedPanel iCanvas = null;

    private ArrayList iButtonListener = new ArrayList();

    private MouseMotionListener iMotionListener = null;

    private ComponentListener iComponentListener = null;



    public MUICanvas()
    {
        init( new SizedPanel() );
    }

    public MUICanvas( Dimension aSize )
    {
        init( new SizedPanel( aSize ) );
    }

    public void setClearBeforePaint( boolean aClearFlag )
    {
        iCanvas.setClearBeforePaint( aClearFlag );
    }

    public void setSize( Dimension aNewSize )
    {
        iCanvas.setSize( aNewSize );
    }

    /**
     * Fuegt der Ansicht ein weiteres sich zeichnendes Objekt hinzu.
     */
    public void addPaintable( Paintable aPaintable )
    {
        iCanvas.addPaintable( aPaintable );
    }

    /**
     * Fuegt der Ansicht ein weiteres sich zeichnendes Objekt hinzu.
     */
    public void removePaintable( Paintable aPaintable )
    {
        iCanvas.removePaintable( aPaintable );
    }

    /**
     * Legt den neuen MouseListener fuer den Anzeigebereich. Alle ggf bisher
     * registrierten Listener werden entfernt.
     */
    public void setMouseListener( MouseListener aListener )
    {
        for ( int idx = 0; idx < iButtonListener.size(); idx++ )
        {
            iCanvas.removeMouseListener( ( MouseListener ) iButtonListener.get( idx ));
        }
        iButtonListener.clear();

        iCanvas.addMouseListener( aListener );
        iButtonListener.add( aListener );
    }

    /**
     * Fuegt der Komponente einen neuen Listener hinzu.
     */
    public void addMouseListener( MouseListener aListener )
    {
        iCanvas.addMouseListener( aListener );
        iButtonListener.add( aListener );
    }

    /**
     * Legt den neuen MouseMotionListener fuer den Anzeigebereich. Ein ggf
     * bisher registrierter Listener wird deaktiviert.
     */
    public void setMouseMotionListener( MouseMotionListener aListener )
    {
        if ( iMotionListener != null )
        {
            iCanvas.removeMouseMotionListener( iMotionListener );
        }

        iCanvas.addMouseMotionListener( aListener );

        iMotionListener = aListener;
    }

    /**
     * Legt den neuen ComponentListener fuer den Anzeigebereich. Ein ggf
     * bisher registrierter Listener wird deaktiviert.
     */
    public void setComponentListener( ComponentListener aListener )
    {
        if ( iComponentListener != null )
        {
            iCanvas.removeComponentListener( iComponentListener );
        }

        iCanvas.addComponentListener( aListener );

        iComponentListener = aListener;
    }

    public void setStretched( boolean aStretchToFitFlag )
    {
        iCanvas.setStrechted( aStretchToFitFlag );
    }

    public void setBackgroundImage( Image aBackgroundImage )
    {
        iCanvas.setBackgroundImage( aBackgroundImage );
    }

    public Dimension getSize()
    {
        return iCanvas.getSize();
    }

    public void update()
    {
        iCanvas.repaint( 250 );
    }

    public String getToolTip()
    {
        return iCanvas.getToolTipText();
    }

    // Implementation

    private void init( SizedPanel aPanel )
    {
        this.iCanvas = aPanel;

        init( aPanel, MUIPrefs.getCanvasDefaults() );
    }



    public class SizedPanel extends JPanel
    {
        private Image iBackgroundImage = null;

        private ArrayList iPaintables = new ArrayList();

        private Dimension iSize = null;

        private boolean iStretchToFit = false;

        private ImageIcon iStretchModeIcon = null;

        private boolean iClearBeforePaint = true;



        public SizedPanel()
        {
            StretchToggle toggle = new StretchToggle();
            addMouseListener( toggle );
        }

        public SizedPanel( Dimension aSize )
        {
            this();
            this.iSize = aSize;
        }

        public void setClearBeforePaint( boolean aClearFlag )
        {
            iClearBeforePaint = aClearFlag;
        }

        /**
         * Legt fest ob das (Hintergrund-)Bild auf die Groesse des Canvas
         * gestreckt werden oder einfach nur mittig angezeigt werden soll.
         */
        public void setStrechted( boolean aStretchToFitFlag )
        {
            iCanvas.iStretchToFit = aStretchToFitFlag;

            if ( iCanvas.iStretchToFit )
            {
                iStretchModeIcon = new ImageIcon( ResourceManager.getResource( "/images/buttons/Shortcut.gif" ) );
            }
            else
            {
                iStretchModeIcon = new ImageIcon( ResourceManager.getResource( "/images/buttons/Shortcut Selected.gif" ) );
            }
            repaint();
        }

        /**
         * Legt das darzustellende Bild fest.
         */
        public void setBackgroundImage( Image aBackgroundImage )
        {
            this.iBackgroundImage = aBackgroundImage;
        }

        public void addPaintable( Paintable aPaintable )
        {
            iPaintables.add( aPaintable );
        }

        public void removePaintable( Paintable aPaintable )
        {
            iPaintables.remove( aPaintable );
        }

        // From JComponent

        public void setSize( Dimension aNewSize )
        {
            iSize = new Dimension( aNewSize );
            super.setSize( iSize );
        }

        public void setSize( int width, int height )
        {
            iSize = new Dimension( width, height );
            super.setSize( iSize.width, iSize.height );
        }

        public Dimension getPreferredSize()
        {
            if ( iSize != null )
            {
                return iSize;
            }
            else
            {
                return super.getPreferredSize();
            }
        }

        public Dimension getMinimumSize()
        {
            return getPreferredSize();
        }

        public void paint( Graphics aGc )
        {
            Dimension size = iCanvas.getSize();
            int width = ( int ) size.getWidth();
            int height = ( int ) size.getHeight();

            if ( iBackgroundImage != null )
            {
                aGc.setColor( MUIPrefs.getBackgroundColor() );
                aGc.fillRect( 0, 0, width, height );

                boolean tooBig = width < iBackgroundImage.getWidth( null );
                tooBig |= height < iBackgroundImage.getHeight( null );

                if ( iStretchToFit || tooBig )
                {
                    aGc.drawImage( iBackgroundImage, 0, 0, width, height, null );
                }
                else
                {
                    int xOffset = ( width - iBackgroundImage.getWidth( null ) ) / 2;
                    int yOffset = ( height - iBackgroundImage.getHeight( null ) ) / 2;

                    aGc.drawImage( iBackgroundImage, xOffset, yOffset, null );
                }
            }
            else if ( iClearBeforePaint )
            {
                super.paint( aGc );
            }

            Graphics2D gc = ( Graphics2D ) aGc;
            for ( int idx = 0; idx < iPaintables.size(); idx++ )
            {
                Paintable paintMe = ( Paintable ) iPaintables.get( idx );
                paintMe.paintInto( gc, size );
            }
        }



        /**
         * Hilfsklasse fuer das Darstellen und Verwalten eines kleinen
         * StretchToggle Buttons im Anzeigebereich.
         */
        class StretchToggle extends MouseAdapter implements Paintable
        {
            private static final String KStretchToggleImageFileName = "/images/buttons/Shortcut Selected.gif";

            /**
             * Initialisiert das Icon.
             */
            public StretchToggle()
            {
                URL source = ResourceManager.getResource( KStretchToggleImageFileName );
                try
                {
                    if ( source == null )
                    {
                        throw new FileNotFoundException( KStretchToggleImageFileName );
                    }
                    iStretchModeIcon = new ImageIcon( ImageIO.read( source ) );
                }
                catch ( IOException ex )
                {

                }
            }

            /**
             * Prueft bei einem Mausklick ob dieser auf dem StrechToggle
             * geschah und schaltet dann den StrechToFit Modus um.
             */
            public void mouseClicked( MouseEvent aEvent )
            {
                if ( iBackgroundImage == null || iStretchModeIcon == null )
                {
                    return;
                }

                Point pos = aEvent.getPoint();
                int x = ( int ) pos.getX();
                int y = ( int ) pos.getY();

                int width = iStretchModeIcon.getImage().getWidth( null );
                int height = iStretchModeIcon.getImage().getHeight( null );
                int yPos = ( int ) ( iJava.getSize().getHeight() - height );

                if ( x > width ) return;
                if ( y < yPos ) return;

                setStretched( !iStretchToFit );
            }

            // From Paintable

            public void paintInto( Graphics2D aGc, Dimension aTargetSize )
            {
                if ( iBackgroundImage == null || iStretchModeIcon == null )
                {
                    return;
                }

                int height = ( int ) aTargetSize.getHeight();
                int iconHeight = iStretchModeIcon.getImage().getHeight( null );

                int togglePos = height - iconHeight;
                aGc.drawImage( iStretchModeIcon.getImage(), 0, togglePos, null );
            }
        }
    }
}
