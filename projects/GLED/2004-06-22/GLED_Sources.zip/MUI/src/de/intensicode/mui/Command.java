/************************************************************************/
/* MUI                      www.intensicode.de              Januar 2003 */
/************************************************************************/

package de.intensicode.mui;



/**
 * Schnittstelle fuer ausfuehrbare Kommandos.
 */
public interface Command
{
    /**
     * Wird aufgerufen, sobald das Kommando sich ausfuehren soll.
     */
    public void execute() throws Throwable;

    /**
     * Zeigt an ob das Kommando asynchron ausgefuehrt werden soll.
     */
    public boolean isAsync();

    /**
     * Liefert den Namen des Kommandos.
     */
    public String getName();

    /**
     * Versucht das laufende Kommando abzubrechen. Liefert genau dann
     * <code>true</code>, wenn das Kommando zur Zeit gerade aktiv war und
     * das Abbrechen erfolgreich war.
     */
    public boolean abort();
}
