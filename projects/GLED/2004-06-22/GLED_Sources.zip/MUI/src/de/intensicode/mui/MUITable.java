/************************************************************************/
/* MUI                   www.itnensicode.de               November 2002 */
/************************************************************************/

package de.intensicode.mui;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;

import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableModel;



public class MUITable extends MUIObject implements ComponentListener
{
    public MUIAction ON_SELECTION;

    protected MutableTableModel iModel;

    protected MutableTable iTable = null;



    public MUITable()
    {
        iModel = new MutableTableModel();
        iTable = new MutableTable( iModel );

        iTable.setFont( iTable.getFont().deriveFont( 0 ).deriveFont( 10.0f ) );
        iTable.addComponentListener( this );

        init( iTable, MUIPrefs.getMUIListDefaults() );

        ON_SELECTION = new ON_SELECTION( this );
    }

    public MUITable setData( Object[] aTableData )
    {
        iModel.setTableData( aTableData );
        return this;
    }

    public MUITable setAction( MUIAction action, OnActionListener receiver )
    {
        action.install( receiver );
        return this;
    }

    // From ComponentListener

    public void componentHidden( ComponentEvent e )
    {

    }

    public void componentMoved( ComponentEvent e )
    {

    }

    public void componentResized( ComponentEvent e )
    {

    }

    public void componentShown( ComponentEvent e )
    {

    }

    // Implementation

    protected /*inner*/ class MutableTable extends JTable
    {
        MutableTable( TableModel aTableModel )
        {
            super( aTableModel );
            setDefaultRenderer( getColumnClass( 0 ), new MUICellRenderer() );
        }

        public int getCellWidth()
        {
            if ( getColumnCount() == 0 )
            {
                return getWidth();
            }
            return getWidth() / getColumnCount();
        }

        public void setCellSize( Dimension aSize )
        {
            iTable.setRowHeight( aSize.height );
        }

//        public int getScrollableUnitIncrement( Rectangle visibleRect, int orientation, int direction )
//        {
//            return super.getScrollableUnitIncrement( visibleRect, orientation, direction ) / 2 + 1;
//        }
    }



    private /*inner*/ class MutableTableModel extends AbstractTableModel
    {
        private Object[] iTableData;

        private MUICanvas iEmptyPanel = new MUICanvas();



        public void setTableData( Object[] aTableData )
        {
            iTableData = aTableData;
            fireTableDataChanged();
            fireTableStructureChanged();
        }

        // From TableModel

        public Class getColumnClass( int columnIndex )
        {
            if ( iTableData != null )
            {
                if ( columnIndex >= 0 && columnIndex < iTableData.length )
                {
                    return iTableData[ columnIndex ].getClass();
                }
            }
            return super.getColumnClass( columnIndex );
        }

        public void setValueAt( Object aValue, int rowIndex, int columnIndex )
        {
            if ( iTableData != null )
            {
                int index = rowIndex * columnIndex;
                if ( index >= 0 && index < iTableData.length )
                {
                    iTableData[ index ] = aValue;
                }
            }
        }

        public String getColumnName( int column )
        {
            return null;
        }

        public boolean isCellEditable( int rowIndex, int columnIndex )
        {
            return false;
        }

        public int getColumnCount()
        {
            if ( iTableData == null )
            {
                return 1;
            }
            else
            {
                int width = ( int ) Math.round( Math.sqrt( iTableData.length * 3 / 2 ) );
                return Math.max( 1, width );
            }
        }

        public int getRowCount()
        {
            if ( iTableData == null )
            {
                return 1;
            }
            else
            {
                int width = getColumnCount();
                int height = iTableData.length / width;
                if ( width * height < iTableData.length )
                {
                    height++;
                }
                return height;
            }
        }

        public Object getValueAt( int rowIndex, int columnIndex )
        {
            if ( iTableData == null )
            {
                return iEmptyPanel;
            }
            else
            {
                int index = rowIndex * getColumnCount() + columnIndex;
                if ( index >= 0 && index < iTableData.length )
                {
                    return iTableData[ index ];
                }
                else
                {
                    return iEmptyPanel;
                }
            }
        }
    }



    protected /*inner*/ class MUICellRenderer implements TableCellRenderer
    {
        public Component getTableCellRendererComponent( JTable table, Object aValue,
                                                        boolean aSelectedFlag, boolean hasFocus,
                                                        int row, int column )
        {
            if ( aValue instanceof MUIComponent )
            {
                MUIComponent mui = ( MUIComponent ) aValue;
                Component java = mui.getJava();
                if ( aSelectedFlag )
                {
                    java.setBackground( MUIPrefs.getSelectedBackgroundColor() );
                }
                else
                {
                    java.setBackground( MUIPrefs.getBackgroundColor() );
                }
                return java;
            }
            return new JLabel( aValue.toString() );
        }
    }



    private /*inner*/ class ON_SELECTION extends MUIAbstractAction implements ListSelectionListener
    {
        public ON_SELECTION( MUITable aTable )
        {
            super( aTable );
//            aTable.iTable.addListSelectionListener( this );
        }

        // From ListSelectionListener

        public void valueChanged( ListSelectionEvent aEvent )
        {
            broadcast( aEvent );
        }
    }
}
