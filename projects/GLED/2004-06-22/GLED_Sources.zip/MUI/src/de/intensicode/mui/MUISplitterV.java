/************************************************************************/
/* MUI                      The.French.DJ                   Januar 2003 */
/************************************************************************/

package de.intensicode.mui;

import de.intensicode.mui.MUISplitter;

import java.awt.Component;

import javax.swing.JSplitPane;



/**
 *
 */
public class MUISplitterV extends MUISplitter {

    public MUISplitterV() {

        super( JSplitPane.VERTICAL_SPLIT, MUIPrefs.getMUISplitterVDefaults() );

    } // MUISplitterV()

} // class MUISplitterV
