/************************************************************************/
/* MUI                    www.intensicode.de              November 2002 */
/************************************************************************/

package de.intensicode.mui;

import de.intensicode.core.ResourceManager;

import java.net.URL;

import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JButton;



/**
 * Stellt einen JButton mit Bild statt Text bereit.
 */
public class MUIImageButton extends MUIButton
{
    /**
     * Initialisiert einen neuen Image-Button mit dem Bild aus der
     * angegebenen Datei.
     */
    public MUIImageButton( String aFileName )
    {
        URL url = ResourceManager.getResource( aFileName );

        iButton = new JButton( new ImageIcon( url ) );

        iButton.addActionListener( this );
        iButton.setBorderPainted( false );
        iButton.setName( aFileName );

        init( iButton, MUIPrefs.getMUIImageButtonDefaults() );
    }

    /**
     * Initialisiert einen Image-Button mit Tool-Tip.
     */
    public MUIImageButton( String aFileName, String aToolTip )
    {
        this( aFileName );
        iButton.setToolTipText( aToolTip );
    }

    public MUIImageButton( Action aAction )
    {
        iButton = new JButton( aAction );
        iButton.setText( null );
        iButton.setBorderPainted( false );
        init( iButton, MUIPrefs.getMUIImageButtonDefaults() );
    }
}
