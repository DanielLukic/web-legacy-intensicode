/************************************************************************/
/* MUI                  www.intensicode.de                November 2002 */
/************************************************************************/

package de.intensicode.mui;

import java.awt.event.ActionListener;

import javax.swing.AbstractButton;
import javax.swing.Action;
import javax.swing.JButton;



public class MUIButton extends MUIObject
{
    protected AbstractButton iButton = null;



    public MUIButton( String aName )
    {
        iButton = new JButton( aName );
        iButton.addActionListener( this );
        iButton.setActionCommand( aName );
        init( iButton, MUIPrefs.getMUIButtonDefaults() );
    }

    public MUIButton( Action aAction )
    {
        iButton = new JButton( aAction );
        init( iButton, MUIPrefs.getMUIButtonDefaults() );
    }

    public MUIButton addActionListener( ActionListener aListener )
    {
        iButton.addActionListener( aListener );
        return this;
    }

    public AbstractButton getButton()
    {
        return iButton;
    }

    // Protected Interface

    protected MUIButton()
    {

    }
}
