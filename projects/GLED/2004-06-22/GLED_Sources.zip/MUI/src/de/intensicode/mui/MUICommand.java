/************************************************************************/
/* Gimolus3D        Vivatech Software Berlin GmbH           Januar 2003 */
/************************************************************************/

package de.intensicode.mui;



/**
 * Spezielles Interface fuer Command-Objekte die am Erzeuger eintreffender
 * Ereignisse interessiert sind. Ein MUICommand kann immer nur einen
 * Erzeuger haben. Dh wird ein Kommando in mehreren MUIComponent Objekten
 * mit setActionCommand registriert, wird fuer jede dieser Registrierungen
 * {@link #setComponent setComponent} aufgerufen.
 */
public interface MUICommand {

    /**
     * Teilt dem Kommando den Erzeuger von Ereignissen mit.
     */
    public void setComponent( MUIComponent eventProducer );

} // interface MUICommand
