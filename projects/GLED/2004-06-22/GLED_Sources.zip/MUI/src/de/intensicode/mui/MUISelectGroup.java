/************************************************************************/
/* MUI                   www.intensicode.de               November 2002 */
/************************************************************************/

package de.intensicode.mui;



public interface MUISelectGroup
{
    void addSelectable( MUIObject aButton );

    String getSelected();

    Object[] getSelectedObjects();
    
    void setSelected( String aControlName );
}
