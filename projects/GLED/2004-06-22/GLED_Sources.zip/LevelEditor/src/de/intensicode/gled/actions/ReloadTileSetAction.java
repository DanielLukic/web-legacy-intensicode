/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.actions;

import de.intensicode.gled.commands.LoadTileSet;
import de.intensicode.mui.MUIUtils;

import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.io.File;

import javax.swing.Action;
import javax.swing.KeyStroke;



public class ReloadTileSetAction extends GledAction
{
    public ReloadTileSetAction()
    {
        putValue( Action.NAME, "Reload" );
        putValue( Action.SHORT_DESCRIPTION, "Reload tile setFrom" );
        putValue( Action.SMALL_ICON, MUIUtils.getIcon( "/icons/reload.png" ) );
        putValue( Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke( KeyEvent.VK_R, KeyEvent.CTRL_DOWN_MASK ) );
    }

    // From ActionListener

    public void actionPerformed( ActionEvent aEvent )
    {
        File tileSetFile = iApplication.getTileSetFile();
        iMainFrame.addCommand( new LoadTileSet( iApplication, tileSetFile ) );
    }
}
