/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.breakout;

import de.intensicode.gled.domain.BlockData;
import de.intensicode.gled.domain.TileSelection;
import de.intensicode.symbian.TDes8;



/**
 *
 */
class BreakOutBlockData implements BlockData
{
    private int iTileIndex;

    private int iSkinIndex;

    private int iExtraIndex;



    public void load( TDes8 aBlockData )
    {
        iTileIndex = Character.toUpperCase( ( char ) aBlockData.at( 0 ) ) - ' ';
        iSkinIndex = Character.toUpperCase( ( char ) aBlockData.at( 1 ) ) - 'A';
        iExtraIndex = ( ( char ) aBlockData.at( 2 ) ) - ' ';

        if ( iSkinIndex < 0 )
        {
            iSkinIndex = 0;
        }

        checkConstraints();
    }

    public void save( TDes8 aBlockData )
    {
        char tileIndex = Character.toLowerCase( ( char ) ( iTileIndex + ' ' ) );
        char skinIndex = Character.toLowerCase( ( char ) ( iSkinIndex + 'A' ) );

        aBlockData.set( 0, ( byte ) tileIndex );
        if ( iTileIndex != 0 || iSkinIndex != 0 )
        {
            aBlockData.set( 1, ( byte ) skinIndex );
        }
        else
        {
            aBlockData.set( 1, ( byte ) ' ' );
        }

        aBlockData.set( 2, ( byte ) ( iExtraIndex + ' ' ) );
    }

    // From BlockData

    public boolean isEmpty( int aLayerIndex )
    {
        switch ( aLayerIndex )
        {
            case 0:
                return iTileIndex == 0;
            case 1:
                return iExtraIndex == 0;
            default:
                throw new IllegalArgumentException( "Invalid layer index: " + aLayerIndex );
        }
    }

    public boolean matches( TileSelection aTileSelection )
    {
        int index = getTileIndex( aTileSelection.getLayerIndex() );
        return index == aTileSelection.getTileIndex();
    }

    public int getTileIndex( int aLayerIndex )
    {
        switch ( aLayerIndex )
        {
            case 0:
                return iTileIndex + iSkinIndex * 64;
            case 1:
                return iExtraIndex;
            default:
                throw new IllegalArgumentException( "Invalid layer index: " + aLayerIndex );
        }
    }

    public void setTileIndex( int aLayerIndex, int aSelectedTile )
    {
        switch ( aLayerIndex )
        {
            case 0:
                iTileIndex = aSelectedTile % 64;
                iSkinIndex = aSelectedTile / 64;
                break;
            case 1:
                iExtraIndex = aSelectedTile;
                break;
            default:
                throw new IllegalArgumentException( "Invalid layer index: " + aLayerIndex );
        }

        checkConstraints();
    }

    public void setFrom( TileSelection aTileSelection )
    {
        setTileIndex( aTileSelection.getLayerIndex(), aTileSelection.getTileIndex() );
    }

    public void setFrom( BlockData aData )
    {
        setTileIndex( 0, aData.getTileIndex( 0 ) );
        setTileIndex( 1, aData.getTileIndex( 1 ) );
    }

    public BlockData cloned()
    {
        BreakOutBlockData clone = new BreakOutBlockData();
        clone.iExtraIndex = this.iExtraIndex;
        clone.iSkinIndex = this.iSkinIndex;
        clone.iTileIndex = this.iTileIndex;
        return clone;
    }

    // Implementation

    private void checkConstraints()
    {
        if ( iTileIndex < 0 || iTileIndex >= 64 )
        {
            throw new IllegalArgumentException( "Tile index out of range (0..63): " + iTileIndex );
        }
        if ( iSkinIndex >= 5 )
        {
            throw new IllegalArgumentException( "Skin index out of range (0..4): " + iSkinIndex );
        }
        if ( iExtraIndex < 0 || iExtraIndex >= 96 )
        {
            throw new IllegalArgumentException( "Extra index out of range (0..96): " + iExtraIndex );
        }
    }
}
