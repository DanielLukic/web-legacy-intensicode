/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.commands;

import de.intensicode.core.config.ConfigurationException;
import de.intensicode.gled.domain.LevelDataProvider;
import de.intensicode.gled.domain.SystemFactory;



public class NewLevelData extends GledCommand
{
    public void execute() throws ConfigurationException
    {
        SystemFactory factory = iApplication.getSystemFactory();
        LevelDataProvider levelProvider = factory.createLevelDataProvider();

        iApplication.setLevelDataFile( null );
        iApplication.setLevelDataProvider( levelProvider );
    }
}
