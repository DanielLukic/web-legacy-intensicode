/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.gui;

import de.intensicode.core.config.ConfigurationException;
import de.intensicode.gled.actions.GledAction;
import de.intensicode.gled.commands.GledCommand;
import de.intensicode.gled.domain.Application;
import de.intensicode.mui.*;

import javax.swing.JButton;
import javax.swing.JFrame;



public class LevelSorter extends MUIDialog
{
    private Application iApplication;

    private Commandable iCommandable = new ModalCommandable();

    private MUIButton iCloseButton = new MUIButton( "Close" );



    public LevelSorter( JFrame aParentFrame, Application aApplication ) throws ConfigurationException
    {
        super( aParentFrame, "Level Sorter", true );
        iApplication = aApplication;

        MUIGroup controls = new MUIGroupH();
        controls.addChild( buildTileTable() );

        MUIGroup contents = new MUIGroupV();
        contents.addChild( controls );
        contents.addCentered( buildCommands() );

        getRootPane().setDefaultButton( ( JButton ) iCloseButton.getJava() );

        iCloseButton.setActionCommand( new CloseDialog(), iCommandable );

        addChild( contents );
        centerDialog();
    }

    // Implementation

    private MUIComponent buildTileTable()
    {
        MUIGroup group = new MUIGroupH();
        group.setTitle( "Overview" );
        group.addChild( new MUIScrollView( new LevelSorterView( iApplication ) ).setScrollDirections( false, true ) );
        return group;
    }

    private MUIComponent buildCommands() throws ConfigurationException
    {
        MUIGroup group = new MUIGroupH();
        group.addChild( iCloseButton );
        group.addChild( new MUISeparatorV() );
        group.addChild( new MUIImageButton( GledAction.getAction( "AddNewLevel" ) ) );
        group.addChild( new MUIImageButton( GledAction.getAction( "DeleteCurrentLevel" ) ) );
        return group;
    }



    private /*inner*/ class ModalCommandable extends Commandable
    {

    }



    private /*inner*/ class CloseDialog extends GledCommand
    {
        public void execute() throws Throwable
        {
            hide();
        }
    }
}
