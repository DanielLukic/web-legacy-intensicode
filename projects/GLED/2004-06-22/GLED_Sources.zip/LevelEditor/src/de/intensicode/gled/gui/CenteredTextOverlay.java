/************************************************************************/
/* Gimolus3D        Vivatech Software Berlin GmbH           Januar 2003 */
/************************************************************************/

package de.intensicode.gled.gui;

import de.intensicode.mui.Paintable;
import junit.framework.Assert;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;



public class CenteredTextOverlay implements Paintable
{
    private boolean iAmVisible = true;

    private Color iTextColor = new Color( 0, 0, 0 );

    private String iText = "";



    public CenteredTextOverlay( String aText )
    {
        Assert.assertNotNull( aText );

        iText = aText;
    }

    // From Paintable

    public void paintInto( Graphics2D aGc, Dimension aTargetSize )
    {
        if ( iAmVisible == false )
        {
            return;
        }

        FontMetrics metrics = aGc.getFontMetrics();
        Rectangle2D bounds = metrics.getStringBounds( iText, aGc );

        double xPos = ( aTargetSize.width - bounds.getWidth() ) / 2;
        double yPos = ( aTargetSize.height - bounds.getHeight() ) / 2;

        aGc.setColor( iTextColor );
        aGc.drawString( iText, ( int ) xPos, ( int ) yPos );
    }
}
