/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.domain;



public interface TileSelection
{
    void addListener( TileSelectionListener aListener );

    boolean isValid();

    int getLayerIndex();

    int getTileIndex();

    void setTo( int aLayerIndex, int aTileIndex );
}
