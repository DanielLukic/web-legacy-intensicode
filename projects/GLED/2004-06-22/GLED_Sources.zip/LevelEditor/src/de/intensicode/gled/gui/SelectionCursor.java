/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.gui;

import de.intensicode.mui.Paintable;

import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.util.Timer;
import java.util.TimerTask;



public class SelectionCursor extends MouseAdapter implements Paintable, MouseMotionListener
{
    private static final int KMaxAnimCounter = 10;

    private static final int KAnimInterval = 50;

    private SelectionCursorListener iListener;

    private Stroke iCursorStroke;

    private Color iCursorColor;

    private int iAnimCounter;

    private Point iIndex;

    private Point iOffset;

    private Dimension iGridSize;

    private Dimension iSize;

    private Component iContainer;

    private Timer iAnimTimer = new Timer();

    private TimerTask iFlashHandler = new FlashHandler();

    private int iEventButton;

    private boolean iEnabled;

    private Rectangle iDrawRect = new Rectangle();



    public SelectionCursor( SelectionCursorListener aListener )
    {
        iListener = aListener;

        iCursorColor = new Color( 240, 24, 24 );
        iCursorStroke = new BasicStroke( 2.5f );

        iIndex = new Point( -1, -1 );
        iOffset = new Point();
        iGridSize = new Dimension();
        iSize = new Dimension();
    }

    public void setEnabled( boolean aEnabledFlag )
    {
        iEnabled = aEnabledFlag;
    }

    public void setFlashing( Component aContainer )
    {
        iContainer = aContainer;

        if ( iContainer == null )
        {
            iAnimTimer.cancel();
        }
        else
        {
            iAnimTimer.scheduleAtFixedRate( iFlashHandler, KAnimInterval, KAnimInterval );
        }
    }

    public void setOffset( Point aOffset )
    {
        setOffset( aOffset.x, aOffset.y );
    }

    public void setOffset( int aX, int aY )
    {
        iOffset.x = aX;
        iOffset.y = aY;
    }

    public void setGridSize( Dimension aSize )
    {
        setGridSize( aSize.width, aSize.height );
    }

    public void setGridSize( int aTilesInRow, int aTilesInColumn )
    {
        iGridSize.width = aTilesInRow;
        iGridSize.height = aTilesInColumn;
    }

    public void setSelectionSize( Dimension aSize )
    {
        iSize.width = aSize.width;
        iSize.height = aSize.height;
    }

    public void setIndex( int aSelectedIndex )
    {
        if ( iGridSize.width == 0 )
        {
            return;
        }

        iIndex.x = aSelectedIndex % iGridSize.width;
        iIndex.y = aSelectedIndex / iGridSize.width;

        if ( iContainer != null )
        {
            iContainer.repaint( 250 );
        }
    }

    public void setIndex( Point aNewIndex )
    {
        iIndex.x = aNewIndex.x;
        iIndex.y = aNewIndex.y;

        if ( iContainer != null )
        {
            iContainer.repaint( 250 );
        }
    }

    public Point getIndex()
    {
        return iIndex;
    }

    public Rectangle getRectangle( int aX, int aY )
    {
        int columns = iGridSize.width;
        int rows = iGridSize.height;
        int width = iSize.width;
        int height = iSize.height;
        iDrawRect.x = iIndex.x * width / columns;
        iDrawRect.y = iIndex.y * height / rows;
        int xEnd = ( iIndex.x + 1 ) * width / columns;
        int yEnd = ( iIndex.y + 1 ) * height / rows;
        iDrawRect.width = xEnd - iDrawRect.x;
        iDrawRect.height = yEnd - iDrawRect.y;
        return iDrawRect;
    }

    // From Paintable

    public void paintInto( Graphics2D aGc, Dimension aTargetSize )
    {
        if ( iIndex.x == -1 || iIndex.y == -1 || iEnabled == false )
        {
            return;
        }

        int columns = iGridSize.width;
        int rows = iGridSize.height;
        int width = iSize.width;
        int height = iSize.height;
        int xStart = iIndex.x * width / columns + iOffset.x;
        int yStart = iIndex.y * height / rows + iOffset.y;
        int xEnd = ( iIndex.x + 1 ) * width / columns + iOffset.x;
        int yEnd = ( iIndex.y + 1 ) * height / rows + iOffset.y;
        int xDelta = xEnd - xStart;
        int yDelta = yEnd - yStart;
        if ( xDelta < 1 || yDelta < 1 )
        {
            return;
        }

        Stroke stroke = aGc.getStroke();
        Color color = aGc.getColor();
        aGc.setColor( iCursorColor );
        aGc.setStroke( iCursorStroke );
        aGc.drawRect( xStart, yStart, xDelta, yDelta );
        aGc.setStroke( stroke );
        aGc.setColor( color );
    }

    // From MouseAdapter

    public void mouseClicked( MouseEvent aEvent )
    {
        iEventButton = aEvent.getButton();
        setSelection( aEvent );
        iEventButton = -1;
    }

    public void mousePressed( MouseEvent aEvent )
    {
        iEventButton = aEvent.getButton();
        setSelection( aEvent );
    }

    public void mouseReleased( MouseEvent aEvent )
    {
        setSelection( aEvent );
        iEventButton = -1;
    }

    // From MouseMotionListener

    public void mouseDragged( MouseEvent aEvent )
    {
        setSelection( aEvent );
    }

    public void mouseMoved( MouseEvent aEvent )
    {

    }

    // Implementation

    private void setSelection( MouseEvent aEvent )
    {
        if ( iGridSize.width == 0 || iGridSize.height == 0 || iEventButton == -1 )
        {
            return;
        }

        int columns = iGridSize.width;
        int rows = iGridSize.height;
        int width = iSize.width;
        int height = iSize.height;

        Point position = aEvent.getPoint();
        int x = ( position.x - iOffset.x ) * columns / width;
        int y = ( position.y - iOffset.y ) * rows / height;

        int xNew = Math.min( x, columns - 1 );
        xNew = Math.max( xNew, 0 );
        int yNew = Math.min( y, rows - 1 );
        yNew = Math.max( yNew, 0 );

        iIndex.x = xNew;
        iIndex.y = yNew;

        if ( iEventButton == MouseEvent.BUTTON1 )
        {
            iListener.onNewSelection( iIndex.x, iIndex.y );
        }
        else if ( iEventButton == MouseEvent.BUTTON3 )
        {
            iListener.onAlternativeSelection( iIndex.x, iIndex.y );
        }
    }



    private /*inner*/ class FlashHandler extends TimerTask
    {
        public void run()
        {
            if ( iContainer == null || iEnabled == false )
            {
                return;
            }
            if ( iIndex.x == -1 || iIndex.y == -1 )
            {
                return;
            }

            if ( ++iAnimCounter >= KMaxAnimCounter )
            {
                iAnimCounter = 0;
            }

            int value = iAnimCounter * 255 / KMaxAnimCounter;
            if ( value < 128 )
            {
                value = 255 - value;
            }
            iCursorColor = new Color( value, value, 255 - value );

            iContainer.repaint( KAnimInterval );
        }
    }
}
