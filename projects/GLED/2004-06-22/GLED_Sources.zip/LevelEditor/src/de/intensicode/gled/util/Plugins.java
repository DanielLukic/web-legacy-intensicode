/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.util;

import java.util.ArrayList;
import java.util.NoSuchElementException;



/**
 *
 */
public class Plugins
{
    private ArrayList iPlugins = new ArrayList();



    public Plugins()
    {
        iPlugins.add( new KnownPlugin( "BreakOut" ) );
        iPlugins.add( new KnownPlugin( "IntensiBlast" ) );
    }

    public int getNumberOfPlugins()
    {
        return iPlugins.size();
    }

    public Plugin getPlugin( int aIdx )
    {
        return ( Plugin ) iPlugins.get( aIdx );
    }

    public Plugin getDefaultPlugin()
    {
        return getPlugin( 0 );
    }

    public Plugin forName( String aPluginName )
    {
        for ( int idx = 0; idx < iPlugins.size(); idx++ )
        {
            Plugin plugin = getPlugin( idx );
            if ( plugin.getName().equals( aPluginName ) )
            {
                return plugin;
            }
        }
        throw new NoSuchElementException();
    }
}
