/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.intensiblast;

import de.intensicode.core.config.Configuration;
import de.intensicode.core.config.ConfigurationException;
import de.intensicode.gled.domain.LevelDataProvider;
import de.intensicode.gled.domain.SystemFactory;
import de.intensicode.gled.domain.TileProvider;



public class IntensiBlastFactory implements SystemFactory
{
    private Configuration iConfiguration;



    public IntensiBlastFactory() throws ConfigurationException
    {
        iConfiguration = new Configuration( "/IntensiBlast.config" );
    }

    // From SystemFactory

    public LevelDataProvider createLevelDataProvider()
    {
        return new IntensiBlastLevelDataProvider( iConfiguration );
    }

    public TileProvider createTileProvider()
    {
        return new IntensiBlastTileProvider( iConfiguration );
    }
}
