/************************************************************************/
/* GLED                 www.intensicode.de                December 2003 */
/************************************************************************/

package de.intensicode.gled.commands;

import de.intensicode.gled.domain.Project;
import de.intensicode.gled.domain.TileProvider;

import java.io.File;



public class LoadTileSet extends GledCommand
{
    private Project iProject;

    private File iTileSetFile;



    public LoadTileSet( Project aProject, File aTileSetFile )
    {
        iProject = aProject;
        iTileSetFile = aTileSetFile;
    }

    // From Command

    public void execute() throws Throwable
    {
        iUserInterface.showStatus( "Loading tile setFrom" );

        try
        {
            TileProvider tileGenerator = iProject.getSystemFactory().createTileProvider();
            tileGenerator.load( iTileSetFile );

            iProject.setTileSetFile( iTileSetFile );
            iProject.setTileProvider( tileGenerator );

            iUserInterface.showStatus( "Tile set loaded" );
            iCommandable.execute( new ShowStatusMessage( "Tile set loaded from " + iTileSetFile ) );
        }
        catch ( Throwable t )
        {
            iUserInterface.showStatus( "Failed loading tile set" );
            iCommandable.execute( new ShowErrorMessage( "Failed loading tile set", t ) );
        }
    }
}
