/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.gui;

import de.intensicode.core.logging.Log;
import de.intensicode.gled.core.GledApplication;
import de.intensicode.gled.core.GledPreferences;
import de.intensicode.gled.core.LevelDrawer;
import de.intensicode.gled.domain.*;
import de.intensicode.mui.MUIAction;
import de.intensicode.mui.MUIComponent;
import de.intensicode.mui.MUIList;
import de.intensicode.mui.OnActionListener;

import java.awt.Dimension;
import java.awt.event.ComponentEvent;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.EventObject;



public class LevelSelectorView extends MUIList implements LevelDataContainerListener, TileProviderListener, OnActionListener
{
    private Log iLog = Log.getLog();

    private GledPreferences iPreferences;

    private LevelDataContainer iLevelDataContainer;

    private TileProviderHandler iTileContainer;

    private LevelSelection iLevelSelection;

    private Dimension iThumbnailSize;

    private LevelDrawer iLevelDrawer;

    private ArrayList /*BufferedImage*/ iThumbnails;

    private ThumbnailComponent[] iThumbnailArray;

    private Dimension iDesiredThumbnailSize;

    private boolean iShowingLevelNames = false;

    private boolean iAmUpdating;



    public LevelSelectorView( GledApplication aApplication )
    {
        this( aApplication, new Dimension( -1, -1 ) );
    }

    public LevelSelectorView( GledApplication aApplication, Dimension aThumbnailSize )
    {
        iPreferences = GledPreferences.getInstance();

        iLevelDataContainer = aApplication.getLevelDataContainer();
        iTileContainer = aApplication.getTileContainer();
        iLevelSelection = aApplication.getLevelSelection();

        iThumbnailSize = aThumbnailSize;
        iLevelDrawer = new LevelDrawer( iTileContainer );
        iThumbnails = new ArrayList();
        iDesiredThumbnailSize = new Dimension( iJava.getWidth(), iJava.getWidth() );

        iLevelDataContainer.addListener( this );
        iTileContainer.addListener( this );

        setAction( ON_SELECTION, this );
    }

    public boolean isShowingLevelNames()
    {
        return iShowingLevelNames;
    }

    public void setShowingLevelNames( boolean aShowingFlag )
    {
        iShowingLevelNames = aShowingFlag;

        if ( iThumbnailArray == null )
        {
            return;
        }

        if ( iShowingLevelNames )
        {
            for ( int idx = 0; idx < iThumbnailArray.length; ++idx )
            {
                iThumbnailArray[ idx ].showTitle();
            }
        }
        else
        {
            for ( int idx = 0; idx < iThumbnailArray.length; ++idx )
            {
                iThumbnailArray[ idx ].hideTitle();
            }
        }
        iJava.repaint( 250 );
    }

    // From LevelDataContainerListener

    public void onLevelDataChanged()
    {
        iAmUpdating = true;

        if ( allDataAvailable() )
        {
            updateThumbnailSizeIfNecessary();
            if ( thumbnailSizeValid() )
            {
                prepareThumbnails();
                setData( iThumbnailArray );
                redrawThumbnails();
            }
        }
        else
        {
            clearData();
        }

        iAmUpdating = false;

        iJava.repaint( 250 );
    }

    public void onLevelDataChanged( int aLevelIndex )
    {
        iAmUpdating = true;

        int levels = iLevelDataContainer.getNumberOfLevels();
        if ( aLevelIndex >= 0 && aLevelIndex < levels )
        {
            if ( aLevelIndex < iThumbnails.size() && thumbnailSizeValid() )
            {
                LevelData data = iLevelDataContainer.getLevelData( aLevelIndex );
                iLevelDrawer.drawLevel( data, getThumbnail( aLevelIndex ), iThumbnailSize );
            }
        }

        iAmUpdating = false;

        iList.repaint( 2500 );
    }

    // From TileProviderListener

    public void onTileProviderChanged()
    {
        iAmUpdating = true;

        if ( allDataAvailable() )
        {
            updateThumbnailSizeIfNecessary();
            if ( thumbnailSizeValid() )
            {
                prepareThumbnails();
                setData( iThumbnailArray );
                redrawThumbnails();
            }
        }
        else
        {
            clearData();
        }

        iAmUpdating = false;

        iJava.repaint( 250 );
    }

    // From ComponentListener

    public void componentResized( ComponentEvent aEvent )
    {
        iDesiredThumbnailSize.width = Math.max( iJava.getWidth(), 32 );
        iDesiredThumbnailSize.height = Math.max( iJava.getWidth(), 32 );

        iList.setFixedCellWidth( iDesiredThumbnailSize.width );
        iList.setFixedCellHeight( iDesiredThumbnailSize.height );

        if ( allDataAvailable() )
        {
            updateThumbnailSizeIfNecessary();
            if ( thumbnailSizeValid() )
            {
                redrawThumbnails();
            }
        }
        iJava.repaint( 250 );
    }

    // From OnActionListener

    public void onAction( MUIComponent comp, MUIAction action, EventObject event )
    {
        if ( iAmUpdating )
        {
            return;
        }

        iLevelSelection.setLevelIndex( iList.getSelectedIndex() );
    }



    // Implementation

    private boolean allDataAvailable()
    {
        if ( iLevelDataContainer.getNumberOfLevels() == 0 )
        {
            return false;
        }
        if ( iTileContainer.getNumberOfLayers() == 0 )
        {
            return false;
        }
        return true;
    }

    private void updateThumbnailSizeIfNecessary()
    {
        iDesiredThumbnailSize.width = iJava.getWidth();
        iDesiredThumbnailSize.height = iJava.getWidth();

        if ( iThumbnailSize.width == -1 || iThumbnailSize.height == -1 )
        {
            Dimension levelSize = iLevelDataContainer.getLevelSize();
            Dimension tileSize = iTileContainer.getTileSize();

            int width = levelSize.width * tileSize.width;
            int height = levelSize.height * tileSize.height;

            if ( width > 0 && height > 0 )
            {
                iThumbnailSize.width = width;
                iThumbnailSize.height = height;
            }
        }
    }

    private boolean thumbnailSizeValid()
    {
        return iThumbnailSize.width > 0 && iThumbnailSize.height > 0;
    }

    private BufferedImage getThumbnail( int aLevelIndex )
    {
        return ( BufferedImage ) iThumbnails.get( aLevelIndex );
    }

    private void prepareThumbnails()
    {
        int levels = iLevelDataContainer.getNumberOfLevels();

        int width = iThumbnailSize.width;
        int height = iThumbnailSize.height;

        while ( iThumbnails.size() < levels )
        {
            iThumbnails.add( new BufferedImage( width, height, iPreferences.getImageType() ) );
        }
        resizeThumbnailsIfNecessary( width, height );

        if ( iThumbnailArray == null || iThumbnailArray.length != levels )
        {
            iThumbnailArray = new ThumbnailComponent[ levels ];
        }
        updateThumbnailsArray();
    }

    private void resizeThumbnailsIfNecessary( int aWidth, int aHeight )
    {
        for ( int idx = 0; idx < iThumbnails.size(); idx++ )
        {
            BufferedImage thumbnail = ( BufferedImage ) iThumbnails.get( idx );

            boolean badSize = false;
            if ( thumbnail.getWidth() != aWidth )
            {
                badSize = true;
            }
            else if ( thumbnail.getHeight() != aHeight )
            {
                badSize = true;
            }

            if ( badSize )
            {
                iThumbnails.remove( idx );
                iThumbnails.add( idx, new BufferedImage( aWidth, aHeight, iPreferences.getImageType() ) );
            }
        }
    }

    private void updateThumbnailsArray()
    {
        for ( int idx = 0; idx < iThumbnailArray.length; idx++ )
        {
            BufferedImage thumbnail = ( BufferedImage ) iThumbnails.get( idx );
            if ( iThumbnailArray[ idx ] == null )
            {
                LevelData levelData = iLevelDataContainer.getLevelData( idx );
                iThumbnailArray[ idx ] = new ThumbnailComponent( levelData.getOptions(), thumbnail, iShowingLevelNames );
            }
            else
            {
                iThumbnailArray[ idx ].setImage( thumbnail );
            }
        }
    }

    private void redrawThumbnails()
    {
        iLog.info( "Redrawing level selector thumbnails" );

        int levels = iLevelDataContainer.getNumberOfLevels();
        for ( int idx = 0; idx < levels; idx++ )
        {
            BufferedImage thumbnail = ( BufferedImage ) iThumbnails.get( idx );
            LevelData data = iLevelDataContainer.getLevelData( idx );
            iLevelDrawer.drawLevel( data, thumbnail, iThumbnailSize );
        }
    }

    private void clearData()
    {
        iThumbnailArray = null;
        setData( new Object[ 0 ] );
    }
}
