/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.actions;

import de.intensicode.mui.MUIUtils;

import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

import javax.swing.Action;
import javax.swing.KeyStroke;



public class ZoomAsNeededAction extends GledAction
{
    public ZoomAsNeededAction()
    {
        putValue( Action.NAME, "Zoom as needed" );
        putValue( Action.SHORT_DESCRIPTION, "Zoom level editor view as needed" );
        putValue( Action.SMALL_ICON, MUIUtils.getIcon( "/icons/zoomFit.png" ) );
        putValue( Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke( KeyEvent.VK_N, KeyEvent.ALT_DOWN_MASK ) );
    }

    // From ActionListener

    public void actionPerformed( ActionEvent e )
    {

    }
}
