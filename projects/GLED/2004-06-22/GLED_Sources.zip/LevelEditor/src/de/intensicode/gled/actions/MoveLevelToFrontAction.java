/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.actions;

import de.intensicode.gled.commands.MoveLevelToFront;
import de.intensicode.mui.MUIUtils;

import java.awt.event.ActionEvent;

import javax.swing.Action;



public class MoveLevelToFrontAction extends GledAction
{
    public MoveLevelToFrontAction()
    {
        putValue( Action.NAME, "Move level to front" );
        putValue( Action.SHORT_DESCRIPTION, "Move level to front" );
        putValue( Action.SMALL_ICON, MUIUtils.getIcon( "/icons/up.png" ) );
    }

    // From ActionListener

    public void actionPerformed( ActionEvent aEvent )
    {
        iMainFrame.addCommand( new MoveLevelToFront() );
    }
}
