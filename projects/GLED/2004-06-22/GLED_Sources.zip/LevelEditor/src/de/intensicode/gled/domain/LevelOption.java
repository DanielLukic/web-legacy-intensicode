/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.domain;



/**
 *
 */
public interface LevelOption
{
    static final int KBoolean = 0;

    static final int KInteger = 1;

    static final int KString = 2;



    int getType();

    String getName();

    Object getValue();

    void setValue( Object aNewValue );

    BooleanExtension getBooleanExtension();

    IntegerExtension getIntegerExtension();

    StringExtension getStringExtension();



    public interface BooleanExtension
    {
        boolean getBooleanValue();
    }



    public interface IntegerExtension
    {
        int getMinValue();

        int getMaxValue();

        int getIntegerValue();
    }



    public interface StringExtension
    {
        int getMaxLength();

        String getStringValue();
    }
}
