/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.commands;

import de.intensicode.gled.domain.LevelDataContainer;
import de.intensicode.gled.domain.LevelSelection;
import de.intensicode.gled.gui.LevelSelectorView;



public class AddNewLevel extends GledCommand
{
    public void execute() throws Throwable
    {
        LevelDataContainer container = iApplication.getLevelDataContainer();
        LevelSelection levelSelection = iApplication.getLevelSelection();

        levelSelection.unselect();
        container.addNewLevel();
        levelSelection.setLevelIndex( container.getNumberOfLevels() - 1 );
    }
}
