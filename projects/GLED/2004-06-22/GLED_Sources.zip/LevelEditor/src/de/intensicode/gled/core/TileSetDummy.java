/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.core;

import de.intensicode.gled.domain.BlockData;
import de.intensicode.gled.domain.Tile;
import de.intensicode.gled.domain.TileSet;

import java.io.File;
import java.io.IOException;



class TileSetDummy implements TileSet
{
    private TileDummy iTileDummy = new TileDummy();



    // From TileSet

    public void load( File aTileSetFile ) throws IOException
    {

    }

    public int getNumberOfTiles()
    {
        return 0;
    }

    public int getTilesPerRow()
    {
        return 0;
    }

    public int getTilesPerColumn()
    {
        return 0;
    }

    public Tile getTile( int aIdx )
    {
        return iTileDummy;
    }

    public Tile getTile( BlockData aBlockID )
    {
        return iTileDummy;
    }

    public boolean isEmpty( BlockData aBlockData )
    {
        return true;
    }

    public boolean needsAlphaBlit()
    {
        return false;
    }
}
