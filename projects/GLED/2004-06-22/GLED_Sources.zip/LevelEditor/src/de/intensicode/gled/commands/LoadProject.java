/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.commands;

import de.intensicode.core.config.ConfigurationException;
import de.intensicode.gled.core.GledProject;
import de.intensicode.gled.core.ProjectInfo;
import de.intensicode.gled.domain.Project;

import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;



public class LoadProject extends GledCommand
{
    private File iProjectFile;



    public LoadProject( String aProjectFileName )
    {
        iProjectFile = new File( aProjectFileName );
    }

    public LoadProject( File aProjectFile )
    {
        iProjectFile = aProjectFile;
    }

    // From Command

    public void execute() throws ConfigurationException
    {
        iUserInterface.showStatus( "Loading project" );

        try
        {
            FileInputStream file = new FileInputStream( iProjectFile );
            ObjectInputStream in = new ObjectInputStream( file );
            try
            {
                iUserInterface.showStatus( "Loading project data" );

                ProjectInfo info = ( ProjectInfo ) in.readObject();

                Project temp = new GledProject( info.getPlugin() );
                iApplication.setProjectFile( null );
                iApplication.setProject( temp );

                Project newProject = new GledProject( info );

                File tileSetFile = newProject.getTileSetFile();
                if ( tileSetFile != null )
                {
                    iCommandable.execute( new LoadTileSet( newProject, tileSetFile ) );
                }
                File levelDataFile = newProject.getLevelDataFile();
                if ( levelDataFile != null )
                {
                    iCommandable.execute( new LoadLevelData( newProject, levelDataFile ) );
                }

                iApplication.setProjectFile( iProjectFile );
                iApplication.setProject( newProject );
            }
            finally
            {
                in.close();
            }

            iUserInterface.showStatus( "Project loaded" );
            iCommandable.execute( new ShowStatusMessage( "Project loaded from " + iProjectFile ) );
        }
        catch ( Throwable t )
        {
            iUserInterface.showStatus( "Failed loading project" );
            iCommandable.execute( new ShowErrorMessage( "Failed loading project", t ) );
        }
    }
}
