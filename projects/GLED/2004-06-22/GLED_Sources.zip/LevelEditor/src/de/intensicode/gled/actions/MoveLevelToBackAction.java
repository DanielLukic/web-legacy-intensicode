/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.actions;

import de.intensicode.gled.commands.MoveLevelToBack;
import de.intensicode.mui.MUIUtils;

import java.awt.event.ActionEvent;

import javax.swing.Action;



public class MoveLevelToBackAction extends GledAction
{
    public MoveLevelToBackAction()
    {
        putValue( Action.NAME, "Move level to back" );
        putValue( Action.SHORT_DESCRIPTION, "Move level to back" );
        putValue( Action.SMALL_ICON, MUIUtils.getIcon( "/icons/down.png" ) );
    }

    // From ActionListener

    public void actionPerformed( ActionEvent aEvent )
    {
        iMainFrame.addCommand( new MoveLevelToBack() );
    }
}
