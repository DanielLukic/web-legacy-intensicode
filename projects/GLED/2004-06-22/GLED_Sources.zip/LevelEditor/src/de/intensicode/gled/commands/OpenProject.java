/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.commands;

import de.intensicode.core.logging.Log;
import de.intensicode.gled.util.GledFileFilter;

import java.io.File;

import javax.swing.JFileChooser;
import javax.swing.filechooser.FileFilter;



public class OpenProject extends GledCommand
{
    private static Log iLog = Log.getLog( "OpenProject" );

    private static JFileChooser iFileChooser;



    public OpenProject()
    {
        if ( iFileChooser == null )
        {
            iFileChooser = new JFileChooser( "data" );
            iFileChooser.setDialogTitle( "Open project" );
        }
    }

    // From Command

    public void execute() throws Throwable
    {
        updateFileFilters();

        int result = iFileChooser.showOpenDialog( iMainFrame );
        if ( result == JFileChooser.APPROVE_OPTION )
        {
            File selected = iFileChooser.getSelectedFile();
            iCommandable.execute( new LoadProject( selected ) );
        }
        else if ( result == JFileChooser.ERROR_OPTION )
        {
            iLog.error( "Error showing file chooser" );
        }
    }

    private void updateFileFilters()
    {
        FileFilter[] filters = iFileChooser.getChoosableFileFilters();
        for ( int idx = 0; idx < filters.length; idx++ )
        {
            iFileChooser.removeChoosableFileFilter( filters[ idx ] );
        }

        iFileChooser.addChoosableFileFilter( new GledFileFilter() );
        iFileChooser.setAcceptAllFileFilterUsed( true );
    }
}
