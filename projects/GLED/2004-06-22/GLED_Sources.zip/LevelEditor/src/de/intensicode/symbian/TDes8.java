/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.symbian;



public class TDes8
{
    private byte[] iData;

    private int iOffset;

    private int iLength;



    public TDes8( byte[] aData, int aOffset, int aLength )
    {
        iData = aData;
        iOffset = aOffset;
        iLength = aLength;
    }

    public TDes8( TDes8 aLevelData, int aOffset, int aLength )
    {
        iData = aLevelData.iData;
        iOffset = aLevelData.iOffset + aOffset;
        iLength = aLength;
    }

    public int length()
    {
        return iLength;
    }

    public byte at( int aOffset )
    {
        if ( aOffset < 0 || aOffset >= iLength )
        {
            throw new IndexOutOfBoundsException();
        }
        return iData[ iOffset + aOffset ];
    }

    public String getString( int aStart, int aLength )
    {
        return new String( iData, iOffset + aStart, aLength );
    }

    public TDes8 mid( int aStartIndex, int aLength )
    {
        return new TDes8( iData, iOffset + aStartIndex, aLength );
    }

    public void set( int aIndex, byte aValue )
    {
        iData[ iOffset + aIndex ] = aValue;
    }

    public void copy( TDes8 aSource )
    {
        for ( int idx = 0; idx < aSource.length(); ++idx )
        {
            set( idx, aSource.at( idx ) );
        }
    }
}
