/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.breakout;

import de.intensicode.core.config.Configuration;
import de.intensicode.core.logging.Log;
import de.intensicode.gled.domain.LevelData;
import de.intensicode.gled.domain.LevelDataProvider;
import de.intensicode.symbian.TDes8;
import de.intensicode.symbian.Mem;

import java.awt.Dimension;
import java.util.ArrayList;



public class BreakOutLevelDataProvider implements LevelDataProvider
{
    private Log iLog = Log.getLog();

    private ArrayList/*BreakOutLevelData*/ iLevelObjects = new ArrayList();

    int iLevelHeaderLines = 6;

    int iLevelTagLineLength = 20;

    Dimension iLevelSize = new Dimension( 11, 16 );

    int iCharsAtEOL = 3; /* | CR LF */

    int iCharsPerBlock = 3; /* TileID, SkinID, ExtraID */

    int iDataLinesPerLevel;

    int iDataBytesPerLine;

    int iLevelBytes;



    public BreakOutLevelDataProvider( Configuration aConfiguration )
    {
        iLevelHeaderLines = aConfiguration.getInt( "LevelData.LevelHeaderLines", iLevelHeaderLines );
        iLevelTagLineLength = aConfiguration.getInt( "LevelData.LevelTagLineLength", iLevelTagLineLength );
        iLevelSize.width = aConfiguration.getInt( "LevelData.LevelWidth", iLevelSize.width );
        iLevelSize.height = aConfiguration.getInt( "LevelData.LevelHeight", iLevelSize.height );
        iCharsAtEOL = aConfiguration.getInt( "LevelData.CharsAtEOL", iCharsAtEOL );
        iCharsPerBlock = aConfiguration.getInt( "LevelData.CharsPerBlock", iCharsPerBlock );

        iDataLinesPerLevel = iLevelHeaderLines + iLevelSize.height;
        iDataBytesPerLine = iCharsPerBlock * iLevelSize.width + iCharsAtEOL;
        iLevelBytes = iDataLinesPerLevel * iDataBytesPerLine;
    }

    public void load( byte[] aLevelData )
    {
        int numberOfLevels = aLevelData.length / iLevelBytes;

        iLog.info( "Loading " + numberOfLevels + " levels" );

//        boolean showErrorInfo = false;

        ArrayList levels = new ArrayList();
        for ( int idx = 0; idx < numberOfLevels; idx++ )
        {
//            try
            {
                TDes8 levelData = new TDes8( aLevelData, iLevelBytes * idx, iLevelBytes );
                BreakOutLevelData level = new BreakOutLevelData( this, idx + 1 );
                level.load( levelData );
                levels.add( level );
            }
//            catch ( Throwable t )
//            {
//                iLog.error( "Failed loading level " + idx, t );
//                showErrorInfo = true;
//            }
        }

        iLevelObjects.clear();
        iLevelObjects = levels;

//        if ( showErrorInfo )
//        {
//            // TODO: Show error info dialog
//        }
    }

    public byte[] save()
    {
        int numberOfLevels = iLevelObjects.size();
        byte[] result = new byte[ iLevelBytes * numberOfLevels ];
        for ( int idx = 0; idx < numberOfLevels; idx++ )
        {
            TDes8 levelData = new TDes8( result, iLevelBytes * idx, iLevelBytes );
            prepareForLevelData( levelData );

            BreakOutLevelData level = ( BreakOutLevelData ) getLevelData( idx );
            level.save( levelData );
        }

        return result;
    }

    // From LevelDataProvider

    public int getNumberOfLevels()
    {
        return iLevelObjects.size();
    }

    public Dimension getLevelSize()
    {
        return iLevelSize;
    }

    public LevelData getLevelData( int aIdx )
    {
        return ( LevelData ) iLevelObjects.get( aIdx );
    }

    public void addNewLevel()
    {
        iLevelObjects.add( new BreakOutLevelData( this, iLevelObjects.size() ) );
    }

    public void cloneLevel( int aSelected )
    {
        BreakOutLevelData destination = new BreakOutLevelData( this, aSelected + 1 );
        iLevelObjects.add( aSelected + 1, destination );

        copyLevel( aSelected, aSelected + 1);
    }

    public void copyLevel( int aSourceLevel, int aDestinationLevel )
    {
        BreakOutLevelData source = ( BreakOutLevelData ) getLevelData( aSourceLevel );
        BreakOutLevelData destination = ( BreakOutLevelData ) getLevelData( aDestinationLevel );
        destination.copy( source );

        updateLevelNumbers();
    }

    public void swapLevels( int aSourceLevel, int aDestinationLevel )
    {
        LevelData source = getLevelData( aSourceLevel );
        LevelData destination = getLevelData( aDestinationLevel );

        iLevelObjects.set( aSourceLevel, destination );
        iLevelObjects.set( aDestinationLevel, source );

        updateLevelNumbers();
    }

    public void deleteLevel( int aLevelIndex )
    {
        iLevelObjects.remove( aLevelIndex );

        updateLevelNumbers();
    }

    // From Implementation

    private void prepareForLevelData( TDes8 aLevelData )
    {
        Mem.Fill( aLevelData, iLevelBytes, ( byte ) '-' );

        for ( int idx = 0; idx < iDataLinesPerLevel; idx++ )
        {
            int offset = ( idx + 1 ) * iDataBytesPerLine - iCharsAtEOL;
            aLevelData.set( offset++, ( byte ) '|' );
            aLevelData.set( offset++, ( byte ) 0x0d );
            aLevelData.set( offset, ( byte ) 0x0a );
        }
    }

    private void updateLevelNumbers()
    {
        int numberOfLevels = iLevelObjects.size();
        for ( int idx = 0; idx < numberOfLevels; idx++ )
        {
            BreakOutLevelData level = ( BreakOutLevelData ) getLevelData( idx );
            level.setLevelNumber( idx + 1 );
        }
    }
}
