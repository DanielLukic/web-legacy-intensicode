/************************************************************************/
/* GLED                 www.intensicode.de                December 2003 */
/************************************************************************/

package de.intensicode.gled.commands;

import de.intensicode.gled.domain.Application;
import de.intensicode.gled.domain.UserInterface;
import de.intensicode.gled.MainFrame;
import de.intensicode.mui.AbstractCommand;
import de.intensicode.mui.Commandable;
import de.intensicode.mui.MUIStatus;

import javax.swing.JFrame;



public abstract class GledCommand extends AbstractCommand
{
    protected static Application iApplication;

    protected static Commandable iCommandable;

    protected static JFrame iMainFrame;

    protected static MUIStatus iStatusLog;

    protected static UserInterface iUserInterface;



    public static void init( Application aApplication, Commandable aCommandable )
    {
        iApplication = aApplication;
        iCommandable = aCommandable;
    }

    public static void setMainFrame( JFrame aMainFrame )
    {
        iMainFrame = aMainFrame;
    }

    public static void setStatusLog( MUIStatus aStatusLog )
    {
        iStatusLog = aStatusLog;
    }

    /**
     * Liefert einfach <code>false</code> um anzuzeigen, das das Kommando
     * nicht abgebrochen werden kann. Unterklassen sollten dies
     * ueberschreiben falls ein Abbruch des Kommandos moeglich ist.
     */
    public boolean abort()
    {
        return false;
    }

    public static void setUserInterface( UserInterface aUserInterface )
    {
        iUserInterface = aUserInterface;
    }
}
