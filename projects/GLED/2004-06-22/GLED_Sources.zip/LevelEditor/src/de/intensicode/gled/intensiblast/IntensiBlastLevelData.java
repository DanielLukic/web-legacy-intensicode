/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.intensiblast;

import de.intensicode.core.logging.Log;
import de.intensicode.gled.domain.BlockData;
import de.intensicode.gled.domain.LevelData;
import de.intensicode.gled.domain.LevelOptions;
import de.intensicode.gled.domain.TileSelection;
import de.intensicode.symbian.TDes8;

import java.awt.Dimension;



/**
 *
 */
class IntensiBlastLevelData implements LevelData
{
    private Log iLog = Log.getLog();

    private IntensiBlastLevelDataProvider iContainer;

    private IntensiBlastLevelOptions iOptions;

    private IntensiBlastBlockData[] iBlocks;

    private IntensiBlastBlockData[] iScrollBuffer;



    public IntensiBlastLevelData( IntensiBlastLevelDataProvider aContainer, int aLevelNumber )
    {
        iContainer = aContainer;

        iOptions = new IntensiBlastLevelOptions( aContainer, aLevelNumber );

        int numberOfBlocks = getLevelWidth() * getLevelHeight();
        iBlocks = new IntensiBlastBlockData[ numberOfBlocks ];
        iScrollBuffer = new IntensiBlastBlockData[ numberOfBlocks ];

        for ( int idx = 0; idx < numberOfBlocks; idx++ )
        {
            iBlocks[ idx ] = new IntensiBlastBlockData( iOptions );
            iScrollBuffer[ idx ] = new IntensiBlastBlockData( iOptions );
        }
    }

    public void setLevelNumber( int aIndex )
    {
        iOptions.setLevelNumber( aIndex );
    }

    public void load( TDes8 aLevelData )
    {
        iOptions.load( aLevelData );

        int width = getLevelWidth();
        int height = getLevelHeight();

        for ( int y = 0; y < height; y++ )
        {
            for ( int x = 0; x < width; x++ )
            {
                TDes8 blockData = getBlockData( aLevelData, x, y );
                try
                {
                    iBlocks[ x + y * width ].load( blockData );
                }
                catch ( IllegalArgumentException iaEx )
                {
                    iLog.error( iaEx );
                    iLog.error( "Invalid block data at " + x + ", " + y );
                    throw iaEx;
                }
            }
        }
    }

    public void save( TDes8 aLevelData )
    {
        iOptions.save( aLevelData );

        int width = getLevelWidth();
        int height = getLevelHeight();

        for ( int y = 0; y < height; y++ )
        {
            for ( int x = 0; x < width; x++ )
            {
                TDes8 blockData = getBlockData( aLevelData, x, y );
                iBlocks[ x + y * width ].save( blockData );
            }
        }
    }

    public void copy( IntensiBlastLevelData aSource )
    {
        byte[] temp = new byte[ iContainer.iLevelBytes ];
        TDes8 buffer = new TDes8( temp, 0, iContainer.iLevelBytes );

        aSource.save( buffer );
        load( buffer );
    }

    // From LevelData

    public LevelOptions getOptions()
    {
        return iOptions;
    }

    public int getLevelWidth()
    {
        return iContainer.getLevelSize().width;
    }

    public int getLevelHeight()
    {
        return iContainer.getLevelSize().height;
    }

    public BlockData getBlockData( int aX, int aY )
    {
        return iBlocks[ aX + aY * iContainer.iLevelSize.width ];
    }

    public void fillLevel( TileSelection aTileSelection )
    {
        if ( aTileSelection.isValid() == false )
        {
            iLog.warn( "Cannot fill level with invalid tile selection " + aTileSelection );
        }

        int layer = aTileSelection.getLayerIndex();
        int tile = aTileSelection.getTileIndex();

        Dimension iLevelSize = iContainer.getLevelSize();
        for ( int y = 0; y < iLevelSize.height; ++y )
        {
            for ( int x = 0; x < iLevelSize.width; ++x )
            {
                BlockData block = getBlockData( x, y );
                block.setTileIndex( layer, tile );
            }
        }
    }

    public void scrollData( int aDeltaX, int aDeltaY )
    {
        int width = getLevelWidth();
        int height = getLevelHeight();

        aDeltaX = aDeltaX % width;
        aDeltaY = aDeltaY % height;

        for ( int y = 0; y < height; y++ )
        {
            for ( int x = 0; x < width; x++ )
            {
                int xDest = ( x + aDeltaX + width ) % width;
                int yDest = ( y + aDeltaY + height ) % height;
                int xSource = ( x + width ) % width;
                int ySource = ( y + height ) % height;

                BlockData dest = iScrollBuffer[ xDest + yDest * width ];
                BlockData source = iBlocks[ xSource + ySource * width ];
                dest.setFrom( source );
            }
        }

        for ( int y = 0; y < height; y++ )
        {
            for ( int x = 0; x < width; x++ )
            {
                BlockData dest = iBlocks[ x + y * width ];
                BlockData source = iScrollBuffer[ x + y * width ];
                dest.setFrom( source );
            }
        }
    }

    // Implementation

    private TDes8 getBlockData( TDes8 aLevelData, int aX, int aY )
    {
        int offset = aX * iContainer.iCharsPerBlock;
        offset += aY * iContainer.iDataBytesPerLine;
        offset += iContainer.iLevelHeaderLines * iContainer.iDataBytesPerLine;

        return aLevelData.mid( offset, iContainer.iCharsPerBlock );
    }
}
