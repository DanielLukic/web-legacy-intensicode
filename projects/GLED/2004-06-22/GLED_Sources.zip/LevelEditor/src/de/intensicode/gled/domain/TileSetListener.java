/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.domain;



public interface TileSetListener
{
    void onTileSetChanged();
}
