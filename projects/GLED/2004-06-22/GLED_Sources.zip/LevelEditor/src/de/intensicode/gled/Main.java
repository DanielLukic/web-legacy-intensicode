/************************************************************************/
/* GLED                 www.intensicode.de                December 2003 */
/************************************************************************/

package de.intensicode.gled;

import de.intensicode.core.config.ConfigurationException;
import de.intensicode.core.logging.Log;
import de.intensicode.gled.core.GledApplication;

import java.io.File;
import java.io.IOException;



public class Main
{
    private GledApplication iApp = new GledApplication();

    private static Log iLog = Log.getLog( "Main" );



    public static void main( String[] args )
    {
        iLog.info( "Starting GLED" );
        try
        {
            File logDir = new File( "log" );
            logDir.mkdirs();

            new Main();
        }
        catch ( Throwable t )
        {
            t.printStackTrace();
            System.err.println( "ERROR: Failed starting GLED" );
            System.err.flush();
            System.exit( 10 );
        }
    }

    private Main() throws ConfigurationException
    {
        new MainFrame( iApp );
    }
}
