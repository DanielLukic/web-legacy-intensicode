/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.util;

import de.intensicode.gled.domain.LevelOption;



/**
 *
 */
public class StringLevelOption implements LevelOption, LevelOption.StringExtension
{
    private String iName;

    String iValue = new String();

    int iMaxLength;



    public StringLevelOption( String aName, int aMaxLength )
    {
        iName = aName;
        iMaxLength = aMaxLength;
    }

    // From LevelOption

    public int getType()
    {
        return KString;
    }

    public String getName()
    {
        return iName;
    }

    public Object getValue()
    {
        return iValue;
    }

    public void setValue( Object aNewValue )
    {
        iValue = ( String ) aNewValue;
        if ( iValue.length() > iMaxLength )
        {
            iValue = iValue.substring( 0, iMaxLength );
        }
    }

    public LevelOption.BooleanExtension getBooleanExtension()
    {
        throw new UnsupportedOperationException();
    }

    public LevelOption.IntegerExtension getIntegerExtension()
    {
        throw new UnsupportedOperationException();
    }

    public LevelOption.StringExtension getStringExtension()
    {
        return this;
    }

    // From StringExtension

    public int getMaxLength()
    {
        return iMaxLength;
    }

    public String getStringValue()
    {
        return iValue;
    }
}
