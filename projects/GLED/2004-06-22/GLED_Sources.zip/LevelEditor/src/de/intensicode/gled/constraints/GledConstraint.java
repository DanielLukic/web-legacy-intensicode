/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.constraints;

import de.intensicode.gled.actions.GledAction;

import java.util.ArrayList;



public abstract class GledConstraint
{
    protected ArrayList/*GledAction*/ iTargetActions = new ArrayList();



    public void addTargetAction( GledAction aAction )
    {
        iTargetActions.add( aAction );
    }

    // Protected Interface

    public void setEnabled( boolean aEnabledFlag )
    {
        for ( int idx = 0; idx < iTargetActions.size(); ++idx )
        {
            GledAction action = ( GledAction ) iTargetActions.get( idx );
            action.setEnabled( aEnabledFlag );
        }
    }
}
