/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.commands;

import de.intensicode.gled.domain.LevelDataContainer;
import de.intensicode.gled.domain.LevelSelection;



public class CloneCurrentLevel extends GledCommand
{
    public void execute() throws Throwable
    {
        LevelDataContainer container = iApplication.getLevelDataContainer();

        LevelSelection levelSelection = iApplication.getLevelSelection();
        if ( levelSelection.isValid() == false )
        {
            return;
        }

        int selected = levelSelection.getLevelIndex();

        levelSelection.unselect();
        container.cloneLevel( selected );
        levelSelection.setLevelIndex( selected + 1 );
    }
}
