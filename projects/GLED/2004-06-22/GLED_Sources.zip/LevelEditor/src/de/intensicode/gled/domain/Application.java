/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.domain;

import de.intensicode.gled.util.Plugins;

import java.io.File;



public interface Application extends Project
{
    File getProjectFile();

    void setProjectFile( File aFile );

    void setProject( Project aNewProject );

    TileProviderHandler getTileContainer();

    LevelDataContainer getLevelDataContainer();

    LayerSelection getLayerSelection();

    LevelSelection getLevelSelection();

    TileSelection getTileSelection();

    UserInterface getUserInterface();

    Plugins getPlugins();
}
