/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.core;

import de.intensicode.gled.domain.Tile;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Point;



class TileDummy implements Tile
{
    public void paintSized( Graphics aGc, Point aPos, Dimension aSize )
    {

    }

    public void paintScaled( Graphics aGc, Point aPos, Dimension aSize, int aPercentage )
    {
    }
}
