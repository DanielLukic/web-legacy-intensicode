/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.intensiblast;

import de.intensicode.gled.domain.LevelOption;
import de.intensicode.gled.domain.LevelOptions;
import de.intensicode.gled.util.StringLevelOption;
import de.intensicode.gled.util.BooleanLevelOption;
import de.intensicode.gled.util.IntegerLevelOption;
import de.intensicode.symbian.TDes8;
import de.intensicode.symbian.Mem;
import de.intensicode.core.Assert;



/**
 *
 */
class IntensiBlastLevelOptions implements LevelOptions
{
    private IntensiBlastLevelDataProvider iContainer;

    private int iLevelNumber;

    private String iLevelName;

    private static final int KTagLine1 = 0;

    private static final int KTagLine2 = 1;

    private static final int KBackgroundBlocks = 2;

    private static final int KAnimationBlocks = 3;

    private static final int KLevelTime = 4;

    private static final int KExtraProbability = 5;

    private static final int KBaseSkinIndex = 6;

    private static final int KNumberOfOptions  = 7;

    private LevelOption[] iOptions = new LevelOption[ KNumberOfOptions ];



    public IntensiBlastLevelOptions( IntensiBlastLevelDataProvider aContainer, int aLevelNumber )
    {
        iContainer = aContainer;
        iLevelNumber = aLevelNumber;
        iLevelName = Integer.toString( iLevelNumber );

        iOptions[ KTagLine1 ] = new StringLevelOption( "Tagline 1", 20 );
        iOptions[ KTagLine2 ] = new StringLevelOption( "Tagline 2", 20 );
        iOptions[ KBackgroundBlocks ] = new BooleanLevelOption( "Background is blocking", true );
        iOptions[ KAnimationBlocks ] = new BooleanLevelOption( "Animation is blocking", true );
        iOptions[ KLevelTime ] = new IntegerLevelOption( "Level Time", 0, 60 );
        iOptions[ KExtraProbability ] = new IntegerLevelOption( "Extras Propability", 0, 100 );
        iOptions[ KBaseSkinIndex ] = new IntegerLevelOption( "Base Skin Index", 0, 3 );

        Assert.MAKE_SURE( KNumberOfOptions == iOptions.length );
    }

    public void setLevelNumber( int aIndex )
    {
        iLevelNumber = aIndex;
        iLevelName = Integer.toString( aIndex );
    }

    public void load( TDes8 aLevelData )
    {
        loadTagLines( aLevelData );
        loadOptions( aLevelData );
    }

    public void save( TDes8 aLevelData )
    {
        saveTagLines( aLevelData );
        saveOptions( aLevelData );
    }

    public int getBaseSkinIndex()
    {
        return retrieveIntegerOption( KBaseSkinIndex );
    }

    // From LevelOptions

    public String getLevelName()
    {
        return iLevelName;
    }

    public int getNumberOfOptions()
    {
        return iOptions.length;
    }

    public LevelOption getLevelOption( int aIndex )
    {
        return iOptions[ aIndex ];
    }

    // Implementation

    private void loadTagLines( TDes8 aLevelData )
    {
        String tagLine1 = extractString( aLevelData, iContainer.iDataBytesPerLine * 1, "|" ).trim();
        String tagLine2 = extractString( aLevelData, iContainer.iDataBytesPerLine * 2, "|" ).trim();

        iOptions[ KTagLine1 ].setValue( tagLine1 );
        iOptions[ KTagLine2 ].setValue( tagLine2 );
    }

    private void loadOptions( TDes8 aLevelData )
    {
        iOptions[ KBackgroundBlocks ].setValue( new Boolean( false ) );
        iOptions[ KAnimationBlocks ].setValue( new Boolean( false ) );
        iOptions[ KLevelTime ].setValue( new Integer( 25 ) );
        iOptions[ KExtraProbability ].setValue( new Integer( 80 ) );
        iOptions[ KBaseSkinIndex ].setValue( new Integer( 0 ) );

        TDes8 options = aLevelData.mid( iContainer.iDataBytesPerLine * 4, iContainer.iDataBytesPerLine );
        for ( int idx = 0; idx < iContainer.iDataBytesPerLine - iContainer.iCharsAtEOL; idx++ )
        {
            int code = Character.toUpperCase( ( char ) options.at( idx ) );
            if ( code == 'B' )
            {
                iOptions[ KBackgroundBlocks ].setValue( new Boolean( true ) );
            }
            else if ( code == 'A' )
            {
                iOptions[ KAnimationBlocks ].setValue( new Boolean( true ) );
            }
            else if ( code == 'T' )
            {
                String value = extractString( options, idx + 1, " -|" );
                iOptions[ KLevelTime ].setValue( new Integer( value ) );

                // skip the value
                idx += value.length();
            }
            else if ( code == 'P' )
            {
                String value = extractString( options, idx + 1, " -|" );
                iOptions[ KExtraProbability ].setValue( new Integer( value ) );

                // skip the value
                idx += value.length();
            }
            else if ( code >= '0' && code <= '3' )
            {
                iOptions[ KBaseSkinIndex ].setValue( new Integer( code - '0' ) );
            }
            else if ( code == ' ' || code == '-' )
            {
                continue;
            }
            else
            {
                throw new IllegalArgumentException( "Unrecognized level option: " + ( char ) code + " (Code: " + code + ")" );
            }
        }
    }

    private void saveTagLines( TDes8 aLevelData )
    {
        String tagLine1 = padTagLineWithSpaces( iOptions[ KTagLine1 ].getValue().toString() );
        String tagLine2 = padTagLineWithSpaces( iOptions[ KTagLine2 ].getValue().toString() );

        TDes8 line1 = new TDes8( aLevelData, iContainer.iDataBytesPerLine * 1, iContainer.iDataBytesPerLine );
        TDes8 line2 = new TDes8( aLevelData, iContainer.iDataBytesPerLine * 2, iContainer.iDataBytesPerLine );
        for ( int idx = 0; idx < iContainer.iLevelTagLineLength; ++idx )
        {
            line1.set( idx, ( byte ) tagLine1.charAt( idx ) );
            line2.set( idx, ( byte ) tagLine2.charAt( idx ) );
        }

        line1.set( iContainer.iLevelTagLineLength, ( byte ) '|' );
        line2.set( iContainer.iLevelTagLineLength, ( byte ) '|' );
    }

    private void saveOptions( TDes8 aLevelData )
    {
        TDes8 options = aLevelData.mid( iContainer.iDataBytesPerLine * 4, iContainer.iDataBytesPerLine - iContainer.iCharsAtEOL );
        Mem.Fill( options, options.length(), ( byte ) ' ' );

        int writeIndex = 0;

        writeIndex = appendNumber( options, writeIndex, retrieveIntegerOption( KBaseSkinIndex ) );

        options.set( writeIndex++, ( byte ) ' ' );

        options.set( writeIndex++, retrieveBooleanOption( KAnimationBlocks ) ? ( byte ) 'A' : ( byte ) ' ' );
        options.set( writeIndex++, retrieveBooleanOption( KBackgroundBlocks ) ? ( byte ) 'B' : ( byte ) ' ') ;

        options.set( writeIndex++, ( byte ) ' ' );

        options.set( writeIndex++, ( byte ) 'T' );
        writeIndex = appendNumber( options, writeIndex, retrieveIntegerOption( KLevelTime ) );

        options.set( writeIndex++, ( byte ) ' ' );

        options.set( writeIndex++, ( byte ) 'P' );
        writeIndex = appendNumber( options, writeIndex, retrieveIntegerOption( KLevelTime ) );
    }

    private boolean retrieveBooleanOption( int aOptionIndex )
    {
        Boolean value = ( Boolean ) iOptions[ aOptionIndex ].getValue();
        return value.booleanValue();
    }

    private int retrieveIntegerOption( int aOptionIndex )
    {
        Integer value = ( Integer ) iOptions[ aOptionIndex ].getValue();
        return value.intValue();
    }

    private String extractString( TDes8 aDataLine, int aStartIndex, String aDelimeterList )
    {
        StringBuffer buffer = new StringBuffer();
        for ( ; ; )
        {
            int code = aDataLine.at( aStartIndex );
            if ( aDelimeterList.indexOf( code ) != -1 )
            {
                break;
            }
            else if ( buffer.length() == iContainer.iDataBytesPerLine - iContainer.iCharsAtEOL )
            {
                break;
            }
            buffer.append( ( char ) code );
            ++aStartIndex;
        }
        return buffer.toString();
    }

    private String padTagLineWithSpaces( String aTagLine )
    {
        StringBuffer temp = new StringBuffer( aTagLine );
        while ( temp.length() < iContainer.iLevelTagLineLength )
        {
            temp.append( ' ' );
        }

        String result = temp.toString();
        return result.substring( 0, iContainer.iLevelTagLineLength );
    }

    private int appendNumber( TDes8 aBuffer, int aStartIndex, int aNumber )
    {
        String number = Integer.toString( aNumber );
        for ( int idx = 0; idx < number.length(); ++idx )
        {
            aBuffer.set( aStartIndex++, ( byte ) number.charAt( idx ) );
        }
        return aStartIndex;
    }
}
