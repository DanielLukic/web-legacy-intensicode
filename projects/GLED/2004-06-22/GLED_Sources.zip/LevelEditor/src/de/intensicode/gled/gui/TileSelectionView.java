/************************************************************************/
/* GLED                 www.intensicode.de                December 2003 */
/************************************************************************/

package de.intensicode.gled.gui;

import de.intensicode.gled.domain.*;
import de.intensicode.gled.core.GledApplication;
import de.intensicode.mui.*;

import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.AlphaComposite;



public class TileSelectionView extends MUIGroupH implements TileProviderListener, TileSelectionListener
{
    private TileProviderHandler iTileProviderHandler;

    private TileSelection iTileSelection;

    private MUILabel iLayerSelection = new MUILabel( "Nothing selected" );

    private int iLayerIndex;

    private int iTileIndex;



    public TileSelectionView( GledApplication aApplication )
    {
        iTileProviderHandler = aApplication.getTileContainer();
        iTileProviderHandler.addListener( this );

        iTileSelection = aApplication.getTileSelection();
        iTileSelection.addListener( this );

        TileSelectionCanvas canvas = new TileSelectionCanvas();

        MUIConstraints constraints = canvas.getConstraints();
        constraints.setWeights( 0.25, 1.0 );
        constraints.iStretchToFitH = false;

        addChild( canvas );
        addChild( iLayerSelection );

        onTileProviderChanged();
    }

    // From TileProviderListener

    public void onTileProviderChanged()
    {
        repaint( 250 );
    }

    // From TileSelectionListener

    public void onTileSelectionChanged( TileSelection aTileSelection )
    {
        iLayerIndex = aTileSelection.getLayerIndex();
        iTileIndex = aTileSelection.getTileIndex();

        if ( iTileSelection.isValid() )
        {
            iLayerSelection.setText( "Layer " + iLayerIndex );
        }
        else
        {
            iLayerSelection.setText( "No selection" );
        }

        repaint( 250 );
    }



    private /*inner*/ class TileSelectionCanvas extends MUICanvas implements Paintable
    {
        private Point iPosition = new Point( 0, 0 );



        private TileSelectionCanvas()
        {
            addPaintable( this );
        }

        // From Paintable

        public void paintInto( Graphics2D aGc, Dimension aTargetSize )
        {
            if ( iTileSelection.isValid() )
            {
                TileSet tileSet = iTileProviderHandler.getLayerTileSet( iLayerIndex );
                Tile tile = tileSet.getTile( iTileIndex );
                aGc.setComposite( AlphaComposite.Src );
                tile.paintSized( aGc, iPosition, aTargetSize );
            }
        }
    }
}
