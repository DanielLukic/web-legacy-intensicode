/************************************************************************/
/* GLED                 www.intensicode.de                December 2003 */
/************************************************************************/

package de.intensicode.gled.gui;

import de.intensicode.gled.domain.*;
import de.intensicode.gled.core.GledApplication;
import de.intensicode.mui.MUICanvas;
import de.intensicode.mui.Paintable;

import java.awt.*;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.image.BufferedImage;



public class TileChooserCanvas extends MUICanvas implements SelectionCursorListener, TileSetListener, Paintable, TileSelectionListener
{
    private Dimension iInsets = new Dimension( 2, 2 );

    private TileProviderHandler iTileProviderHandler;

    private TileSelection iTileSelection;

    private TileSetHandler iTileSet;

    private int iLayerIndex;

    private CenteredTextOverlay iTextOverlay;

    private Dimension iVisibleSize = null;

    private Dimension iDesiredSize = null;

    private int iTilesPerRow;

    private int iTilesPerColumn;

    private SelectionCursor iSelectionCursor;

    private BufferedImage iPaintBuffer;

    private boolean iTileDataChanged = true;



    public TileChooserCanvas( GledApplication aApplication, int aLayerIndex )
    {
        iTileProviderHandler = aApplication.getTileContainer();

        iTileSelection = aApplication.getTileSelection();
        iTileSelection.addListener( this );

        iTileSet = iTileProviderHandler.getLayerTileSetHandler( aLayerIndex );
        iTileSet.addListener( this );

        iLayerIndex = aLayerIndex;

        iTilesPerRow = 1;
        iTilesPerColumn = 1;

        iSelectionCursor = new SelectionCursor( this );

        addPaintable( this );
        addPaintable( iSelectionCursor );

        setMouseListener( iSelectionCursor );
        setMouseMotionListener( iSelectionCursor );

        setClearBeforePaint( false );

        iJava.addComponentListener( new SizeConstrainer() );
    }

    public int getTilesPerRow()
    {
        return iTilesPerRow;
    }

    // From MUIObject

    public void setVisibleRect( Rectangle aBounds )
    {
        super.setVisibleRect( aBounds );

        iVisibleSize = aBounds.getSize();
    }

    // From SelectionCursorListener

    public void onNewSelection( int aX, int aY )
    {
        int tileIndex = aX + aY * iTilesPerRow;
        iTileSelection.setTo( iLayerIndex, tileIndex );
        iSelectionCursor.setIndex( tileIndex );
    }

    public void onAlternativeSelection( int aX, int aY )
    {
        onNewSelection( aX, aY );
    }

    // From TileSetListener

    public void onTileSetChanged()
    {
        iTileDataChanged = true;

        int tiles = iTileSet.getNumberOfTiles();
        if ( tiles == 0 )
        {
            return;
        }

        iTilesPerRow = iTileSet.getTilesPerRow();
        iTilesPerColumn = ( tiles + iTilesPerRow - 1 ) / iTilesPerRow;

        Dimension pixelSize = iTileProviderHandler.getTileSize();
        int factor = pixelSize.width * 256 / pixelSize.height;

        Dimension tileSize = new Dimension();
        tileSize.width = ( iJava.getWidth() - ( iTilesPerRow + 1 ) * iInsets.width ) / iTilesPerRow;
        tileSize.height = tileSize.width * 256 / factor;

        if ( iDesiredSize == null )
        {
            iDesiredSize = new Dimension();
        }
        iDesiredSize.width = iJava.getWidth();
        iDesiredSize.height = ( tileSize.height + iInsets.height ) * iTilesPerColumn + iInsets.height;

        if ( iDesiredSize.height == 0 )
        {
            iDesiredSize.height = iDesiredSize.width;
        }
        if ( iVisibleSize != null && iVisibleSize.height > iDesiredSize.height )
        {
            iDesiredSize.height = iVisibleSize.height;
        }

        if ( getSize().equals( iDesiredSize ) == false )
        {
//            if ( Math.abs( getSize().height - iDesiredSize.height ) > 1 )
//            {
//                setSize( iDesiredSize );
//            }
//            else if ( Math.abs( getSize().width - iDesiredSize.width ) > 1 )
//            {
//                setSize( iDesiredSize );
//            }
        }

        iJava.repaint( 250 );
    }

    // From TileSelectionListener

    public void onTileSelectionChanged( TileSelection aTileSelection )
    {
        if ( iLayerIndex == aTileSelection.getLayerIndex() )
        {
            iSelectionCursor.setIndex( aTileSelection.getTileIndex() );
            iSelectionCursor.setEnabled( true );
        }
        else
        {
            iSelectionCursor.setEnabled( false );
        }

        iJava.repaint( 250 );
    }

    // From Paintable

    public void paintInto( Graphics2D aGc, Dimension aTargetSize )
    {
        int tiles = iTileSet.getNumberOfTiles();

        iTilesPerRow = iTileSet.getTilesPerRow();
        if ( iTilesPerRow == 0 )
        {
            showNoDataMessage( aGc, aTargetSize );
            return;
        }

        iTilesPerColumn = ( tiles + iTilesPerRow - 1 ) / iTilesPerRow;

        iSelectionCursor.setGridSize( iTilesPerRow, iTilesPerColumn );
        iSelectionCursor.setSelectionSize( aTargetSize );

        if ( tiles == 0 )
        {
            showNoDataMessage( aGc, aTargetSize );
            return;
        }

        updatePaintBufferIfNecessary( aTargetSize, aGc.getBackground() );

        int width = aTargetSize.width;
        int height = aTargetSize.height;
        aGc.drawImage( iPaintBuffer, 0, 0, width, height, 0, 0, width, height, null );
    }

    // Implementation

    private void showNoDataMessage( Graphics2D aGc, Dimension aTargetSize )
    {
        if ( iTextOverlay == null )
        {
            iTextOverlay = new CenteredTextOverlay( "NO TILES LOADED" );
        }

        iTextOverlay.paintInto( aGc, aTargetSize );
    }

    private void updatePaintBufferIfNecessary( Dimension aTargetSize, Color aBackgroundColor )
    {
        int width = aTargetSize.width;
        int height = aTargetSize.height;

        if ( iPaintBuffer == null )
        {
            iPaintBuffer = new BufferedImage( width, height, BufferedImage.TYPE_INT_RGB );
            iTileDataChanged = true;
        }
        else if ( iPaintBuffer.getWidth() < width || iPaintBuffer.getHeight() < height )
        {
            iPaintBuffer = new BufferedImage( width, height, BufferedImage.TYPE_INT_RGB );
            iTileDataChanged = true;
        }
        else if ( iPaintBuffer.getWidth() != width || iPaintBuffer.getHeight() != height )
        {
            iTileDataChanged = true;
        }

        if ( iTileDataChanged )
        {
            Graphics2D gc = ( Graphics2D ) iPaintBuffer.getGraphics();
            gc.setColor( aBackgroundColor );
            gc.fillRect( 0, 0, iPaintBuffer.getWidth(), iPaintBuffer.getHeight() );
            gc.setComposite( AlphaComposite.Src );
            paintTiles( gc, aTargetSize );
            iTileDataChanged = false;
        }
    }

    private void paintTiles( Graphics aGc, Dimension aTargetSize )
    {
        int width = aTargetSize.width;
        int height = aTargetSize.height;

        int tileIndex = 0;
        Point tilePos = new Point();
        Dimension tileSize = new Dimension();
        for ( int y = 0; y < iTilesPerColumn; y++ )
        {
            for ( int x = 0; x < iTilesPerRow; x++ )
            {
                tilePos.x = x * width / iTilesPerRow;
                tilePos.y = y * height / iTilesPerColumn;
                int xEnd = ( x + 1 ) * width / iTilesPerRow - iInsets.width;
                int yEnd = ( y + 1 ) * height / iTilesPerColumn - iInsets.height;
                tileSize.width = xEnd - tilePos.x;
                tileSize.height = yEnd - tilePos.y;

                Tile aTile = iTileSet.getTile( tileIndex++ );
                aTile.paintSized( aGc, tilePos, tileSize );
            }
        }
    }



    private /*inner*/ class SizeConstrainer extends ComponentAdapter
    {
        // From ComponentAdapter

        public void componentResized( ComponentEvent aEvent )
        {
            super.componentResized( aEvent );
            onTileSetChanged();
        }
    }
}
