/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.gui;



public interface SelectionCursorListener
{
    void onNewSelection( int aX, int aY );

    void onAlternativeSelection( int aX, int aY );
}
