/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.core;

import de.intensicode.gled.util.Plugin;

import java.io.File;
import java.io.Serializable;
import java.io.IOException;



public class ProjectInfo implements Serializable
{
    private Plugin iPlugin;

    private File iTileSetFile;

    private File iLevelDataFile;



    public ProjectInfo( GledProject aGledProject ) throws IOException
    {
        iPlugin = aGledProject.getPlugin();
        iTileSetFile = aGledProject.getTileSetFile();
        iLevelDataFile = aGledProject.getLevelDataFile();

        File currentDirectory = new File( ".");

        String currentPath = currentDirectory.getCanonicalPath();
        String tileSetPath = iTileSetFile.getCanonicalPath();
        if ( tileSetPath.indexOf( currentPath ) == 0 )
        {
            String relativePath = tileSetPath.substring( currentPath.length() + 1 );
            iTileSetFile = new File( relativePath );
        }

        String levelDataPath = iLevelDataFile.getCanonicalPath();
        if ( levelDataPath.indexOf( currentPath ) == 0 )
        {
            String relativePath = levelDataPath.substring( currentPath.length() + 1 );
            iLevelDataFile = new File( relativePath );
        }
    }

    public Plugin getPlugin()
    {
        return iPlugin;
    }

    public File getTileSetFile()
    {
        return iTileSetFile;
    }

    public File getLevelDataFile()
    {
        return iLevelDataFile;
    }
}
