/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.constraints;

import de.intensicode.gled.domain.TileProviderHandler;
import de.intensicode.gled.domain.TileProviderListener;



public class IfTileSetLoadedConstraint extends GledConstraint implements TileProviderListener
{
    private TileProviderHandler iTileContainer;



    public IfTileSetLoadedConstraint( TileProviderHandler aTileContainer )
    {
        iTileContainer = aTileContainer;
        iTileContainer.addListener( this );
    }

    // From TileProviderListener

    public void onTileProviderChanged()
    {
        setEnabled( iTileContainer.getNumberOfLayers() > 0 );
    }
}
