/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.util;

import de.intensicode.gled.domain.LevelOption;



/**
 *
 */
public class BooleanLevelOption implements LevelOption, LevelOption.BooleanExtension
{
    private String iName;

    Boolean iValue;



    public BooleanLevelOption( String aName )
    {
        this( aName, false );
    }

    public BooleanLevelOption( String aName, boolean aInitialValue )
    {
        iName = aName;
        iValue = new Boolean( aInitialValue );
    }

    // From LevelOption

    public int getType()
    {
        return KBoolean;
    }

    public String getName()
    {
        return iName;
    }

    public Object getValue()
    {
        return iValue;
    }

    public void setValue( Object aNewValue )
    {
        iValue = ( Boolean ) aNewValue;
    }

    public LevelOption.BooleanExtension getBooleanExtension()
    {
        return this;
    }

    public LevelOption.IntegerExtension getIntegerExtension()
    {
        throw new UnsupportedOperationException();
    }

    public LevelOption.StringExtension getStringExtension()
    {
        throw new UnsupportedOperationException();
    }

    // From BooleanExtension

    public boolean getBooleanValue()
    {
        return iValue.booleanValue();
    }
}
