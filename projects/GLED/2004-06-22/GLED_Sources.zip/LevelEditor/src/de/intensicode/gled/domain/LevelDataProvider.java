/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.domain;

import java.awt.Dimension;



public interface LevelDataProvider
{
    void load( byte[] aLevelData );

    byte[] save();

    int getNumberOfLevels();

    Dimension getLevelSize();

    LevelData getLevelData( int aIdx );

    void addNewLevel();

    void cloneLevel( int aSelected );

    void copyLevel( int aSourceLevel, int aDestinationLevel );

    void swapLevels( int aSourceLevel, int aDestinationLevel );

    void deleteLevel( int aLevelIndex );
}
