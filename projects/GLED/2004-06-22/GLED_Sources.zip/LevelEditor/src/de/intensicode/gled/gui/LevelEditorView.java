/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.gui;

import de.intensicode.core.config.ConfigurationException;
import de.intensicode.core.logging.Log;
import de.intensicode.gled.actions.GledAction;
import de.intensicode.gled.core.GledApplication;
import de.intensicode.gled.core.LevelDrawer;
import de.intensicode.gled.domain.*;
import de.intensicode.mui.MUICanvas;
import de.intensicode.mui.Paintable;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.util.ArrayList;



public class LevelEditorView extends MUICanvas implements Paintable,
        LevelSelectionListener, LevelDataContainerListener,
        TileProviderListener, SelectionCursorListener, LayerSelectionListener
{
    private GledApplication iApplication;

    private CenteredTextOverlay iTextOverlay;

    private LevelDataContainer iLevelDataContainer;

    private TileProviderHandler iTileContainer;

    private LevelSelection iLevelSelection;

    private TileSelection iTileSelection;

    private LayerSelection iLayerSelection;

    private LevelDrawer iLevelDrawer;

    private LockHandler iLockHandler;

    private LevelData iLevelData;

    private SelectionCursor iSelectionCursor;

    private Point iOffset;

    private Dimension iSize;

    private int iSelectedLevel = -1;

    private GledAction iSelectPreviousTile;

    private GledAction iSelectNextTile;

    private static final int KMaxUndoSteps = 1024;

    private ArrayList/*UndoSingleChange*/ iUndoBuffer = new ArrayList();

    private boolean iAmChangingSomething;

    private BufferedImage iPaintBuffer;

    private boolean iLevelDataChanged = true;

    private Point iClipIndex = new Point();

    private Log iLog = Log.getLog();



    public LevelEditorView( GledApplication aApplication ) throws ConfigurationException
    {
        iApplication = aApplication;

        iLevelDataContainer = aApplication.getLevelDataContainer();
        iTileContainer = aApplication.getTileContainer();

        iLevelSelection = aApplication.getLevelSelection();
        iTileSelection = aApplication.getTileSelection();

        iLayerSelection = aApplication.getLayerSelection();
        iLayerSelection.addListener( this );

        iLevelDrawer = new LevelDrawer( iTileContainer, iLayerSelection );

        iLockHandler = new LockHandler( iLevelDataContainer );

        iOffset = new Point( 0, 0 );
        iSize = new Dimension( 1, 1 );

        iLevelDataContainer.addListener( this );
        iTileContainer.addListener( this );
        iLevelSelection.addListener( this );

        iSelectionCursor = new SelectionCursor( this );

        addPaintable( this );
        addPaintable( iSelectionCursor );

        addMouseListener( iLockHandler );
        addMouseListener( iSelectionCursor );
        setMouseMotionListener( iSelectionCursor );

        setClearBeforePaint( true );

        iCanvas.addKeyListener( new KeyHandler() );

        iSelectPreviousTile = GledAction.getAction( "SelectPreviousTile" );
        iSelectNextTile = GledAction.getAction( "SelectNextTile" );
    }

    public void undoLastChange()
    {
        if ( iUndoBuffer.size() > 0 )
        {
            Undo change = ( Undo ) iUndoBuffer.remove( iUndoBuffer.size() - 1 );
            change.undo( iLevelData );
        }
        else
        {
            iApplication.getUserInterface().showStatus( "Nothing to undo" );
        }
    }

    public void fillLevel()
    {
        if ( selectionValid() == false )
        {
            return;
        }

        saveUndo();

        iAmChangingSomething = true;
        iLevelData.fillLevel( iTileSelection );
        iAmChangingSomething = false;

        requestDisplayUpdate();
    }

    // From Paintable

    public void paintInto( Graphics2D aGc, Dimension aTargetSize )
    {
        if ( iLevelData == null )
        {
            if ( iTextOverlay == null )
            {
                iTextOverlay = new CenteredTextOverlay( "NO DATA" );
            }
            iTextOverlay.paintInto( aGc, aTargetSize );
        }
        else if ( allDataAvailable() )
        {
            int size = Math.min( aTargetSize.width, aTargetSize.height );
            iOffset.x = ( aTargetSize.width - size ) / 2;
            iOffset.y = ( aTargetSize.height - size ) / 2;
            iSize.width = size;
            iSize.height = size;

            updatePaintBufferIfNecessary( Color.BLACK );

            aGc.translate( iOffset.x, iOffset.y );
            aGc.drawImage( iPaintBuffer, 0, 0, size, size, 0, 0, size, size, null );
            aGc.translate( -iOffset.x, -iOffset.y );

            iSelectionCursor.setOffset( iOffset );
            iSelectionCursor.setSelectionSize( iSize );

            if ( iSize == null || iLevelData == null )
            {
                return;
            }
        }

        if ( iSelectionCursor != null && iLevelData != null )
        {
            iSelectionCursor.setGridSize( iLevelData.getLevelWidth(), iLevelData.getLevelHeight() );
            iSelectionCursor.paintInto( aGc, aTargetSize );
        }

        iClipIndex.x = iClipIndex.y = -1;
    }

    // From LevelSelectionListener

    public void onLevelSelectionChanged( int aLevelIndex )
    {
        iSelectionCursor.setEnabled( true );

        iSelectedLevel = aLevelIndex;
        iLevelData = iLevelDataContainer.getLevelData( iSelectedLevel );
        requestDisplayUpdate();
        clearUndo();
    }

    public void onLevelUnselected()
    {
        iSelectionCursor.setEnabled( false );

        iSelectedLevel = -1;
        iLevelData = null;
        requestDisplayUpdate();
        clearUndo();
    }

    // From LevelDataContainerListener

    public void onLevelDataChanged()
    {
        if ( iSelectedLevel < 0 || iSelectedLevel >= iLevelDataContainer.getNumberOfLevels() )
        {
            iLevelData = null;
        }
        else
        {
            iLevelData = iLevelDataContainer.getLevelData( iSelectedLevel );
        }
        requestDisplayUpdate();
    }

    public void onLevelDataChanged( int aLevelIndex )
    {
        if ( iAmChangingSomething )
        {
            iLevelDataChanged = true;
            return;
        }
        if ( iSelectedLevel == aLevelIndex )
        {
            requestDisplayUpdate();
        }
    }

    // From TileProviderListener

    public void onTileProviderChanged()
    {
        if ( selectionValid() )
        {
            iLevelDataChanged = true;
            requestDisplayUpdate();
        }
    }

    // From SelectionCursorListener

    public void onNewSelection( int aX, int aY )
    {
        if ( selectionValid() == false )
        {
            return;
        }

        iCanvas.requestFocus();

        BlockData block = iLevelData.getBlockData( aX, aY );
        if ( block.matches( iTileSelection ) == false )
        {
            saveUndo( aX, aY, block );

            iAmChangingSomething = true;
            block.setFrom( iTileSelection );
            iAmChangingSomething = false;

            iLevelDataChanged = true;

            iClipIndex.x = aX;
            iClipIndex.y = aY;

            iJava.repaint( 250 );
        }
        else
        {
            iJava.repaint( 250 );

        }
    }

    public void onAlternativeSelection( int aX, int aY )
    {
        if ( selectionValid() == false )
        {
            return;
        }

        iCanvas.requestFocus();

        BlockData block = iLevelData.getBlockData( aX, aY );

        int layers = iTileContainer.getNumberOfLayers();
        for ( int idx = layers - 1; idx >= 0; idx-- )
        {
            if ( iLayerSelection.getVisibility( idx ) == false )
            {
                continue;
            }
            if ( idx == 0 || block.isEmpty( idx ) == false )
            {
                iTileSelection.setTo( idx, block.getTileIndex( idx ) );
                break;
            }
        }
    }

    // From LayerSelectionListener

    public void onLayerSelectionChanged( LayerSelection aLayerSelection )
    {
        requestDisplayUpdate();
    }

    // Implementation

    private boolean selectionValid()
    {
        return iSelectedLevel != -1 && iTileSelection.isValid();
    }

    private void requestDisplayUpdate()
    {
//        clearUndo();
        iLevelDataChanged = true;
        iJava.repaint( 250 );
    }

    private boolean allDataAvailable()
    {
        if ( iLevelDataContainer.getNumberOfLevels() == 0 )
        {
            return false;
        }
        if ( iTileContainer.getNumberOfLayers() == 0 )
        {
            return false;
        }
        if ( iLevelData == null )
        {
            return false;
        }
        if ( iSize == null )
        {
            return false;
        }
        return true;
    }

    private void updatePaintBufferIfNecessary( Color aBackgroundColor )
    {
        if ( iLevelData != null )
        {
            if ( iPaintBuffer == null )
            {
                iPaintBuffer = new BufferedImage( iSize.width, iSize.height, BufferedImage.TYPE_INT_RGB );
                iLevelDataChanged = true;
            }
            else if ( iPaintBuffer.getWidth() < iSize.width || iPaintBuffer.getHeight() < iSize.height )
            {
                iPaintBuffer = new BufferedImage( iSize.width, iSize.height, BufferedImage.TYPE_INT_RGB );
                iLevelDataChanged = true;
            }
            else if ( iPaintBuffer.getWidth() != iSize.width || iPaintBuffer.getHeight() != iSize.height )
            {
                iLevelDataChanged = true;
            }
            if ( iLevelDataChanged )
            {
                Graphics2D gc = ( Graphics2D ) iPaintBuffer.getGraphics();
                if ( iClipIndex.x != -1 && iClipIndex.y != -1 )
                {
                    gc.setColor( aBackgroundColor );
                    gc.fill( iSelectionCursor.getRectangle( iClipIndex.x, iClipIndex.y ) );
                    iLevelDrawer.drawLevel( iLevelData, gc, iSize, iClipIndex );
                }
                else
                {
                    gc.setColor( aBackgroundColor );
                    gc.fillRect( 0, 0, iPaintBuffer.getWidth(), iPaintBuffer.getHeight() );
                    iLevelDrawer.drawLevel( iLevelData, gc, iSize );
                }
                iLevelDataChanged = false;
            }
        }
    }

    private void clearUndo()
    {
        iUndoBuffer.clear();
    }

    private void saveUndo()
    {
        if ( iUndoBuffer.size() >= KMaxUndoSteps )
        {
            iUndoBuffer.remove( 0 );
        }
        iUndoBuffer.add( new UndoLevelChange( iLevelData ) );
    }

    private void saveUndo( int aX, int aY, BlockData aBlock )
    {
        if ( iUndoBuffer.size() >= KMaxUndoSteps )
        {
            iUndoBuffer.remove( 0 );
        }
        iUndoBuffer.add( new UndoSingleChange( new Point( aX, aY ), aBlock ) );
    }



    private /*inner*/ interface Undo
    {
        void undo( LevelData aLevelData );
    }



    private /*inner*/ class LockHandler extends MouseAdapter
    {
        private LevelDataContainer iLevelDataContainer;



        public LockHandler( LevelDataContainer aLevelDataContainer )
        {
            iLevelDataContainer = aLevelDataContainer;
        }

        public void mousePressed( MouseEvent aEvent )
        {
            iLevelDataContainer.setUpdateLock( true );
        }

        public void mouseReleased( MouseEvent aEvent )
        {
            iLevelDataContainer.setUpdateLock( false );
        }
    }



    private /*inner*/ class UndoSingleChange implements Undo
    {
        private Point iIndex;

        private Point iCursor;

        private BlockData iData;



        public UndoSingleChange( Point aIndex, BlockData aBlock )
        {
            iIndex = aIndex;
            iCursor = iSelectionCursor.getIndex();
            iData = aBlock.cloned();
        }

        // From Undo

        public void undo( LevelData aLevelData )
        {
            iAmChangingSomething = true;

            BlockData block = aLevelData.getBlockData( iIndex.x, iIndex.y );
            block.setFrom( iData );
            iSelectionCursor.setIndex( iCursor );
            requestDisplayUpdate();

            iAmChangingSomething = false;
        }
    }



    private /*inner*/ class UndoLevelChange implements Undo
    {
        private BlockData[] iData;



        public UndoLevelChange( LevelData aLevelData )
        {
            int width = aLevelData.getLevelWidth();
            int height = aLevelData.getLevelHeight();
            iData = new BlockData[ width * height ];

            for ( int y = 0; y < height; ++y )
            {
                for ( int x = 0; x < width; ++x )
                {
                    iData[ x + y * width ] = aLevelData.getBlockData( x, y ).cloned();
                }
            }
        }

        // From Undo

        public void undo( LevelData aLevelData )
        {
            iAmChangingSomething = true;

            int width = aLevelData.getLevelWidth();
            int height = aLevelData.getLevelHeight();
            for ( int y = 0; y < height; ++y )
            {
                for ( int x = 0; x < width; ++x )
                {
                    BlockData block = aLevelData.getBlockData( x, y );
                    block.setFrom( iData[ x + y * width ] );
                }
            }
            requestDisplayUpdate();

            iAmChangingSomething = false;
        }
    }



    private /*inner*/ class KeyHandler extends KeyAdapter
    {
        public void keyPressed( KeyEvent aEvent )
        {
            if ( aEvent.getModifiers() != 0 )
            {
                return;
            }
            Point cursor = iSelectionCursor.getIndex();
            switch ( aEvent.getKeyCode() )
            {
                case KeyEvent.VK_UP:
                    if ( --cursor.y < 0 )
                    {
                        cursor.y = iLevelData.getLevelHeight() - 1;
                    }
                    updateCursor( cursor );
                    break;

                case KeyEvent.VK_DOWN:
                    if ( ++cursor.y >= iLevelData.getLevelHeight() )
                    {
                        cursor.y = 0;
                    }
                    updateCursor( cursor );
                    break;

                case KeyEvent.VK_LEFT:
                    if ( --cursor.x < 0 )
                    {
                        cursor.x = iLevelData.getLevelWidth() - 1;
                    }
                    updateCursor( cursor );
                    break;

                case KeyEvent.VK_RIGHT:
                    if ( ++cursor.x >= iLevelData.getLevelWidth() )
                    {
                        cursor.x = 0;
                    }
                    updateCursor( cursor );
                    break;

                case KeyEvent.VK_ENTER:
                case KeyEvent.VK_V:
                    onNewSelection( cursor.x, cursor.y );
                    break;

                case KeyEvent.VK_C:
                case KeyEvent.VK_G:
                    onAlternativeSelection( cursor.x, cursor.y );
                    break;

                case KeyEvent.VK_BACK_SPACE:
                    undoLastChange();
                    break;

                case KeyEvent.VK_OPEN_BRACKET:
                    iSelectPreviousTile.actionPerformed( null );
                    break;

                case KeyEvent.VK_CLOSE_BRACKET:
                    iSelectNextTile.actionPerformed( null );
                    break;

                default:
                    break;
            }
        }

        private void updateCursor( Point aCursor )
        {
            iSelectionCursor.setIndex( aCursor );
            requestDisplayUpdate();
        }
    }
}
