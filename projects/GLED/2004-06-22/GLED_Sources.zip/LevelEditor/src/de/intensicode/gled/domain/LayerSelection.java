/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.domain;



public interface LayerSelection
{
    boolean getVisibility( int aIdx );

    boolean getReducedSize( int aIdx );

    int getSizePercentage( int aIdx );

    boolean getTransparency( int aIdx );

    int getTransparencyPercentage( int aIdx );

    void setVisibility( int aIdx, boolean aSelected );

    void setReducedSize( int aIdx, boolean aSelected );

    void setSizePercentage( int aIndex, int aValue );

    void setTransparency( int aIdx, boolean aSelected );

    void setTransparencyPercentage( int aIndex, int aValue );

    void addListener( LayerSelectionListener aLayerSelectionListener );
}
