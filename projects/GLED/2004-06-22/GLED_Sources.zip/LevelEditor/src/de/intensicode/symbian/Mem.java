/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.symbian;



public class Mem
{
    public static void Fill( TDes8 aData, int aLength, byte aByte )
    {
        for ( int idx = 0; idx < aLength; ++idx )
        {
            aData.set( idx, aByte );
        }
    }

    public static void FillZ( TDes8 aData, int aLength )
    {
        for ( int idx = 0; idx < aLength; ++idx )
        {
            aData.set( idx, ( byte ) 0 );
        }
    }
}
