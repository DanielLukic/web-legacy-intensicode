/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.domain;



public interface BlockData
{
    boolean isEmpty( int aLayerIndex );

    boolean matches( TileSelection aTileSelection );

    int getTileIndex( int aLayerIndex );

    void setTileIndex( int aLayerIndex, int aSelectedTile );

    void setFrom( TileSelection aTileSelection );

    void setFrom( BlockData aData );

    BlockData cloned();
}
