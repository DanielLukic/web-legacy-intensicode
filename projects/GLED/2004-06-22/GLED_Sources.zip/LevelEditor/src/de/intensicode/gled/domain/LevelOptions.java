/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.domain;



public interface LevelOptions
{
    String getLevelName();

    int getNumberOfOptions();

    LevelOption getLevelOption( int aIndex );
}
