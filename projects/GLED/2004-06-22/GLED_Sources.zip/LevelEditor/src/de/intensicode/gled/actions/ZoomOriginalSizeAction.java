/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.actions;

import de.intensicode.mui.MUIUtils;

import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

import javax.swing.Action;
import javax.swing.KeyStroke;



public class ZoomOriginalSizeAction extends GledAction
{
    public ZoomOriginalSizeAction()
    {
        putValue( Action.NAME, "Zoom to orignal size" );
        putValue( Action.SHORT_DESCRIPTION, "Zoom level editor view to original size (1:1 pixel)" );
        putValue( Action.SMALL_ICON, MUIUtils.getIcon( "/icons/zoomExact.png" ) );
        putValue( Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke( KeyEvent.VK_O, KeyEvent.ALT_DOWN_MASK ) );
    }

    // From ActionListener

    public void actionPerformed( ActionEvent e )
    {

    }
}
