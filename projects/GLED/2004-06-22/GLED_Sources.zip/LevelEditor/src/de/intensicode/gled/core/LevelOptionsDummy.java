/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.core;

import de.intensicode.gled.domain.LevelOptions;
import de.intensicode.gled.domain.LevelOption;
import de.intensicode.gled.util.BooleanLevelOption;



class LevelOptionsDummy implements LevelOptions
{
    private final String iDummyName = "DUMMY";

    private final LevelOption iDummyOption = new BooleanLevelOption( "DUMMY" );



    // From LevelOptions

    public String getLevelName()
    {
        return iDummyName;
    }

    public int getNumberOfOptions()
    {
        return 0;
    }

    public LevelOption getLevelOption( int aIndex )
    {
        return iDummyOption;
    }
}
