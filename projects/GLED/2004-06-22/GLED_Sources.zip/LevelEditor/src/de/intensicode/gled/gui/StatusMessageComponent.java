/************************************************************************/
/* GLED                 www.intensicode.de                December 2003 */
/************************************************************************/

package de.intensicode.gled.gui;

import de.intensicode.mui.MUILabel;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Timer;



public class StatusMessageComponent extends MUILabel implements ActionListener
{
    private Timer iTimeOutTimer = new Timer( 2500, this );



    public StatusMessageComponent()
    {
        super( "" );
    }

    public void showStatus( String aMessage )
    {
        setText( aMessage );
        startTimeOut();
    }

    // From ActionListener

    public void actionPerformed( ActionEvent aEvent )
    {
        setText( "" );
        iTimeOutTimer.stop();
    }

    // Implementation

    private void startTimeOut()
    {
        if ( iTimeOutTimer.isRunning() )
        {
            iTimeOutTimer.stop();
        }
        iTimeOutTimer.start();
    }
}
