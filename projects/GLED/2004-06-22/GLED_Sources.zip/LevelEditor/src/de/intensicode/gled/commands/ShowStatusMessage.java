/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.commands;

import java.io.IOException;



public class ShowStatusMessage extends GledCommand
{
    private String iDescription;

    private IOException iCause;



    public ShowStatusMessage( String aMessage )
    {
        iDescription = aMessage;
        iAmAsync = false;
    }

    public ShowStatusMessage( String aDescription, IOException aCause )
    {
        iDescription = aDescription;
        iCause = aCause;
    }

    // From Command

    public void execute() throws Throwable
    {
        StringBuffer message = new StringBuffer( iDescription );
        if ( iCause != null )
        {
            message.append( " (" );
            message.append( iCause );
            message.append( ")" );
        }
        iStatusLog.showStatus( message.toString() );
    }
}
