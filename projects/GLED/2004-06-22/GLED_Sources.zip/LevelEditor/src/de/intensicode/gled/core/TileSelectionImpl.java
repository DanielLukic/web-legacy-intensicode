/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.core;

import de.intensicode.gled.domain.TileProviderListener;
import de.intensicode.gled.domain.TileSelection;
import de.intensicode.gled.domain.TileSelectionListener;

import java.util.ArrayList;



/**
 *
 */
public class TileSelectionImpl implements TileSelection, TileProviderListener
{
    private TileProviderHandlerImpl iTileProviderHandler;

    private ArrayList /*TileSelectionListener*/ iListeners = new ArrayList();

    private int iNumberOfLayers = 0;

    private int iNumberOfTiles = 0;

    private int iLayerIndex = -1;

    private int iTileIndex = -1;

    private int iLastLayerFired = -2;

    private int iLastTileFired = -2;



    public TileSelectionImpl( TileProviderHandlerImpl aTileProviderHandler )
    {
        iTileProviderHandler = aTileProviderHandler;
        iTileProviderHandler.addListener( this );
    }

    // From TileSelection

    public void addListener( TileSelectionListener aListener )
    {
        iListeners.add( aListener );
    }

    public boolean isValid()
    {
        return iLayerIndex != -1 && iTileIndex != -1;
    }

    public int getLayerIndex()
    {
        return iLayerIndex;
    }

    public int getTileIndex()
    {
        return iTileIndex;
    }

    public void setTo( int aLayerIndex, int aTileIndex )
    {
        iLayerIndex = aLayerIndex;
        iTileIndex = aTileIndex;

        checkAndUpdateSelection();
    }

    // From TileProviderListener

    public void onTileProviderChanged()
    {
        checkAndUpdateSelection();

    }

    // From Object

    public String toString()
    {
        StringBuffer result = new StringBuffer();
        result.append( "iLayerIndex=");
        result.append( iLayerIndex );
        result.append( ", iTileIndex=");
        result.append( iTileIndex );
        return result.toString();
    }

    // Implementation

    private void checkAndUpdateSelection()
    {
        iNumberOfLayers = iTileProviderHandler.getNumberOfLayers();

        if ( iNumberOfLayers == 0 )
        {
            iLayerIndex = iTileIndex = -1;
            iNumberOfTiles = 0;
        }
        else
        {
            if ( iLayerIndex < 0 || iLayerIndex >= iTileProviderHandler.getNumberOfLayers() )
            {
                iLayerIndex = iTileIndex = 0;
            }

            iNumberOfTiles = iTileProviderHandler.getLayerTileSet( iLayerIndex ).getNumberOfTiles();
            if ( iTileIndex < 0 || iTileIndex >= iNumberOfTiles )
            {
                iLayerIndex = iTileIndex = -1;
            }
        }

        fireTileSelectionChanged();
    }

    private void fireTileSelectionChanged()
    {
        if ( iLastLayerFired != iLayerIndex || iLastTileFired != iTileIndex )
        {
            iLastLayerFired = iLayerIndex;
            iLastTileFired = iTileIndex;

            for ( int idx = 0; idx < iListeners.size(); ++idx )
            {
                TileSelectionListener listener = ( TileSelectionListener ) iListeners.get( idx );
                listener.onTileSelectionChanged( this );
            }
        }
    }
}
