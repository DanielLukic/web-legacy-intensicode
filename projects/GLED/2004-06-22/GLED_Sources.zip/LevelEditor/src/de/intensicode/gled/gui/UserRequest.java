/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.gui;

import javax.swing.JFrame;
import javax.swing.JOptionPane;



public class UserRequest
{
    public final static int KYes = JOptionPane.YES_OPTION;

    public final static int KNo = JOptionPane.NO_OPTION;



    public static int askUser( JFrame aFrame, String aMessage, Throwable aThrowable )
    {
        StringBuffer message = new StringBuffer( aMessage );
        message.append( "\nReason: " );
        message.append( aThrowable.getMessage() );

        return JOptionPane.showConfirmDialog
            ( aFrame, message, "GLED Request", JOptionPane.YES_NO_OPTION, JOptionPane.ERROR_MESSAGE );
    }

    public static void informUser( JFrame aFrame, String aMessage )
    {
        JOptionPane.showMessageDialog
            ( aFrame, aMessage, "GLED Information", JOptionPane.INFORMATION_MESSAGE );
    }
}
