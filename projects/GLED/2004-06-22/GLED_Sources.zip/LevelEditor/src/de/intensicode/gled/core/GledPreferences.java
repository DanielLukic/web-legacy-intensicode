/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.core;

import de.intensicode.core.logging.Log;

import java.awt.Dimension;
import java.awt.Point;
import java.awt.image.BufferedImage;
import java.io.*;



public class GledPreferences implements Serializable
{
    private static Log iLog = Log.getLog( "GledPreferences" );

    private static String KGledPreferencesFileName = "res/GLED.preferences";

    private static GledPreferences iSingleton = null;

    private Point iFramePosition = new Point( -1, -1 );

    private Dimension iFrameSize = new Dimension( -1, -1 );



    private GledPreferences()
    {

    }

    public static GledPreferences getInstance()
    {
        if ( iSingleton == null )
        {
            iLog.info( "Loading GLED preferences" );
            try
            {
                readPreferences();
            }
            catch ( Exception ex )
            {
                iLog.error( "Failed reading preferences. Using iDefaults", ex );
                iSingleton = new GledPreferences();
            }
        }
        return iSingleton;
    }

    public int getImageType()
    {
        return BufferedImage.TYPE_INT_RGB;
    }

    public Point getFramePosition()
    {
        return iFramePosition;
    }

    public Dimension getFrameSize()
    {
        return iFrameSize;
    }

    public void setFrameShape( Point aPosition, Dimension aSize )
    {
        iFramePosition = aPosition;
        iFrameSize = aSize;

        try
        {
            writePreferences();
        }
        catch ( Exception ex )
        {
            iLog.error( "Failed saving preferences", ex );
        }
    }

    // Implementation

    private static void readPreferences() throws IOException, ClassNotFoundException
    {
        FileInputStream file = null;
        ObjectInputStream in = null;
        try
        {
            file = new FileInputStream( KGledPreferencesFileName );
            in = new ObjectInputStream( file );
            iSingleton = ( GledPreferences ) in.readObject();
        }
        finally
        {
            if ( in != null )
            {
                in.close();
            }
            else if ( file != null )
            {
                file.close();
            }
        }
    }

    private void writePreferences() throws IOException
    {
        FileOutputStream file = null;
        ObjectOutputStream out = null;
        try
        {
            file = new FileOutputStream( KGledPreferencesFileName );
            out = new ObjectOutputStream( file );
            out.writeObject( iSingleton );
        }
        finally
        {
            if ( out != null )
            {
                out.close();
            }
            else if ( file != null )
            {
                file.close();
            }
        }
    }
}
