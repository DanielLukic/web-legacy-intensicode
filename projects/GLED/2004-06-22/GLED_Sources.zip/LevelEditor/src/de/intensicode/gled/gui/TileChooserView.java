/************************************************************************/
/* GLED                 www.intensicode.de                December 2003 */
/************************************************************************/

package de.intensicode.gled.gui;

import de.intensicode.core.logging.Log;
import de.intensicode.gled.core.GledApplication;
import de.intensicode.gled.domain.TileProviderHandler;
import de.intensicode.gled.domain.TileProviderListener;
import de.intensicode.mui.MUIConstraints;
import de.intensicode.mui.MUIGroupV;
import de.intensicode.mui.MUILabel;
import de.intensicode.mui.MUIScrollView;

import java.awt.Dimension;
import java.util.ArrayList;



public class TileChooserView extends MUIGroupV implements TileProviderListener
{
    private Log iLog = Log.getLog();

    private ArrayList iLayers = new ArrayList();

    private TileProviderHandler iTileProviderHandler;

    private GledApplication iApplication;



    public TileChooserView( GledApplication aApplication )
    {
        iApplication = aApplication;

        iTileProviderHandler = aApplication.getTileContainer();
        iTileProviderHandler.addListener( this );

        onTileProviderChanged();
    }

    // From TileProviderListener

    public void onTileProviderChanged()
    {
        removeAll();
        iLayers.clear();

        iLog.info( "Creating tile chooser layers" );

        int layers = iTileProviderHandler.getNumberOfLayers();
        for ( int idx = 0; idx < layers; idx++ )
        {
            TileChooserCanvas layer = new TileChooserCanvas( iApplication, idx );
            iLayers.add( layer );

            String name = iTileProviderHandler.getLayerName( idx );
            addChild( new MUILabel( name ) );

            MUIConstraints constraints = new MUIConstraints();
            constraints.setWeights( 0.75, idx == 0 ? 1.0 : 0.25 );
            addChild( new MUIScrollView( layer ).setScrollDirections( false, true ), constraints );
        }
    }

    // From JComponent

    public Dimension getMinimumSize()
    {
        int width = iTileProviderHandler.getTileSize().width;
        int height = iTileProviderHandler.getTileSize().height;
        int factor = 100 * width / height;
        Dimension minSize = super.getMinimumSize();
        minSize.height = minSize.width * 100 / factor;
        return minSize;
    }

    public Dimension getPreferredSize()
    {
        int width = iTileProviderHandler.getTileSize().width;
        int height = iTileProviderHandler.getTileSize().height;
        int factor = 100 * width / height;
        Dimension prefSize = super.getPreferredSize();
        prefSize.height = prefSize.width * 100 / factor;
        return prefSize;
    }
}
