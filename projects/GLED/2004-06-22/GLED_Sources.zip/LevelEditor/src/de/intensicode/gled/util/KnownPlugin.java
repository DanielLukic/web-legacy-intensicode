/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.util;

import de.intensicode.core.config.ConfigurationException;
import de.intensicode.gled.domain.SystemFactory;



/**
 *
 */
public class KnownPlugin implements Plugin
{
    private String iName;



    public KnownPlugin( String aName )
    {
        iName = aName;
    }

    // From Plugin

    public String getName()
    {
        return iName;
    }

    public SystemFactory getSystemFactory() throws ConfigurationException
    {
        StringBuffer className = new StringBuffer();
        className.append( "de.intensicode.gled." );
        className.append( iName.toLowerCase() );
        className.append( "." );
        className.append( iName );
        className.append( "Factory" );

        try
        {
            Class clazz = Class.forName( className.toString() );
            Object instance = clazz.newInstance();

            return ( SystemFactory ) instance;
        }
        catch ( Throwable t )
        {
            throw new ConfigurationException( "Failed loading plugin", t );
        }
    }
}
