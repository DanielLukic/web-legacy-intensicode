/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.actions;

import de.intensicode.core.Reflection;
import de.intensicode.core.logging.Log;
import de.intensicode.core.config.ConfigurationException;
import de.intensicode.gled.MainFrame;
import de.intensicode.gled.core.GledApplication;

import java.util.Hashtable;

import javax.swing.AbstractAction;



public abstract class GledAction extends AbstractAction
{
    protected static Log iLog = Log.getLog();

    protected static GledApplication iApplication;

    protected static MainFrame iMainFrame;

    private static Hashtable iKnownActions = new Hashtable();



    public GledAction()
    {
        setEnabled( false );
    }

    public static void init( GledApplication aApplication, MainFrame aMainFrame )
    {
        iApplication = aApplication;
        iMainFrame = aMainFrame;
    }

    public static GledAction getAction( String aActionName ) throws ConfigurationException
    {
        if ( iKnownActions.containsKey( aActionName ) == false )
        {
            String className = "de.intensicode.gled.actions." + aActionName + "Action";
            Class clazz = Reflection.findClass( className );
            GledAction action = null;
            try
            {
                action = ( GledAction ) clazz.newInstance();
            }
            catch ( Exception ex )
            {
                throw new ConfigurationException( "Failed loading GLED action " + aActionName, ex );
            }
            iKnownActions.put( aActionName, action );
        }
        return ( GledAction ) iKnownActions.get( aActionName );
    }
}
