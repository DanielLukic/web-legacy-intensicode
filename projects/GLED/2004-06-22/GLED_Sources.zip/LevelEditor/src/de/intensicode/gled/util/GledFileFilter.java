/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.util;

import java.io.File;

import javax.swing.filechooser.FileFilter;



public class GledFileFilter extends FileFilter
{
    private static final String KDefaultExtension = ".gled";

    private final String KDefaultDescription = "GLED Project File";

    private String iExtension;

    private String iDescription;



    public GledFileFilter()
    {
        iExtension = KDefaultExtension;
        iDescription = KDefaultDescription;
    }

    public GledFileFilter( String aExtension, String aDescription )
    {
        iExtension = aExtension;
        iDescription = aDescription;
    }

    public String getExtension()
    {
        return iExtension;
    }

    // From FileFilter

    public boolean accept( File aFile )
    {
        if ( aFile.getName().toLowerCase().endsWith( iExtension ) )
        {
            return true;
        }
        return aFile.isDirectory();
    }

    public String getDescription()
    {
        return iDescription;
    }
}
