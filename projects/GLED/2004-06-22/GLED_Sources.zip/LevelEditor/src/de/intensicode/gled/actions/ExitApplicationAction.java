/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.actions;

import de.intensicode.gled.commands.ExitApplication;
import de.intensicode.mui.MUIUtils;

import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

import javax.swing.Action;
import javax.swing.KeyStroke;



public class ExitApplicationAction extends GledAction
{
    public ExitApplicationAction()
    {
        putValue( Action.NAME, "Exit" );
        putValue( Action.SHORT_DESCRIPTION, "Exit the application" );
        putValue( Action.SMALL_ICON, MUIUtils.getIcon( "/icons/exit.png" ) );
        putValue( Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke( KeyEvent.VK_Q, KeyEvent.CTRL_DOWN_MASK ) );
        setEnabled( true );
    }

    // From ActionListener

    public void actionPerformed( ActionEvent aEvent )
    {
        iMainFrame.addCommand( new ExitApplication() );
    }
}
