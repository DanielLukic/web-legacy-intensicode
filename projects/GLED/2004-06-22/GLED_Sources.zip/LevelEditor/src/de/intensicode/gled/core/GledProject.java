/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.core;

import de.intensicode.core.config.ConfigurationException;
import de.intensicode.gled.domain.LevelDataProvider;
import de.intensicode.gled.domain.Project;
import de.intensicode.gled.domain.SystemFactory;
import de.intensicode.gled.domain.TileProvider;
import de.intensicode.gled.util.Plugin;

import java.io.File;
import java.io.IOException;



public class GledProject implements Project
{
    private Plugin iPlugin;

    private SystemFactory iSystemFactory;

    private File iTileSetFile;

    private TileProvider iTileProvider;

    private File iLevelDataFile;

    private LevelDataProvider iLevelDataProvider;



    public GledProject( Plugin aPlugin ) throws ConfigurationException
    {
        initSystemFactory( aPlugin );

        iTileProvider = iSystemFactory.createTileProvider();
        iLevelDataProvider = iSystemFactory.createLevelDataProvider();
    }

    public GledProject( ProjectInfo aProjectInfo ) throws ConfigurationException
    {
        initSystemFactory( aProjectInfo.getPlugin() );

        iTileSetFile = aProjectInfo.getTileSetFile();
        iLevelDataFile = aProjectInfo.getLevelDataFile();

        iTileProvider = iSystemFactory.createTileProvider();
        iLevelDataProvider = iSystemFactory.createLevelDataProvider();
    }

    public Plugin getPlugin()
    {
        return iPlugin;
    }

    // From Project

    public SystemFactory getSystemFactory()
    {
        return iSystemFactory;
    }

    public File getTileSetFile()
    {
        return iTileSetFile;
    }

    public TileProvider getTileProvider()
    {
        return iTileProvider;
    }

    public void setTileSetFile( File aTileSetFile )
    {
        iTileSetFile = aTileSetFile;
    }

    public void setTileProvider( TileProvider aTileProvider )
    {
        iTileProvider = aTileProvider;
    }

    public File getLevelDataFile()
    {
        return iLevelDataFile;
    }

    public LevelDataProvider getLevelDataProvider()
    {
        return iLevelDataProvider;
    }

    public void setLevelDataFile( File aLevelDataFile )
    {
        iLevelDataFile = aLevelDataFile;
    }

    public void setLevelDataProvider( LevelDataProvider aLevelProvider )
    {
        iLevelDataProvider = aLevelProvider;
    }

    public ProjectInfo getDataForOutput() throws IOException
    {
        return new ProjectInfo( this );
    }

    // Implementation

    private void initSystemFactory( Plugin aPlugin ) throws ConfigurationException
    {
        iPlugin = aPlugin;
        iSystemFactory = aPlugin.getSystemFactory();
    }
}
