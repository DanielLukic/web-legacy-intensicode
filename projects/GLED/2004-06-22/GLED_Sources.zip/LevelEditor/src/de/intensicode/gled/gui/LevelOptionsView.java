/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.gui;

import de.intensicode.core.logging.Log;
import de.intensicode.gled.commands.ShowStatusMessage;
import de.intensicode.gled.core.GledApplication;
import de.intensicode.gled.domain.*;
import de.intensicode.mui.*;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.util.ArrayList;



public class LevelOptionsView extends MUIGroupH implements LevelDataContainerListener, LevelSelectionListener
{
    private Log iLog = Log.getLog();

    private Commandable iCommandable;

    private LevelDataContainer iLevelDataContainer;

    private LevelSelection iLevelSelection;

    private Font iOptionFont;

    private LevelOptions iLevelOptions;

    private ArrayList iFields = new ArrayList();

    private int iSelectedLevel = -1;

    private boolean iAmUpdating;

    private final ShowStatusMessage KLevelOptionsUpdatedMsg = new ShowStatusMessage( "Level options updated" );



    public LevelOptionsView( GledApplication aApplication, Commandable aCommandable )
    {
        iCommandable = aCommandable;
        iLevelDataContainer = aApplication.getLevelDataContainer();
        iLevelSelection = aApplication.getLevelSelection();
        iOptionFont = new Font( "FixedSys", Font.PLAIN, 12 );

        onLevelDataChanged();

        iLevelDataContainer.addListener( this );
        iLevelSelection.addListener( this );
    }

    public void updateLevelOptions()
    {
        if ( iAmUpdating || iLevelOptions == null || iSelectedLevel == -1 )
        {
            return;
        }

        saveFields();

        iCommandable.execute( KLevelOptionsUpdatedMsg );
    }

    // From LevelDataContainerListener

    public void onLevelDataChanged()
    {
        removeFields();

        if ( iSelectedLevel < 0 || iSelectedLevel >= iLevelDataContainer.getNumberOfLevels() )
        {
            iSelectedLevel = -1;
            iLevelOptions = null;
        }
        else
        {
            iLevelOptions = iLevelDataContainer.getLevelData( iSelectedLevel ).getOptions();
            createFields();
            loadFields();
        }
    }

    public void onLevelDataChanged( int aLevelIndex )
    {
        if ( iSelectedLevel != -1 && aLevelIndex == iSelectedLevel && iAmUpdating == false )
        {
            loadFields();
        }
    }

    // From LevelSelectionListener

    public void onLevelSelectionChanged( int aLevelIndex )
    {
        iSelectedLevel = aLevelIndex;
        onLevelDataChanged();
    }

    public void onLevelUnselected()
    {
        iSelectedLevel = -1;
        onLevelDataChanged();
    }

    // Implementation

    private void removeFields()
    {
        removeAll();
        iFields.clear();
    }

    private void createFields()
    {
        MUIGroupV booleanFields = new MUIGroupV();
        MUIGroupV integerFields = new MUIGroupV();
        MUIGroupV stringFields = new MUIGroupV();

        int numberOfFields = iLevelOptions.getNumberOfOptions();
        for ( int idx = 0; idx < numberOfFields; idx++ )
        {
            LevelOption option = iLevelOptions.getLevelOption( idx );
            switch ( option.getType() )
            {
                case LevelOption.KBoolean:
                    booleanFields.addChild( createBooleanField( option ) );
                    break;

                case LevelOption.KString:
                    stringFields.addChild( createStringField( option ) );
                    break;

                case LevelOption.KInteger:
                    integerFields.addChild( createIntegerField( option ) );
                    break;

                default:
                    iLog.error( "Level option with unknown type skipped" );
                    break;
            }
        }

        MUIComponent booleans = new MUIScrollView( booleanFields ).setScrollDirections( false, true );
        MUIComponent integers = new MUIScrollView( integerFields ).setScrollDirections( false, true );
        MUIComponent strings = new MUIScrollView( stringFields ).setScrollDirections( false, true );

        booleans.getConstraints().setWeights( 0.3, 0.75 );
        integers.getConstraints().setWeights( 0.6, 0.75 );
        strings.getConstraints().setWeights( 0.5, 0.75 );

        addChild( booleans );
        addChild( integers );
        addChild( strings );
    }

    private void loadFields()
    {
        if ( iLevelOptions == null )
        {
            return;
        }

        iAmUpdating = true;

        int numberOfFields = iLevelOptions.getNumberOfOptions();
        for ( int idx = 0; idx < numberOfFields; idx++ )
        {
            LevelOption option = iLevelOptions.getLevelOption( idx );
            switch ( option.getType() )
            {
                case LevelOption.KBoolean:
                    {
                        LevelOption.BooleanExtension booleanExtension = option.getBooleanExtension();
                        boolean booleanValue = booleanExtension.getBooleanValue();

                        MUICheckBox field = ( MUICheckBox ) iFields.get( idx );
                        field.setSelected( booleanValue );
                    }
                    break;

                case LevelOption.KInteger:
                    {
                        LevelOption.IntegerExtension integerExtension = option.getIntegerExtension();
                        int minValue = integerExtension.getMinValue();
                        int maxValue = integerExtension.getMaxValue();
                        int integerValue = integerExtension.getIntegerValue();

                        MUISlider field = ( MUISlider ) iFields.get( idx );
                        field.setValues( minValue, maxValue, integerValue );
                    }
                    break;

                case LevelOption.KString:
                    {
                        LevelOption.StringExtension stringExtension = option.getStringExtension();
                        String stringValue = stringExtension.getStringValue();
                        int maxLength = stringExtension.getMaxLength();

                        MUITextField field = ( MUITextField ) iFields.get( idx );
                        field.setText( stringValue );
                        field.setMaxLength( maxLength );
                    }
                    break;

                default:
                    iLog.error( "Level option with unknown type skipped" );
                    break;
            }
        }

        iAmUpdating = false;

        invalidate();
        validate();
    }

    private void saveFields()
    {
        if ( iLevelOptions == null )
        {
            return;
        }

        iLog.info( "Saving fields" );

        iAmUpdating = true;

        int numberOfFields = iLevelOptions.getNumberOfOptions();
        for ( int idx = 0; idx < numberOfFields; idx++ )
        {
            LevelOption option = iLevelOptions.getLevelOption( idx );
            switch ( option.getType() )
            {
                case LevelOption.KBoolean:
                    {
                        MUICheckBox field = ( MUICheckBox ) iFields.get( idx );
                        option.setValue( new Boolean( field.isSelected() ) );
                    }
                    break;

                case LevelOption.KInteger:
                    {
                        MUISlider field = ( MUISlider ) iFields.get( idx );
                        option.setValue( new Integer( field.getValue() ) );
                    }
                    break;

                case LevelOption.KString:
                    {
                        MUITextField field = ( MUITextField ) iFields.get( idx );
                        option.setValue( field.getText() );
                    }
                    break;

                default:
                    iLog.error( "Level option with unknown type skipped" );
                    break;
            }
        }

        iAmUpdating = false;

        invalidate();
        validate();
    }

    private MUIComponent createBooleanField( LevelOption aOption )
    {
        LevelOption.BooleanExtension booleanExtension = aOption.getBooleanExtension();
        boolean booleanValue = booleanExtension.getBooleanValue();

        MUICheckBox field = new MUICheckBox( aOption.getName() );
        field.setActionForwarding( this );
        field.setSelected( booleanValue );
        iFields.add( field );

        return field;
    }

    private MUIComponent createIntegerField( LevelOption aOption )
    {
        LevelOption.IntegerExtension integerExtension = aOption.getIntegerExtension();
        int minValue = integerExtension.getMinValue();
        int maxValue = integerExtension.getMaxValue();
        int integerValue = integerExtension.getIntegerValue();

        MUISlider field = new MUISlider( minValue, maxValue, integerValue, true );
        field.setActionForwarding( this );
        iFields.add( field );

        MUIGroupH group = new MUIGroupH();
        group.addChild( new MUILabel( aOption.getName() ) );
        group.addChild( field );

        return group;
    }

    private MUIComponent createStringField( LevelOption aOption )
    {
        LevelOption.StringExtension stringExtension = aOption.getStringExtension();
        String stringValue = stringExtension.getStringValue();
        int maxLength = stringExtension.getMaxLength();

        MUITextField field = new MUITextField( stringValue, maxLength );
        field.setActionForwarding( this );
        field.setFont( iOptionFont );
        iFields.add( field );

        MUIGroupH group = new MUIGroupH();
        group.addChild( new MUILabel( aOption.getName() ) );
        group.addChild( field );

        return group;
    }

    // From ActionListener

    public void actionPerformed( ActionEvent aEvent )
    {
        updateLevelOptions();
    }
}
