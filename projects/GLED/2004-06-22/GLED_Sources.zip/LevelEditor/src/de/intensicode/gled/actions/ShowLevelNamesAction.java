/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.actions;

import de.intensicode.gled.gui.LevelSelectorView;
import de.intensicode.mui.MUIUtils;

import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

import javax.swing.Action;
import javax.swing.KeyStroke;



public class ShowLevelNamesAction extends GledAction
{
    public ShowLevelNamesAction()
    {
        putValue( Action.NAME, "Show level names" );
        putValue( Action.SHORT_DESCRIPTION, "Add level names to thumbnails" );
        putValue( Action.SMALL_ICON, MUIUtils.getIcon( "/icons/attach.png" ) );
        putValue( Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke( KeyEvent.VK_N, KeyEvent.ALT_DOWN_MASK ) );
        setEnabled( true );
    }

    // From ActionListener

    public void actionPerformed( ActionEvent e )
    {
        LevelSelectorView selector = iMainFrame.getLevelSelector();
        boolean shown = selector.isShowingLevelNames();
        selector.setShowingLevelNames( !shown );
    }
}
