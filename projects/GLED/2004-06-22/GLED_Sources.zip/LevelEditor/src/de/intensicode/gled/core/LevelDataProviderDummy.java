/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.core;

import de.intensicode.gled.domain.LevelData;
import de.intensicode.gled.domain.LevelDataProvider;

import java.awt.Dimension;



class LevelDataProviderDummy implements LevelDataProvider
{
    public void load( byte[] aLevelData )
    {

    }

    public byte[] save()
    {
        return new byte[ 0 ];
    }

    public int getNumberOfLevels()
    {
        return 0;
    }

    public Dimension getLevelSize()
    {
        return new Dimension( 0, 0 );
    }

    public LevelData getLevelData( int aIdx )
    {
        return new LevelDataDummy();
    }

    public byte[] getDataForOutput()
    {
        return new byte[ 0 ];
    }

    public void addNewLevel()
    {
        throw new UnsupportedOperationException();
    }

    public void cloneLevel( int aSelected )
    {

    }

    public void copyLevel( int aSourceLevel, int aDestinationLevel )
    {
        throw new UnsupportedOperationException();
    }

    public void swapLevels( int aSourceLevel, int aDestinationLevel )
    {
        throw new UnsupportedOperationException();
    }

    public void deleteLevel( int aLevelIndex )
    {
        throw new UnsupportedOperationException();
    }
}
