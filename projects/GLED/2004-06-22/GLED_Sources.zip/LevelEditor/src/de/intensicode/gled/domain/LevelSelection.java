/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.domain;



public interface LevelSelection
{
    void addListener( LevelSelectionListener aListener );

    boolean isValid();

    int getLevelIndex();

    void setLevelIndex( int aLevelIndex );

    void unselect();
}
