/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.core;

import de.intensicode.gled.domain.LevelData;
import de.intensicode.gled.domain.BlockData;
import de.intensicode.gled.domain.LevelOptions;
import de.intensicode.gled.domain.TileSelection;



class LevelDataDummy implements LevelData
{
    private LevelOptionsDummy iLevelOptionsDummy = new LevelOptionsDummy();

    private BlockDataDummy iBlockDataDummy = new BlockDataDummy();



    // From LevelData

    public LevelOptions getOptions()
    {
        return iLevelOptionsDummy;
    }

    public int getLevelWidth()
    {
        return 0;
    }

    public int getLevelHeight()
    {
        return 0;
    }

    public BlockData getBlockData( int aX, int aY )
    {
        return iBlockDataDummy;
    }

    public void fillLevel( TileSelection aTileSelection )
    {

    }

    public void scrollData( int aDeltaX, int aDeltaY )
    {

    }
}
