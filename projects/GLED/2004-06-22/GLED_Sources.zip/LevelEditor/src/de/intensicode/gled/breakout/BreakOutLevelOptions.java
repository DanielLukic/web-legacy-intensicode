/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.breakout;

import de.intensicode.gled.domain.LevelOption;
import de.intensicode.gled.domain.LevelOptions;
import de.intensicode.gled.util.StringLevelOption;
import de.intensicode.gled.util.BooleanLevelOption;
import de.intensicode.symbian.TDes8;
import de.intensicode.symbian.Mem;
import de.intensicode.core.Assert;



/**
 *
 */
class BreakOutLevelOptions implements LevelOptions
{
    private BreakOutLevelDataProvider iContainer;

    private int iLevelNumber;

    private String iLevelName;

    private static final int KTagLine1 = 0;

    private static final int KTagLine2 = 1;

    private static final int KGradientBackground = 2;

    private static final int KStarsBackground = 3;

    private static final int KStarsAnimated = 4;

    private static final int KBlocksExlopding = 5;

    private static final int KIndestructibleBlocks  = 6;

    private static final int KNumberOfOptions  = 7;

    private LevelOption[] iOptions = new LevelOption[ KNumberOfOptions ];



    public BreakOutLevelOptions( BreakOutLevelDataProvider aContainer, int aLevelNumber )
    {
        iContainer = aContainer;
        iLevelNumber = aLevelNumber;
        iLevelName = Integer.toString( iLevelNumber );

        iOptions[ KTagLine1 ] = new StringLevelOption( "Tagline 1", 20 );
        iOptions[ KTagLine2 ] = new StringLevelOption( "Tagline 2", 20 );
        iOptions[ KGradientBackground ] = new BooleanLevelOption( "Background Gradient", true );
        iOptions[ KStarsBackground ] = new BooleanLevelOption( "Background Stars", true );
        iOptions[ KStarsAnimated ] = new BooleanLevelOption( "Animate Stars", true );
        iOptions[ KBlocksExlopding ] = new BooleanLevelOption( "Blocks Exploding" );
        iOptions[ KIndestructibleBlocks ] = new BooleanLevelOption( "Indestructible Blocks", true );

        Assert.MAKE_SURE( KNumberOfOptions == iOptions.length );
    }

    public void setLevelNumber( int aIndex )
    {
        iLevelNumber = aIndex;
        iLevelName = Integer.toString( aIndex );
    }

    public void load( TDes8 aLevelData )
    {
        loadTagLines( aLevelData );
        loadOptions( aLevelData );
    }

    public void save( TDes8 aLevelData )
    {
        saveTagLines( aLevelData );
        saveOptions( aLevelData );
    }

    // From LevelOptions

    public String getLevelName()
    {
        return iLevelName;
    }

    public int getNumberOfOptions()
    {
        return iOptions.length;
    }

    public LevelOption getLevelOption( int aIndex )
    {
        return iOptions[ aIndex ];
    }

    // Implementation

    private void loadTagLines( TDes8 aLevelData )
    {
        String tagLine1 = extractString( aLevelData, iContainer.iDataBytesPerLine * 1, "|" ).trim();
        String tagLine2 = extractString( aLevelData, iContainer.iDataBytesPerLine * 2, "|" ).trim();

        iOptions[ KTagLine1 ].setValue( tagLine1 );
        iOptions[ KTagLine2 ].setValue( tagLine2 );
    }

    private void loadOptions( TDes8 aLevelData )
    {
        iOptions[ KGradientBackground ].setValue( new Boolean( false ) );
        iOptions[ KStarsBackground ].setValue( new Boolean( false ) );
        iOptions[ KStarsAnimated ].setValue( new Boolean( false ) );
        iOptions[ KBlocksExlopding ].setValue( new Boolean( false ) );
        iOptions[ KIndestructibleBlocks ].setValue( new Boolean( false ) );

        TDes8 options = aLevelData.mid( iContainer.iDataBytesPerLine * 4, iContainer.iDataBytesPerLine );
        for ( int idx = 0; idx < iContainer.iDataBytesPerLine - iContainer.iCharsAtEOL; idx++ )
        {
            int code = options.at( idx );
            if ( code == 'g' )
            {
                iOptions[ KGradientBackground ].setValue( new Boolean( true ) );
            }
            else if ( code == 's' )
            {
                iOptions[ KStarsBackground ].setValue( new Boolean( true ) );
            }
            else if ( code == 'S' )
            {
                iOptions[ KStarsAnimated ].setValue( new Boolean( true ) );
            }
            else if ( code == 'x' )
            {
                iOptions[ KBlocksExlopding ].setValue( new Boolean( true ) );
            }
            else if ( code == 'i' )
            {
                iOptions[ KIndestructibleBlocks ].setValue( new Boolean( true ) );
            }
            else if ( code == ' ' || code == '-' )
            {
                continue;
            }
            else
            {
                throw new IllegalArgumentException( "Unrecognized level option: " + ( char ) code + " (Code: " + code + ")" );
            }
        }
    }

    private void saveTagLines( TDes8 aLevelData )
    {
        String tagLine1 = padTagLineWithSpaces( iOptions[ KTagLine1 ].getValue().toString() );
        String tagLine2 = padTagLineWithSpaces( iOptions[ KTagLine2 ].getValue().toString() );

        TDes8 line1 = new TDes8( aLevelData, iContainer.iDataBytesPerLine * 1, iContainer.iDataBytesPerLine );
        TDes8 line2 = new TDes8( aLevelData, iContainer.iDataBytesPerLine * 2, iContainer.iDataBytesPerLine );
        for ( int idx = 0; idx < iContainer.iLevelTagLineLength; ++idx )
        {
            line1.set( idx, ( byte ) tagLine1.charAt( idx ) );
            line2.set( idx, ( byte ) tagLine2.charAt( idx ) );
        }

        line1.set( iContainer.iLevelTagLineLength, ( byte ) '|' );
        line2.set( iContainer.iLevelTagLineLength, ( byte ) '|' );
    }

    private void saveOptions( TDes8 aLevelData )
    {
        TDes8 options = aLevelData.mid( iContainer.iDataBytesPerLine * 4, iContainer.iDataBytesPerLine - iContainer.iCharsAtEOL );
        Mem.Fill( options, options.length(), ( byte ) ' ' );

        int writeIndex = 0;
        if ( retrieveBooleanOption( KGradientBackground ) )
        {
            options.set( writeIndex++, ( byte ) 'g' );
        }
        if ( retrieveBooleanOption( KStarsBackground ) )
        {
            options.set( writeIndex++, ( byte ) 's' );
        }
        if ( retrieveBooleanOption( KStarsAnimated ) )
        {
            options.set( writeIndex++, ( byte ) 'S' );
        }
        if ( retrieveBooleanOption( KBlocksExlopding ) )
        {
            options.set( writeIndex++, ( byte ) 'x' );
        }
        if ( retrieveBooleanOption( KIndestructibleBlocks ) )
        {
            options.set( writeIndex++, ( byte ) 'i' );
        }
    }

    private boolean retrieveBooleanOption( int aOptionIndex )
    {
        Boolean value = ( Boolean ) iOptions[ aOptionIndex ].getValue();
        boolean result = value.booleanValue();
        return result;
    }

    private String extractString( TDes8 aDataLine, int aStartIndex, String aDelimeterList )
    {
        StringBuffer buffer = new StringBuffer();
        for ( ; ; )
        {
            int code = aDataLine.at( aStartIndex );
            if ( aDelimeterList.indexOf( code ) != -1 )
            {
                break;
            }
            else if ( buffer.length() == iContainer.iDataBytesPerLine - iContainer.iCharsAtEOL )
            {
                break;
            }
            buffer.append( ( char ) code );
            ++aStartIndex;
        }
        return buffer.toString();
    }

    private String padTagLineWithSpaces( String aTagLine )
    {
        StringBuffer temp = new StringBuffer( aTagLine );
        while ( temp.length() < iContainer.iLevelTagLineLength )
        {
            temp.append( ' ' );
        }

        String result = temp.toString();
        return result.substring( 0, iContainer.iLevelTagLineLength );
    }
}
