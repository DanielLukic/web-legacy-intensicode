/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.core;

import de.intensicode.gled.domain.*;

import java.awt.Dimension;
import java.util.ArrayList;



class LevelDataContainerImpl implements LevelDataContainer
{
    private LevelDataProvider iProvider;

    private ArrayList iListeners = new ArrayList();

    private boolean iAmLocked;

    private ArrayList iRecentlyChanged = new ArrayList();

    private Integer iUpdateAllTag = new Integer( -1 );



    public LevelDataContainerImpl( Project aProject )
    {
        iProvider = aProject.getLevelDataProvider();
    }

    public void setProject( Project aNewProject )
    {
        iProvider = aNewProject.getLevelDataProvider();

        fireLevelDataChanged();
    }

    // From LevelDataContainer

    public void addListener( LevelDataContainerListener aListener )
    {
        iListeners.add( aListener );
    }

    public void setUpdateLock( boolean aUpdateLock )
    {
        if ( iAmLocked == aUpdateLock )
        {
            throw new IllegalStateException( "Lock already in use" );
        }

        iAmLocked = aUpdateLock;

        if ( iAmLocked == false )
        {
            int numberOfChanges = iRecentlyChanged.size();
            if ( numberOfChanges > 0 )
            {
                for ( int idx = 0; idx < numberOfChanges; idx++ )
                {
                    Integer changeInfo = ( Integer ) iRecentlyChanged.get( idx );
                    if ( changeInfo.intValue() == -1 )
                    {
                        fireLevelDataChanged();
                        break;
                    }
                    else
                    {
                        fireLevelDataChanged( changeInfo.intValue() );
                    }
                }
                iRecentlyChanged.clear();
            }
        }
    }

    // From LevelDataProvider

    public void load( byte[] aLevelData )
    {
        iProvider.load( aLevelData );
        fireLevelDataChanged();
    }

    public byte[] save()
    {
        return iProvider.save();
    }

    public int getNumberOfLevels()
    {
        return iProvider.getNumberOfLevels();
    }

    public Dimension getLevelSize()
    {
        return iProvider.getLevelSize();
    }

    public LevelData getLevelData( int aIdx )
    {
        return new EventHandlingLevelData( this, iProvider.getLevelData( aIdx ), aIdx );
    }

    public void addNewLevel()
    {
        iProvider.addNewLevel();
        fireLevelDataChanged();
    }

    public void cloneLevel( int aSelected )
    {
        iProvider.cloneLevel( aSelected );
        fireLevelDataChanged();
    }

    public void copyLevel( int aSourceLevel, int aDestinationLevel )
    {
        iProvider.copyLevel( aSourceLevel, aDestinationLevel );
        fireLevelDataChanged();
    }

    public void swapLevels( int aSourceLevel, int aDestinationLevel )
    {
        iProvider.swapLevels( aSourceLevel, aDestinationLevel );
        fireLevelDataChanged();
    }

    public void deleteLevel( int aLevelIndex )
    {
        iProvider.deleteLevel( aLevelIndex );
        fireLevelDataChanged();
    }

    // Implementation

    void fireLevelDataChanged()
    {
        if ( iAmLocked )
        {
            iRecentlyChanged.clear();
            iRecentlyChanged.add( iUpdateAllTag );
            return;
        }

        for ( int idx = 0; idx < iListeners.size(); idx++ )
        {
            LevelDataContainerListener listener = ( LevelDataContainerListener ) iListeners.get( idx );
            listener.onLevelDataChanged();
        }
    }

    void fireLevelDataChanged( int aLevelIndex )
    {
        if ( iAmLocked )
        {
            Integer changeInfo = new Integer( aLevelIndex );
            if ( iRecentlyChanged.contains( changeInfo ) == false )
            {
                iRecentlyChanged.add( changeInfo );
            }
            return;
        }

        for ( int idx = 0; idx < iListeners.size(); idx++ )
        {
            LevelDataContainerListener listener = ( LevelDataContainerListener ) iListeners.get( idx );
            listener.onLevelDataChanged( aLevelIndex );
        }
    }
}
