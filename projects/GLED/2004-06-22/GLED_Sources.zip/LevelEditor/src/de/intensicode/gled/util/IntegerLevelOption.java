/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.util;

import de.intensicode.gled.domain.LevelOption;



/**
 *
 */
public class IntegerLevelOption implements LevelOption, LevelOption.IntegerExtension
{
    private String iName;

    private int iMinValue;

    private int iMaxValue;

    Integer iValue = new Integer( 0 );



    public IntegerLevelOption( String aName, int aMinValue, int aMaxValue )
    {
        iName = aName;
        iMinValue = aMinValue;
        iMaxValue = aMaxValue;
    }

    // From LevelOption

    public int getType()
    {
        return KInteger;
    }

    public String getName()
    {
        return iName;
    }

    public Object getValue()
    {
        return iValue;
    }

    public void setValue( Object aNewValue )
    {
        iValue = ( Integer ) aNewValue;
    }

    public LevelOption.BooleanExtension getBooleanExtension()
    {
        throw new UnsupportedOperationException();
    }

    public LevelOption.IntegerExtension getIntegerExtension()
    {
        return this;
    }

    public LevelOption.StringExtension getStringExtension()
    {
        throw new UnsupportedOperationException();
    }

    // From IntegerExtension

    public int getMinValue()
    {
        return iMinValue;
    }

    public int getMaxValue()
    {
        return iMaxValue;
    }

    public int getIntegerValue()
    {
        return iValue.intValue();
    }
}
