
package de.intensicode.gled;

import junit.framework.TestCase;



public class DummyTest extends TestCase
{
    public DummyTest( String name )
    {
        super( name );
    }



    public void testSomething()
    {

    }
}
