/************************************************************************/
/* AppCore                   www.intensicode.de             Januar 2003 */
/************************************************************************/

package de.intensicode.core.logging;

import java.text.SimpleDateFormat;
import java.util.Date;



/**
 * Basisklasse fuer Log-Objekte. Stellt die Formatierung von Datumsangaben
 * bereit.
 * <p>
 * Siehe insbesondere {@link #isFromLoggingPackage isFromLoggingPackage}.
 */
public abstract class AbstractLogger implements Logger
{
    /**
     * Name des zum Log gehoerenden Moduls. Wird im Log hinter dem Datum
     * ausgegeben.
     */
    protected String iModuleName = null;

    /**
     * Format fuer Ausgabe des Datums.
     */
    protected SimpleDateFormat iDateFormat = new SimpleDateFormat( "yyyy/MM/dd HH:mm" );

    protected boolean iShowSourceInfo;

    protected boolean iShowFullInfo;



    // From Logger

    /**
     * Legt den Modulnamen fest der in Log-Eintraegen hinter dem Datum
     * erscheinen soll.
     */
    public void setModuleName( String aModuleName )
    {
        iModuleName = aModuleName;
    }

    /**
     * Legt das Format fuer die Datumsangabe fest. Wird <code>null</code>
     * oder "" uebergeben, wird kein Datum im Log ausgegeben.
     */
    public void setDateFormat( String aDateFormat )
    {
        if ( aDateFormat == null || aDateFormat.equals( "" ) == true )
        {
            iDateFormat = null;
        }
        else
        {
            iDateFormat = new SimpleDateFormat( aDateFormat );
        }
    }

    /**
     * Die Basisimplementierung macht nichts.
     */
    public void reset()
    {

    }

    public void showSourceInfo( boolean aYesNoFlag, boolean aShowFullInfoFlag )
    {
        iShowSourceInfo = aYesNoFlag;
        iShowFullInfo = aShowFullInfoFlag;
    }

    // From Object

    public abstract Object clone();

    // Protected Interface

    /**
     * Liefert das aktuelle Datum in formatierter Form.
     */
    protected String getDate()
    {
        if ( iDateFormat != null )
        {
            return iDateFormat.format( new Date() );
        }
        return "";
    }

    /**
     * Liefert Datum und Aufrufer in formatierter Form.
     */
    protected String getHeader()
    {
        StringBuffer header = new StringBuffer();
        if ( iDateFormat != null )
        {
            header.append( getDate() );
        }
        if ( iModuleName != null && iShowSourceInfo == false )
        {
            header.append( " [" );
            header.append( iModuleName );
            header.append( "]" );
        }
        else if ( iShowSourceInfo )
        {
            header.append( " [" );
            header.append( getSourceInfo() );
            header.append( "]" );
        }
        return header.toString();
    }

    protected static String getPackageFromClassName( String aFullName )
    {
        int lastDotPos = aFullName.lastIndexOf( "." );
        return aFullName.substring( 0, lastDotPos );
    }

    protected static String stripPackageFromClassName( String aFullName )
    {
        int lastDotPos = aFullName.lastIndexOf( "." );

        String name = aFullName.substring( lastDotPos + 1 );
        return name;
    }

    /**
     * Prueft ob ein Eintrag des Stack-Trace uebersprungen werden soll,
     * weil er zum Logging-Subsystem gehoert. Unterklassen muessen diese
     * Methode entsprechend ueberschreiben, falls sie sich in einem anderen
     * Paket befinden!
     */
    protected boolean isFromLoggingPackage( String aClassName )
    {
        String loggingPackage = getNameOfLoggingPackage();
        return aClassName.startsWith( loggingPackage );
    }

    // Implementation

    private String getSourceInfo()
    {
        Throwable dummy = new Throwable();
        StackTraceElement[] stack = dummy.getStackTrace();
        for ( int idx = 0; idx < stack.length; idx++ )
        {
            if ( isFromLoggingPackage( stack[ idx ].getClassName() ) )
            {
                continue;
            }
            return formatSourceInfo( stack[ idx ] );
        }
        return formatSourceInfo( stack[ 0 ] );
    }

    private String formatSourceInfo( StackTraceElement aStackTraceElement )
    {
        StringBuffer result = new StringBuffer();
        result.append( getClassName( aStackTraceElement ) );
        result.append( ':' );
        result.append( aStackTraceElement.getMethodName() );
        result.append( '(' );
        result.append( aStackTraceElement.getLineNumber() );
        result.append( ')' );
        return result.toString();
    }

    private String getClassName( StackTraceElement aStackTraceElement )
    {
        String result = aStackTraceElement.getClassName();
        if ( iShowFullInfo )
        {
            return result;
        }
        else
        {
            return stripPackageFromClassName( result );
        }
    }

    private String getNameOfLoggingPackage()
    {
        return getPackageFromClassName( Logging.class.getName() );
    }
}
