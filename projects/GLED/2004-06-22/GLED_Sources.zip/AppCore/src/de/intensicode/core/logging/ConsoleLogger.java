/************************************************************************/
/* AppCore                   www.intensicode.de             Januar 2003 */
/************************************************************************/

package de.intensicode.core.logging;



/**
 * Log fuer die Ausgabe von Meldungen auf die Konsole.
 */
public class ConsoleLogger extends AbstractLogger
{
    public void print( String msg )
    {
        System.out.println( getHeader() + " " + msg );
    }

    public Object clone()
    {
        return new ConsoleLogger();
    }
}
