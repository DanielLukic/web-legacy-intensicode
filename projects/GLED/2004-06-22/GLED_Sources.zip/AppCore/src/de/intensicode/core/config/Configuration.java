/************************************************************************/
/* AppCore              www.intensicode.de                    Juni 2002 */
/************************************************************************/

package de.intensicode.core.config;

import de.intensicode.core.ResourceManager;
import de.intensicode.core.logging.Log;

import java.io.IOException;
import java.net.URL;
import java.security.AccessControlException;
import java.util.Properties;



/**
 * Verwaltet die Konfiguration des GIS Server Systems. Liest die
 * Konfiguration aus einem Property-File und stellt die enthaltenen
 * Einstellungen ueber die
 * {@link java.util.Properties Properties}-Schnittstelle bereit.
 * <p>
 * Dabei wird in der {@link #get get}-Methode eine Exception geworfen, wenn
 * ein Schluessel nicht definiert ist. Soll dieses Verhalten umgangen
 * werde, koennen die Methoden der
 * {@link java.util.Properties Properties}-Schnittstelle verwendet werden.
 * Oder man verwendet die Methoden mit Uebergabe eines Default-Werts.
 */
public class Configuration extends Properties
{
    private static Log iLog = Log.getLog( "Configuration" );



    /**
     * Erzeugt eine neue Konfiguration ohne Eintraege.
     */
    public Configuration()
    {

    }

    /**
     * Initialisiert die Konfiguration auf Basis der angegebenen
     * Konfigurationsdatei (Property-File).
     */
    public Configuration( String aConfigName ) throws ConfigurationException
    {
        load( aConfigName );
    }

    /**
     * Laedt die angegebene Konfigurationsdatei zu den aktuellen Eintragen
     * hinzu - falls sie existiert und lesbar ist. Ist sie nicht vorhanden
     * oder nicht lesbar passiert gar nichts.
     * <p>
     * Diese Methode eignet sich insbesondere fuer das Lesen von Defaults.
     */
    public void loadIfExists( String aConfigName )
    {
        try
        {
            load( aConfigName );
        }
        catch ( ConfigurationException ex )
        {
            iLog.warn( "Failed loading " + aConfigName );
        }
    }

    /**
     * Liefert den Wert zum angegebenen Schluessel.
     *
     * @throws de.intensicode.core.config.ConfigurationException falls fuer den
     * angegebenen Schluessel kein Wert definiert ist.
     */
    public String get( String key ) throws ConfigurationException
    {
        return getString( key );
    }

    /**
     * Liefert den Wert zum angegebenen Schluessel oder den uebergebenen
     * Default-Wert, falls der Schluessel in der Konfiguration nicht
     * definiert ist.
     */
    public String get( String key, String defaultValue )
    {
        return getProperty( key, defaultValue );
    }

    /**
     * Liefert den Wert zum angegebenen Schluessel als String.
     *
     * @throws de.intensicode.core.config.ConfigurationException falls fuer den
     * angegebenen Schluessel kein Wert definiert ist.
     */
    public String getString( String key ) throws ConfigurationException
    {
        String value = getProperty( key );
        if ( value == null )
        {
            throw new ConfigurationException( "Configuration has no value for " + key );
        }
        return value;
    }

    /**
     * Liefert den Wert zum angegebenen Schluessel als String.
     */
    public String getString( String key, String defaultValue )
    {
        return getProperty( key, defaultValue );
    }

    /**
     * Liefert den Wert zum angegebenen Schluessel als Integer.
     *
     * @throws de.intensicode.core.config.ConfigurationException falls es sich
     * beim definierten Wert um keine Zahl handelt oder kein Wert definiert
     * ist.
     */
    public int getInt( String key ) throws ConfigurationException
    {
        Integer result = getInteger( key );
        return result.intValue();
    }

    /**
     * Liefert den Wert zum angegebenen Schluessel als Integer, oder den
     * uebergebenen Default-Wert, falls in der Konfiguration kein Wert
     * angegeben ist.
     */
    public int getInt( String key, int defaultValue )
    {
        try
        {
            Integer result = getInteger( key, new Integer( defaultValue ) );
            return result.intValue();
        }
        catch ( ConfigurationException e )
        {
            return defaultValue;
        }
    }

    /**
     * Liefert den Wert zum angegebenen Schluessel als Integer.
     *
     * @throws de.intensicode.core.config.ConfigurationException falls es sich
     * beim definierten Wert um keine Zahl handelt oder kein Wert definiert
     * ist.
     */
    public Integer getInteger( String key ) throws ConfigurationException
    {
        String value = getString( key );
        try
        {
            return new Integer( value );
        }
        catch ( NumberFormatException nfEx )
        {
            throw new ConfigurationException( "Not a number: " + value );
        }
    }

    /**
     * Liefert den Wert zum angegebenen Schluessel als Integer, oder den
     * uebergebenen Default-Wert, falls in der Konfiguration kein Wert
     * angegeben ist.
     *
     * @throws de.intensicode.core.config.ConfigurationException falls es sich
     * beim definierten Wert um keine Zahl handelt.
     */
    public Integer getInteger( String key, Integer defaultValue ) throws ConfigurationException
    {
        String value = getProperty( key );
        if ( value == null )
        {
            return defaultValue;
        }
        try
        {
            return new Integer( value );
        }
        catch ( NumberFormatException nfEx )
        {
            throw new ConfigurationException( "Not a number: " + value );
        }
    }

    /**
     * Liefert den Wert zum angegebenen Schluessel als Double.
     *
     * @throws de.intensicode.core.config.ConfigurationException falls es sich
     * beim definierten Wert um keine Zahl handelt oder kein Wert definiert
     * ist.
     */
    public Double getDouble( String key ) throws ConfigurationException
    {
        String value = getString( key );
        try
        {
            return new Double( value );
        }
        catch ( NumberFormatException nfEx )
        {
            throw new ConfigurationException( "Not a number: " + value );
        }
    }

    /**
     * Liefert den Wert zum angegebenen Schluessel als Double.
     *
     * @throws de.intensicode.core.config.ConfigurationException falls es sich
     * beim definierten Wert um keine Zahl handelt.
     */
    public Double getDouble( String key, Double defaultValue ) throws ConfigurationException
    {
        String value = getProperty( key );
        if ( value == null )
        {
            return defaultValue;
        }
        try
        {
            return new Double( value );
        }
        catch ( NumberFormatException nfEx )
        {
            throw new ConfigurationException( "Not a number: " + value );
        }
    }

    public double getDoubleValue( String aKey ) throws ConfigurationException
    {
        Double value = getDouble( aKey );
        return value.doubleValue();
    }

    public double getDoubleValue( String aKey, double aDefault ) throws ConfigurationException
    {
        Double value = getDouble( aKey, new Double( aDefault ) );
        return value.doubleValue();
    }

    /**
     * Liefert den Wert zum angegebenen Schluessel als Double.
     *
     * @throws de.intensicode.core.config.ConfigurationException falls es sich
     * beim definierten Wert um keine Zahl handelt oder kein Wert definiert
     * ist.
     */
    public Long getLong( String key ) throws ConfigurationException
    {
        String value = getString( key );
        try
        {
            return new Long( value );
        }
        catch ( NumberFormatException nfEx )
        {
            throw new ConfigurationException( "Not a number: " + value );
        }
    }

    /**
     * Liefert den Wert zum angegebenen Schluessel als Double.
     *
     * @throws de.intensicode.core.config.ConfigurationException falls es sich
     * beim definierten Wert um keine Zahl handelt.
     */
    public Long getLong( String key, Long defaultValue ) throws ConfigurationException
    {
        String value = getProperty( key );
        if ( value == null )
        {
            return defaultValue;
        }
        try
        {
            return new Long( value );
        }
        catch ( NumberFormatException nfEx )
        {
            throw new ConfigurationException( "Not a number: " + value );
        }
    }

    public long getLongValue( String aKey ) throws ConfigurationException
    {
        Long value = getLong( aKey );
        return value.longValue();
    }

    /**
     * Liefert <code>true</code> wenn der angegebene Schluessel in der
     * Konfiguration enthalten ist und ihm der String <code>true</code>
     * zugewiesen ist.
     *
     * @throws de.intensicode.core.config.ConfigurationException falls kein Wert
     * definiert ist.
     */
    public boolean getBoolean( String key ) throws ConfigurationException
    {
        String value = get( key );
        return new Boolean( value ).booleanValue();
    }

    /**
     * Liefert <code>true</code> wenn der angegebene Schluessel in der
     * Konfiguration enthalten ist und ihm der String <code>true</code>
     * zugewiesen ist. Ist der Schluessel nicht definiert wird der
     * uebergebene Default-Wert geliefert.
     */
    public boolean getBoolean( String key, boolean defaultValue )
    {
        String value = get( key, null );
        if ( value == null )
        {
            return defaultValue;
        }
        return new Boolean( value ).booleanValue();
    }

    /**
     * Liefert das Objekt zum angegebenen Schluessel oder <code>null</code>
     * falls der Schluesel nicht definiert ist.
     */
    public Object getObject( String key )
    {
        return super.get( key );
    }

    /**
     * Liefert das Objekt zum angegebenen Schluessel als Double.
     */
    public Object getObject( String key, Object defaultValue ) throws ConfigurationException
    {
        Object value = super.get( key );
        if ( value == null )
        {
            return defaultValue;
        }
        return value;
    }

    /**
     * Liefert eine neue Konfiguration auf Basis des Werts des angegebenen
     * Schluessels.
     */
    public Configuration getConfiguration( String key ) throws ConfigurationException
    {
        String configName = get( key );
        return new Configuration( configName );
    }

    // Implementation

    private void load( String aConfigName ) throws ConfigurationException
    {
        if ( iLog != null )
        {
            iLog.info( "Loading " + aConfigName );
        }
        try
        {
            URL source = ResourceManager.getResource( aConfigName );
            if ( source == null )
            {
                throw new ConfigurationException( "Unknown resource: " + aConfigName );
            }
            super.load( source.openStream() );
        }
        catch ( AccessControlException acEx )
        {
            // Assuming applet context.
        }
        catch ( IOException ioEx )
        {
            throw new ConfigurationException( "Could not open configuration file - " + ioEx.getMessage(), ioEx );
        }
    }
}
