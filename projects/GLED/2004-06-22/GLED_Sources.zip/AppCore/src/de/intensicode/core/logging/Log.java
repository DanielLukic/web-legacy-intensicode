/************************************************************************/
/* AppCore                www.intensicode.de                  Juni 2002 */
/************************************************************************/

package de.intensicode.core.logging;

import de.intensicode.core.Assert;
import de.intensicode.core.config.Configuration;
import de.intensicode.core.config.ConfigurationException;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.security.AccessControlException;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.StringTokenizer;



/**
 * Allgemeine Basisklasse fuer das Logging. Ermoeglicht das Ausgeben von
 * informativen Meldungen, Warnungen und Fehlern. Dazu koennen diesen drei
 * Log-Leveln individuell Logger-Objekte zugeordnet werden.
 */
public class Log
{
    private ArrayList allLoggers = new ArrayList();

    /**
     * Enthalet die Logger-Objekte fuer informative Meldungen.
     */
    protected ArrayList iInfoLogs = new ArrayList();

    /**
     * Enthalet die Logger-Objekte fuer Warnungen.
     */
    protected ArrayList iWarnLogs = new ArrayList();

    /**
     * Enthalet die Logger-Objekte fuer Fehlermeldungen.
     */
    protected ArrayList iErrorLogs = new ArrayList();

    /**
     * Name des Moduls welches Ausgaben in das Log schreibt.
     */
    protected String iModuleName = null;

    /**
     * Aktuell gesetzter Verbosity-Level.
     */
    protected int iLogLevel = Logging.KDefaultLogLevel;

    /**
     * Aktuell gesetztes Datumsformat fuer Log-Ausgaben.
     */
    protected String iDateFormat = Logging.KDefaultDateFormat;



    /**
     * Liefert ein Log fuer den angegebene Modulnamen.
     */
    public static Log getLog( String aModuleName )
    {
        try
        {
            return Logging.getLog( aModuleName );
        }
        catch ( AccessControlException acEx )
        {
            Logging.error( "Security exception. Assuming applet context: " + acEx );
            return new DummyLog();
        }
        catch ( ConfigurationException cEx )
        {
            Logging.error( "Failed creating iLog for " + aModuleName, cEx );
            return new BackupLog( aModuleName );
        }
    }

    /**
     * Gibt eine Meldung aus, wobei diese aus dem angegebenen
     * Resource-Bundle gelesen wird.
     */
    public void info( ResourceBundle aBundle, String aID )
    {
        info( aBundle.getString( aID ) );
    }

    /**
     * Gibt eine informative Meldung in das Log-File aus.
     */
    public void info( String msg )
    {
        if ( iLogLevel >= Logging.KLogLevelAll )
        {
            print( iInfoLogs, "[INFO] " + msg );
        }
    }

    /**
     * Gibt eine Warnung in das Log-File aus.
     */
    public void warn( String msg )
    {
        if ( iLogLevel >= Logging.KLogLevelWarnings )
        {
            print( iWarnLogs, "[WARN] " + msg );
        }
    }

    /**
     * Gibt eine Fehlermeldung in das Log-File aus.
     */
    public void error( String msg )
    {
        if ( iLogLevel >= Logging.KLogLevelErrors )
        {
            print( iErrorLogs, "[ERROR] " + msg );
        }
    }

    /**
     * Gibt eine Fehlermeldung mit assoziierter Exception in das Log-File
     * aus.
     */
    public void error( String msg, Throwable t )
    {
        if ( iLogLevel >= Logging.KLogLevelErrors )
        {
            error( t );
            print( iErrorLogs, "[ERROR] " + msg );
        }
    }

    /**
     * Gibt eine Exception in das Log-File aus.
     */
    public void error( Throwable t )
    {
        if ( iLogLevel >= Logging.KLogLevelErrors )
        {
            StringWriter string = new StringWriter();
            PrintWriter writer = new PrintWriter( string );
            t.printStackTrace( writer );

            print( iErrorLogs, "[ERROR] " + string.getBuffer().toString() );
        }
    }

    public static Log getLog( Class aModuleClass )
    {
        return getLog( stripPackageFromClassName( aModuleClass.getName() ) );
    }

    public static Log getLog()
    {
        Throwable temp = new Throwable();
        StackTraceElement[] stack = temp.getStackTrace();
        Assert.MAKE_SURE( stack.length >= 2 );
        String fullName = stack[ 1 ].getClassName();
        return getLog( stripPackageFromClassName( fullName ) );
    }

    public static Log getLog( String loggerName, String moduleName )
    {
        Log result = new Log( moduleName );
        result.setLogger( Logging.getRegisteredLogger( loggerName ) );
        return result;
    }

    public void setLogger( Logger logger )
    {
        logger.setModuleName( iModuleName );
        logger.setDateFormat( iDateFormat );

        iInfoLogs.clear();
        iInfoLogs.add( logger );
        iWarnLogs.clear();
        iWarnLogs.add( logger );
        iErrorLogs.clear();
        iErrorLogs.add( logger );
    }

    // Protected Interface

    /**
     * Initialisiert ein Log-Objekt fuer das Modul mit dem angegebenen
     * Namen ohne eine Konfiguration festzulegen.
     */
    protected Log( String aModuleName )
    {
        iModuleName = aModuleName;
    }

    /**
     * Initialisiert ein Log-Objekt fuer das Modul mit dem angegebenen
     * Namen.
     */
    protected Log( String aModuleName, Configuration aConfig ) throws ConfigurationException
    {
        this( aModuleName );

        if ( aConfig == null )
        {
            throw new IllegalArgumentException( "Configuration is null" );
        }

        iModuleName = aModuleName;
        iLogLevel = aConfig.getInt( "LOGGING_LEVEL", Logging.KDefaultLogLevel );
        iDateFormat = aConfig.get( "DATEFORMAT", Logging.KDefaultDateFormat );

        addLoggers( iInfoLogs, aConfig.get( "INFO_LOG", Logging.KDefaultInfoLog ) );
        addLoggers( iWarnLogs, aConfig.get( "WARN_LOG", Logging.KDefaultWarnLog ) );
        addLoggers( iErrorLogs, aConfig.get( "ERROR_LOG", Logging.KDefaultErrorLog ) );

        boolean reset = aConfig.getBoolean( "RESET_LOGS", Logging.DEFAULT_RESET );
        if ( reset )
        {
            resetLogs();
        }

        String showSourceInfo = aConfig.get( "SHOW_SOURCE_INFO", Logging.DEFAULT_SOURCE_INFO ).toUpperCase();
        if ( showSourceInfo.equals( "SHORT" ) )
        {
            activateSourceInfo( false );
        }
        else if ( showSourceInfo.equals( "FULL" ) )
        {
            activateSourceInfo( true );
        }
        else if ( showSourceInfo.equals( "NO" ) == false )
        {
            throw new ConfigurationException( "Invalid value for SHOW_SOURCE_INFO: " + showSourceInfo );
        }
    }

    /**
     * Haengt die in der Liste <code>config</code> angegebenen Logs in die
     * uebergebene Log-Liste.
     */
    protected void addLoggers( ArrayList logs, String config )
    {
        StringTokenizer tokens = new StringTokenizer( config, "," );
        while ( tokens.hasMoreTokens() == true )
        {
            String logConfig = tokens.nextToken();
            addLogger( logs, logConfig );
        }
    }

    /**
     * Versucht die uebergebene Log-Konfiguration (Name mit ggf vorhandenen
     * Parametern, abgetrennt durch einen Doppelpunkt) zu erkennen und ein
     * entsprechendes Log-Objekt in die angegebene Log-Liste zu haengen.
     */
    protected void addLogger( ArrayList loggers, String config )
    {
        Logger logger = null;
        if ( config.startsWith( "Console" ) == true )
        {
            logger = new ConsoleLogger();
        }
        else if ( config.startsWith( "File" ) == true )
        {
            logger = new FileLogger( config.substring( 5 ) );
        }
        else if ( config.startsWith( "Applet" ) == true )
        {
            logger = new AppletLogger();
        }
        else
        {
            // Ansonsten wird der Eintrag als registrierter Logger
            // betrachtet:
            logger = Logging.getRegisteredLogger( config );
        }

        logger.setModuleName( iModuleName );
        logger.setDateFormat( iDateFormat );
        loggers.add( logger );

        allLoggers.add( logger );
    }

    protected synchronized void print( ArrayList logs, String msg )
    {
        for ( int idx = 0; idx < logs.size(); idx++ )
        {
            Logger logger = ( Logger ) logs.get( idx );
            logger.print( msg );
        }
    }

    // Implementation

    private void activateSourceInfo( boolean aShowFullInfoFlag )
    {
        for ( int idx = 0; idx < allLoggers.size(); idx++ )
        {
            Logger logger = ( Logger ) allLoggers.get( idx );
            logger.showSourceInfo( true, aShowFullInfoFlag );
        }
    }

    private void resetLogs()
    {
        for ( int idx = 0; idx < allLoggers.size(); idx++ )
        {
            Logger logger = ( Logger ) allLoggers.get( idx );
            logger.reset();
        }
    }

    private static String stripPackageFromClassName( String aFullName )
    {
        int lastDotPos = aFullName.lastIndexOf( "." );
        return aFullName.substring( lastDotPos + 1 );
    }
}
