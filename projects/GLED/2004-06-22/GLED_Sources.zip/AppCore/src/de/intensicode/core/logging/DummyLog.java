/************************************************************************/
/* Gimolus3D        Vivatech Software Berlin GmbH           Januar 2003 */
/************************************************************************/

package de.intensicode.core.logging;



/**
 * Dummy-Log falls im Applet-Context verwendet.
 */
public class DummyLog extends Log {

    DummyLog( ) {

        super( "AppletDummy" );

    }

}
