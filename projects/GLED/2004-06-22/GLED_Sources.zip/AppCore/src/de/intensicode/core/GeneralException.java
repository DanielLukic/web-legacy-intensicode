/************************************************************************/
/* GIS Server           VIVATECH Software Berlin GmbH         Juni 2002 */
/************************************************************************/

package de.intensicode.core;

/**
 * Allgemeine Basisklasse fuer Ausnahmen.
 */
public class GeneralException extends Exception {

  /**
   * Erzeugt eine neue Ausnahme mit der uebergebenen Fehlermeldung.
   */
  public GeneralException(String message) {

    super(message);

  } // GeneralException(String)



  /**
   * Erzeugt eine neue Ausnahme mit der uebergebenen Fehlermeldung und der
   * uebergebene Ausnahme als Grund.
   */
  public GeneralException(String message, Throwable cause) {

    super(message + "\nCaused by: " + cause.getMessage(), cause);

  } // GeneralException(String, Throwable)



  /**
   * Erzeugt eine neue Ausnahme mit der uebergebenen Ausnahme als Grund.
   */
  public GeneralException(Throwable cause) {

    super(cause.getMessage(), cause);

  } // GeneralException(Throwable)

} // class GeneralException
