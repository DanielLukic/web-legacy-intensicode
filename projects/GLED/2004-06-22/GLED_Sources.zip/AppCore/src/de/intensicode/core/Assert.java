/************************************************************************/
/* Core Library              www.intensicode.de               Juni 2003 */
/************************************************************************/

package de.intensicode.core;



/**
 * Hilfsklasse fuer die Bereitstellung einer Assertion-Schnittstelle wie
 * sie im SmartNav Projekt (Symbian) verwendet wird.
 */
public class Assert
{
    public static void MAKE_SURE( boolean aCondition )
    {
        MAKE_SURE( null, null, aCondition );
    }

    public static void MAKE_SURE( String aMessage, boolean aCondition )
    {
        MAKE_SURE( null, aMessage, aCondition );
    }

    public static void MAKE_SURE( String aReasonCode, String aMessage, boolean aCondition )
    {
        if ( aCondition == false )
        {
            StringBuffer msg = new StringBuffer( "Assertion failed: " );
            if ( aMessage != null )
            {
                msg.append( aMessage );
                msg.append( ' ' );
            }
            if ( aReasonCode != null )
            {
                msg.append( '[' );
                msg.append( aReasonCode );
                msg.append( ']' );
            }

            System.err.println( msg );

            StackTraceElement[] traces = new Throwable().getStackTrace();
            for ( int idx = 0; idx < traces.length; idx++ )
            {
                String className = traces[ idx ].getClassName();
                if ( className.equals( Assert.class.getName() ) == true )
                    continue;

                System.err.println( "  at " + traces[ idx ].toString() );
            }
            System.err.flush();

            System.exit( 10 );
        }
    }

    public static void MAKE_SURE( int aValue, boolean aCondition )
    {
        String message = "Invalid value: " + aValue;
        MAKE_SURE( message, aCondition );
    }
}
