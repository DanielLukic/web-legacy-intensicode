/************************************************************************/
/* Core Library              www.intensicode.de               Juni 2003 */
/************************************************************************/

package de.intensicode.core;



/**
 * Primitive Basisklasse welche als Ersatz fuer <code>enum</code> verwendet
 * werden kann.
 */
public abstract class Enumeration
{
    private String iTag;



    protected Enumeration( String aTag )
    {
        iTag = aTag;
    }

    // From Object

    public boolean equals( Object obj )
    {
        if ( obj instanceof Enumeration == false )
        {
            throw new IllegalArgumentException( "Incompatible object" );
        }
        Enumeration that = ( Enumeration ) obj;
        return iTag.equals( that.iTag );
    }
}
