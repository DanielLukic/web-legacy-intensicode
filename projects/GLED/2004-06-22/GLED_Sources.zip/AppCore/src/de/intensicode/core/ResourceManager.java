/************************************************************************/
/* AppCore                www.intensicode.de                Januar 2003 */
/************************************************************************/

package de.intensicode.core;

import de.intensicode.core.logging.Log;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.MissingResourceException;
import java.util.ResourceBundle;



/**
 * Hilfsklasse fuer das Laden der Resourcen (Fehlermeldungen usw).
 */
public class ResourceManager
{
    private static Log iLog = Log.getLog( "ResourceManager" );



    public static URL getResource( String aResourceName )
    {
        if ( iLog != null )
        {
            iLog.info( "Loading resource " + aResourceName );
        }
        return ResourceManager.class.getResource( aResourceName );
    }

    public static InputStream getResourceAsStream( String aResourceName )
    {
        URL resource = getResource( aResourceName );
        if ( resource == null )
        {
            return null;
        }
        try
        {
            return resource.openStream();
        }
        catch ( IOException ex )
        {
            return null;
        }
    }

    /**
     * Laedt die Resourcen fuer das durch den Namen spezifizierte "Modul"
     * aus dem <code>res/bundles/</code> Verzeichnis.
     */
    public static ResourceBundle getBundle( String aBundleName )
    {
        if ( iLog != null )
        {
            iLog.info( "Loading resource bundle " + aBundleName );
        }

        String basename = "bundles/" + aBundleName;
        try
        {
            return ResourceBundle.getBundle( basename );
        }
        catch ( MissingResourceException mrEx )
        {
            throw new RuntimeException
                    ( "Failed loading resource file.\nPlease consult the "
                    + "System Administrator.\nSee the console window for "
                    + "details.\n", mrEx );
        }
    }
}
