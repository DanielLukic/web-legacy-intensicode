/************************************************************************/
/* Core Library              www.intensicode.de               Juni 2003 */
/************************************************************************/

package de.intensicode.core.util;

import de.intensicode.core.logging.Log;

import java.util.ArrayList;
import java.util.Collection;
import java.util.ConcurrentModificationException;
import java.util.Iterator;



/**
 * Einfacher, auf {@link java.util.Collection Collection}s operierender,
 * Praedikat-Finder.
 */
public class PredicateFinder
{

    private static Log iLog = Log.getLog();



    /**
     * Liefert die passenden Objekte.
     */
    public static Collection Find( Iterator aIterator, FindPredicate aPredicate )
    {

        ArrayList result = new ArrayList();
        while ( aIterator.hasNext() == true )
        {

            Object item = aIterator.next();
            if ( aPredicate.IsMatch( item ) )
                result.add( item );
        }

        return ( result );

    }

    /**
     * Liefert die passenden Objekte.
     */
    public static Collection Find( Collection aCollection, FindPredicate aPredicate )
    {

        return ( Find( aCollection.iterator(), aPredicate ) );

    }

    /**
     * Liefert <code>null</code> falls kein passendes Objekt gefunden
     * wurde.
     */
    public static Object FindOnce( Iterator aIterator, FindPredicate aPredicate )
    {

        while ( aIterator.hasNext() == true )
        {

            Object item = aIterator.next();
            if ( aPredicate.IsMatch( item ) )
                return ( item );
        }

        return ( null );

    }

    /**
     * Liefert <code>null</code> falls kein passendes Objekt gefunden
     * wurde.
     */
    public static Object FindOnce( Collection aCollection, FindPredicate aPredicate )
    {

        while ( true )
        {
            try
            {
                return FindOnce( aCollection.iterator(), aPredicate );
            }
            catch ( ConcurrentModificationException ex )
            {
                iLog.error( "DIRTY FIX - IGNORING: " + ex );
            }
        }

    }

    /**
     * Liefert den ersten Index an dem sich ein auf das #aPredicate
     * passendes Objekt befindet. Liefert <code>-1</code> falls kein
     * passendes Objekt gefunden wurde.
     */
    public static int FindIndex( ArrayList aListOfItems, FindPredicate aPredicate )
    {

        for ( int idx = 0; idx < aListOfItems.size(); idx++ )
        {

            Object item = aListOfItems.get( idx );
            if ( aPredicate.IsMatch( item ) )
                return ( idx );
        }

        return ( -1 );

    }

}
