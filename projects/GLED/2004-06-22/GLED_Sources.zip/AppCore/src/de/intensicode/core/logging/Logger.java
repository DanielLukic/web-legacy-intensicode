/************************************************************************/
/* AppCore               www.intensicode.de                   Juni 2002 */
/************************************************************************/

package de.intensicode.core.logging;



/**
 * Schnittstelle fuer Log-Implementierungen.
 */
public interface Logger
{
    void setModuleName( String aModuleName );

    void setDateFormat( String aDateFormat );

    void showSourceInfo( boolean aYesNoFlag, boolean aShowFullInfoFlag );

    void print( String aMessage );

    void reset();

    Object clone();
}
