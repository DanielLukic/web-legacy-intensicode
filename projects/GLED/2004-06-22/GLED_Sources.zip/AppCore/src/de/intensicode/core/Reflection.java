/************************************************************************/
/* MapGEN           Vivatech Software Berlin GmbH           August 2000 */
/************************************************************************/

package de.intensicode.core;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;



/**
 * Aufsatz auf die Reflection-API von Java - ermoeglicht direkt das
 * Erzeugen von Klassen anhand ihres Namens und einer Liste von Parametern.
 */
public class Reflection
{
    public static Object createInstance( String name )
    {
        Class clazz = findClass( name );
        try
        {
            return clazz.newInstance();
        }
        catch ( InstantiationException ex )
        {
            throw new RethrownException( ex );
        }
        catch ( IllegalAccessException ex )
        {
            throw new RethrownException( ex );
        }
    }

    /**
     * Liefert eine neue Instanz einer durch ihren Namen spezifizierten
     * Klasse.
     * <p>
     * Dabei koennen die zu uebergebenden Parameter in einem Object-Array
     * uebergeben werden. Die Parameter duerfen nicht <code>null</code>
     * sein, da sie fuer die Bestimmung des Konstruktors benoetigt werden.
     * Sind Nullen moeglich, sollte die
     * {@link #createInstance(String,Class[],Object[]) diese} Methode
     * verwendet werden.
     */
    public static Object createInstance( String name, Object[] parameters )
    {
        Class[] types = determineTypes( parameters );
        return createInstance( name, types, parameters );
    }

    /**
     * Liefert eine neue Instanz einer durch ihren Namen spezifizierten
     * Klasse.
     * <p>
     * Dabei koennen die zu uebergebenden Parameter in einem Object-Array
     * uebergeben werden. Damit der richtige Konstruktor gefunden wird,
     * muessen die Typen der Parameter explizit im Class-Array uebergeben
     * werden. Die Parameter duerfen dehslb hier <code>null</code>
     * sein.
     */
    public static Object createInstance( String name, Class[] types, Object[] parameters )
    {
        // Klasse finden.
        Class clazz = findClass( name );

        // Klasse instanziieren.
        return createInstance( clazz, types, parameters );
    }

    /**
     * Instanziiert eine Klasse anhand einer Parameterliste.
     */
    public static Object createInstance( Class clazz, Object[] parameters )
    {
        Class[] types = determineTypes( parameters );
        return createInstance( clazz, types, parameters );
    }

    /**
     * Instanziiert eine Klasse anhand einer Parameterliste.
     */
    public static Object createInstance( Class clazz, Class[] types, Object[] parameters )
    {
        try
        {
            // Konstruktor bestimmen.
            Constructor constructor = clazz.getConstructor( types );

            // Klasse instanziieren.
            return instanciateClass( constructor, parameters );
        }
        catch ( NoSuchMethodException nsmEx )
        {
            throw new RethrownException( "No matching constructor", nsmEx );
        }
    }

    /**
     * Hilfsmethode: Bestimmt die Typen einer Liste von Parametern.
     */
    private static Class[] determineTypes( Object[] parameters )
    {
        Class[] types = new Class[ parameters.length ];

        // Typen der Parameter bestimmen. Achtung: Null-Pointer sind hier gar
        // nicht gut!
        for ( int idx = 0; idx < types.length; idx++ )
        {
            if ( parameters[ idx ] == null )
            {
                throw new IllegalArgumentException( "Parameter is null" );
            }
            types[ idx ] = parameters[ idx ].getClass();
        }
        return types;
    }

    /**
     * Hilfsmethode: Versucht die uebergebene Klasse (ggf. unqualifiziert,
     * also ohne Paketangabe) zu finden.
     */
    public static Class findClass( String aName )
    {
        try
        {
            return Class.forName( aName );
        }
        catch ( ClassNotFoundException cnfEx )
        {
            // Diese Ausnahme wird erstmal ignoriert.
        }

        // Klasse in allen Paketen suchen. Fuer den Fall das sie unqualifiziert
        // angegeben wurde.
        Package[] packages = Package.getPackages();
        for ( int idx = 0; idx < packages.length; idx++ )
        {
            Package pack = packages[ idx ];
            String fullyQualified = pack.getName() + "." + aName;
            try
            {
                Class clazz = Class.forName( fullyQualified );

                // Hierhin kommt man nur wenn die Klasse gefunden wurde und keine
                // Exception geworfen wurde!
                return clazz;
            }
            catch ( ClassNotFoundException cnfEx )
            {
                // Diese Ausnahme wird erstmal ignoriert.
            }
        }
        throw new RuntimeException( "Class not found - " + aName );
    }

    /**
     * Hilfsmethode: Instanziiert eine Klasse anhand eines uebergebenen
     * Konstruktors und einer Parameterliste.
     */
    private static Object instanciateClass( Constructor aConstructor, Object[] aParameters )
    {
        try
        {
            return aConstructor.newInstance( aParameters );
        }
        catch ( InvocationTargetException itEx )
        {
            throw new RethrownException( "Exception in initialization", itEx.getTargetException() );
        }
        catch ( IllegalAccessException iaEx )
        {
            throw new RethrownException( "Class could not be accessed", iaEx );
        }
        catch ( InstantiationException iEx )
        {
            throw new RethrownException( "Class could not be instanciated", iEx );
        }
    }
}
