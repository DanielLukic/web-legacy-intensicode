/************************************************************************/
/* Core Library              www.intensicode.de               Juni 2003 */
/************************************************************************/

package de.intensicode.core.io;

import java.io.IOException;
import java.io.RandomAccessFile;



/**
 * Hilfsfunktion fuer den Umgang mit Dateien.
 */
public class FileUtils {

	public static byte[] loadFile( String aInputFileName ) throws IOException {

        RandomAccessFile file = new RandomAccessFile( aInputFileName, "r" );
        byte[] result = new byte[ ( int ) file.length() ];
        file.readFully( result );

        return( result );

    }

}
