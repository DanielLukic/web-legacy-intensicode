/************************************************************************/
/* AppCore               www.intensicode.de                   Juni 2002 */
/************************************************************************/

package de.intensicode.core.logging;

import de.intensicode.core.config.Configuration;
import de.intensicode.core.config.ConfigurationException;

import java.security.AccessControlException;
import java.util.HashMap;
import java.util.Iterator;



/**
 * Einfache Klasse fuer das Logging der Ausgaben der diversen GIS-Server
 * Module.
 * <p>
 * Zentrale Idee dabei: Die Module melden sich mit ihrem Namen an. Das
 * Logging Subsystem laedt dann die entsprechenden Einstellungen und
 * konfiguriert seine Ausgaben (Konsole / Datei) entsprechend.
 * <p>
 * Dabei ist das System wesentlich einfacher aufgebaut als das der Java
 * API.
 */
public class Logging
{
    private static final String KDefaultConfigFileName = "/logging/Default.properties";

    /**
     * Dynamically registered {@link Logger Logger} implementations.
     */
    private static HashMap iRegisteredLoggers = new HashMap();

    /**
     * Enthaelt die zur Zeit bekannten Log-Objekte.
     */
    private static HashMap iKnownLogs = new HashMap();

    /**
     * Enthaelt das globale Log.
     */
    private static Log iGlobalLog;

    /**
     * Konfiguration fuer den Fall das ein Modul nicht speziell konfiguriert
     * wurde (mittels einer entsprechenden Properties-Datei in logging/.
     */
    private static Configuration iDefaults;


    // Definition der Verbosity-Level.

    public static final int KLogLevelNothing = 0;

    public static final int KLogLevelErrors = 1;

    public static final int KLogLevelWarnings = 2;

    public static final int KLogLevelAll = 3;


    // Festlegung von Defaults falls das Einlesen der Konfiguration nicht
    // klappt.

    public static final int KDefaultLogLevel = KLogLevelAll;

    public static boolean DEFAULT_RESET = false;

    public static String DEFAULT_SOURCE_INFO = "NO";

    public static String KDefaultInfoLog = "Console";

    public static String KDefaultWarnLog = "Console,File:log/Warnings.log";

    public static String KDefaultErrorLog = "Console,File:log/Errors.log";

    public static String KDefaultDateFormat = "yyyy/MM/dd HH:mm:ss";



    /**
     * Liefert ein Log-Objekt fuer den angegebenen Modulnamen.
     */
    public static synchronized Log getLog( String aModuleName ) throws ConfigurationException
    {
        Log log = ( Log ) iKnownLogs.get( aModuleName );
        if ( log == null )
        {
            Configuration config = getConfig( aModuleName );
            if ( config == null )
            {
                log = new Log( aModuleName );
            }
            else
            {
                log = new Log( aModuleName, config );
            }
            iKnownLogs.put( aModuleName, log );
        }
        return log;
    }

    public static void registerLogger( String aLoggerName, Logger aLoggerImpl )
    {
        iRegisteredLoggers.put( aLoggerName, aLoggerImpl );
    }

    public static Logger getRegisteredLogger( String aLoggerName )
    {
        Logger result = ( Logger ) iRegisteredLoggers.get( aLoggerName );
        if ( result == null )
        {
            throw new LoggingException( "Logger " + aLoggerName + " not registered" );
        }
        return ( Logger ) result.clone();
    }

    public static void setDefaultLogger( String aLoggerName )
    {
        KDefaultInfoLog = aLoggerName;
        KDefaultWarnLog = aLoggerName;
        KDefaultErrorLog = aLoggerName;

        warn( "Resetting configuration to use default logger " + aLoggerName );

        iDefaults = new Configuration();
        iDefaults.setProperty( "LOGGING_LEVEL", "" + KDefaultLogLevel );
        iDefaults.setProperty( "INFO_LOG", KDefaultInfoLog );
        iDefaults.setProperty( "WARN_LOG", KDefaultWarnLog );
        iDefaults.setProperty( "ERROR_LOG", KDefaultErrorLog );
        iDefaults.setProperty( "DATEFORMAT", KDefaultDateFormat );
    }

    public static void switchToLogger( Logger aLogger )
    {
        Iterator openLogs = iKnownLogs.keySet().iterator();
        while ( openLogs.hasNext() )
        {
            Log log = ( Log ) openLogs.next();
            log.setLogger( aLogger );
        }
    }

    /**
     * Gibt eine informative Meldung im globalen Log-File aus.
     */
    public static void info( String aMessage )
    {
        iGlobalLog.info( aMessage );
    }

    /**
     * Gibt eine Warnung im globalen Log-File aus.
     */
    public static void warn( String aMessage )
    {
        iGlobalLog.warn( aMessage );
    }

    /**
     * Gibt eine Fehlermeldung im globalen Log-File aus.
     */
    public static void error( String aMessage )
    {
        iGlobalLog.error( aMessage );
    }

    /**
     * Gibt eine Fehlermeldung im globalen Log-File aus.
     */
    public static void error( String aMessage, Throwable aThrowable )
    {
        iGlobalLog.error( aMessage, aThrowable );
    }

    /**
     * Gibt eine Fehlermeldung im globalen Log-File aus.
     */
    public static void error( Throwable aThrowable )
    {
        iGlobalLog.error( aThrowable );
    }

    // Implementation

    /**
     * Liefert die Konfiguration fuer den angegebenen Modulnamen.
     */
    private static synchronized Configuration getConfig( String aModuleName )
    {
        try
        {
            String configName = "/logging/" + aModuleName + ".properties";
            return new Configuration( configName );
        }
        catch ( ConfigurationException cEx )
        {
            Logging.warn( "Failed reading logging configuration for " + aModuleName );
            return iDefaults;
        }
    }

    /**
     * Initialisiert die Default-Settings.
     */
    private static void initDefaults()
    {
        try
        {
            iDefaults = new Configuration( KDefaultConfigFileName );
        }
        catch ( ConfigurationException cEx )
        {
            warn( "Failed reading default logging configuration. Setting defaults" );

            iDefaults = new Configuration();
            iDefaults.setProperty( "LOGGING_LEVEL", "" + KDefaultLogLevel );
            iDefaults.setProperty( "INFO_LOG", KDefaultInfoLog );
            iDefaults.setProperty( "WARN_LOG", KDefaultWarnLog );
            iDefaults.setProperty( "ERROR_LOG", KDefaultErrorLog );
            iDefaults.setProperty( "DATEFORMAT", KDefaultDateFormat );
        }
    }

    static
    {
        try
        {
            iGlobalLog = new BackupLog( "Global" );
            initDefaults();
            try
            {
                iGlobalLog = Logging.getLog( "Global" );
            }
            catch ( ConfigurationException cEx )
            {
                error( "Failed creating iGlobalLog iLog. Using iBackup console iLog" );
            }
        }
        catch ( AccessControlException acEx )
        {
            // Assuming applet context.
            iGlobalLog = new AppletLog( "Global" );
        }
    }
}
