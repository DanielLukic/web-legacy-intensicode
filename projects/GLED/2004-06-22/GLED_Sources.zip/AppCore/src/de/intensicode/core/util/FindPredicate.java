/************************************************************************/
/* Core Library              www.intensicode.de               Juni 2003 */
/************************************************************************/

package de.intensicode.core.util;



/**
 * Schnittstelle fuer ein einfaches Praedikat mit einem Argument.
 */
public interface FindPredicate {

    public boolean IsMatch( Object aObject );

}
