/************************************************************************/
/* Odysseus         Vivatech Software Berlin GmbH          Oktober 2000 */
/************************************************************************/

package de.intensicode.core;

/**
 * allgemeine Ausnahme fuer Fehler beim Geo-Coding.
 */
public class ReflectionException extends RethrownException {

  /**
   * Initialisiert die Ausnahme mit der uebergebenen Meldung.
   */
  public ReflectionException(String message, Exception cause) {

    super(message, cause);

  } // ReflectionException(String, Exception)



  /**
   * Initialisiert die Ausnahme mit der uebergebenen Meldung.
   */
  public ReflectionException(String message) {

    super(message);

  } // ReflectionException(String)

} // class ReflectionException
