/************************************************************************/
/* AppCore               www.intensicode.de                   Juni 2002 */
/************************************************************************/

package de.intensicode.core.logging;

import javax.swing.JTextArea;



/**
 * Log fuer die Ausgabe von Meldungen in ein TextField. Dabei muss das
 * TextField - ein statisches Feld - vom Applet initialisiert werden.
 */
public class AppletLogger extends AbstractLogger
{
    public static JTextArea iOutput = null;



    public AppletLogger()
    {

    }

    // From Logger

    public void print( String msg )
    {
        if ( iOutput == null )
        {
            return;
        }
        String fullMsg = getHeader() + " " + msg;
        iOutput.append( fullMsg );
        iOutput.append( "\n" );
    }

    // From AbstractLogger

    public Object clone()
    {
        return new AppletLogger();
    }
}
