/************************************************************************/
/* MUI                   www.intensicode.de               November 2002 */
/************************************************************************/

package de.intensicode.mui;

import java.awt.Toolkit;
import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JMenuItem;
import javax.swing.KeyStroke;



public class MUIMenuTextEntry extends MUIObject
{
    protected JMenuItem iEntry = null;



    public MUIMenuTextEntry( String aMenuText )
    {
        iEntry = new JMenuItem( aMenuText );
        init( iEntry, MUIPrefs.getMUIMenuEntryDefaults() );
    }

    public MUIMenuTextEntry( String aMenuText, int mnemonic )
    {
        iEntry = new JMenuItem( aMenuText, mnemonic );
        init( iEntry, MUIPrefs.getMUIMenuEntryDefaults() );
    }

    public MUIMenuTextEntry( Action aAction )
    {
        iEntry = new JMenuItem( aAction );
        init( iEntry, MUIPrefs.getMUIMenuEntryDefaults() );
    }

    public MUIMenuTextEntry setVisuals( String aIconName, String aShortCutName, int aShortCutCode )
    {
        iEntry.setAction( new MUIMenuAction( iEntry.getText(), aIconName, aShortCutName, aShortCutCode ) );
        return this;
    }



    public /*inner*/ class MUIMenuAction extends AbstractAction
    {
        public MUIMenuAction( String aName, String aIconResource, String aShortDescription, int aShortcut )
        {
            super( aName, MUIUtils.getIcon( aIconResource ) );

            int shortcutKeyMask = Toolkit.getDefaultToolkit().getMenuShortcutKeyMask();
            KeyStroke keyStroke = KeyStroke.getKeyStroke( aShortcut, shortcutKeyMask );

            putValue( Action.SHORT_DESCRIPTION, aShortDescription );
            putValue( Action.ACCELERATOR_KEY, keyStroke );
            putValue( Action.NAME, aName );
        }

        // From ActionListener

        public void actionPerformed( ActionEvent aEvent )
        {
            actionQueue.fire( aEvent );
        }
    }
}
