/************************************************************************/
/* MUI                      The.French.DJ                  Februar 2003 */
/************************************************************************/

package de.intensicode.mui;

import java.awt.event.ActionListener;

import javax.swing.JComboBox;
import javax.swing.JLabel;



/**
 * Stellt eine Combo-Box bereit.
 */
public class MUIComboBox extends MUIObject
{
    /**
     * Die eigentliche GUI-Komponente.
     */
    protected JComboBox combo = null;

    /**
     * Initialisiert eine Auswahlliste und weist ihr den angegebenen Namen
     * als ActionCommand zu.
     */
    public MUIComboBox( String name, Object[] items )
    {

        combo = new JComboBox( items );
        combo.addActionListener( this );
        combo.setActionCommand( name );

        init( combo, MUIPrefs.getMUIComboBoxDefaults() );

    } // MUIButton( String, Object[] )

    /**
     * Fuegt der Auswahlliste einen weiteren ActionListener hinzu. Als
     * ActionCommand wird der im Konstruktor uebergebene String geliefert.
     */
    public MUIComboBox addActionListener( ActionListener listener )
    {

        combo.addActionListener( listener );

        return ( this );

    } // MUIComboBox addActionListener( ActionListener )

    /**
     * Fuegt der Auswahlliste einen weiteren Eintrag hinzu.
     */
    public void addSelection( String selection )
    {

        combo.addItem( new JLabel( selection ) );

    } // void addSelection( String )

    /**
     * Liefert das aktuell ausgewaehlte Element.
     */
    public Object getSelectedItem()
    {

        return ( combo.getSelectedItem() );

    } // Object getSelectedItem()

    public void setSelectedItem( int aIdx )
    {
        combo.setSelectedIndex( aIdx );
    }

} // class MUIComboBox
