
package de.intensicode.mui;

import de.intensicode.core.ResourceManager;

import java.awt.*;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;

import javax.swing.*;
import javax.swing.plaf.basic.BasicTabbedPaneUI;
import javax.swing.text.View;



public class MUITabs extends MUIObject
{
    protected JTabbedPane iTabs = null;

    private boolean iVerticalLayout;



    public MUITabs()
    {
        this( true );
    }

    public MUITabs( boolean aVerticalLayout )
    {
        iVerticalLayout = aVerticalLayout;

        int layout = aVerticalLayout ? JTabbedPane.RIGHT : JTabbedPane.TOP;
        iTabs = new JTabbedPane( layout, JTabbedPane.SCROLL_TAB_LAYOUT );
        iTabs.setUI( new NewUI() );

        UIManager.put( "TabbedPane.background", Color.RED );

        init( iTabs, MUIPrefs.getMUITabsDefaults() );
    }

    public void addTab( String name, MUIComponent component )
    {
        addTab( name, null, component );
    }

    public void addTab( String name, String iconFilename, MUIComponent component )
    {
        ImageIcon icon = null;

        if ( iconFilename != null )
        {
            icon = new ImageIcon( ResourceManager.getResource( iconFilename ) );
        }

        iTabs.addTab( name, icon, component.getJava() );

        if ( component.getJava().getName() == null )
        {
            component.getJava().setName( name );
        }
    }

    public void removeAllTabs()
    {
        iTabs.removeAll();;
    }

    public void setTab( String name )
    {
        for ( int idx = 0; idx < iTabs.getTabCount(); idx++ )
        {
            Component comp = iTabs.getComponentAt( idx );

            if ( name.equals( comp.getName() ) )
            {
                iTabs.setSelectedComponent( comp );
            }
        }
    }



    class NewUI extends BasicTabbedPaneUI
    {
        protected int calculateMaxTabHeight( int tabPlacement )
        {
            FontMetrics metrics = getFontMetrics();
            int tabCount = tabPane.getTabCount();
            int result = 0;
            int fontHeight = metrics.getHeight();
            for ( int i = 0; i < tabCount; i++ )
            {
                result = Math.max( calculateTabHeight( tabPlacement, i, fontHeight ), result );
            }
            return result;
        }

        protected int calculateMaxTabWidth( int tabPlacement )
        {
            FontMetrics metrics = getFontMetrics();
            int tabCount = tabPane.getTabCount();
            int result = 0;
            for ( int i = 0; i < tabCount; i++ )
            {
                result = Math.max( calculateTabWidth( tabPlacement, i, metrics ), result );
            }
            return result;
        }

        protected int calculateTabAreaHeight( int tabPlacement, int horizRunCount, int maxTabHeight )
        {
            Insets tabAreaInsets = getTabAreaInsets( tabPlacement );
            int tabRunOverlay = getTabRunOverlay( tabPlacement );
            return ( horizRunCount > 0 ?
                    horizRunCount * ( maxTabHeight - tabRunOverlay ) + tabRunOverlay +
                    tabAreaInsets.top + tabAreaInsets.bottom :
                    0 );
        }

        protected int calculateTabAreaWidth( int tabPlacement, int vertRunCount, int maxTabWidth )
        {
            Insets tabAreaInsets = getTabAreaInsets( tabPlacement );
            int tabRunOverlay = getTabRunOverlay( tabPlacement );
            return ( vertRunCount > 0 ?
                    vertRunCount * ( maxTabWidth - tabRunOverlay ) + tabRunOverlay +
                    tabAreaInsets.left + tabAreaInsets.right :
                    0 );
        }

        protected int calculateTabHeight( int tabPlacement, int tabIndex, int fontHeight )
        {
            int height = 0;
            View v = getTextViewForTab( tabIndex );
            if ( v != null )
            {
                height += ( int ) v.getPreferredSpan( View.Y_AXIS );
            }
            else
            {
                FontMetrics metrics = getFontMetrics();
                String title = tabPane.getTitleAt( tabIndex );
                height += SwingUtilities.computeStringWidth( metrics, title );
            }
            Icon icon = getIconForTab( tabIndex );
            Insets tabInsets = getTabInsets( tabPlacement, tabIndex );

            if ( icon != null )
            {
                height += icon.getIconHeight();
                height += textIconGap;
            }

            height += tabInsets.top + tabInsets.bottom + 2;

            height += textIconGap * 2;

            return height;
        }

        protected int calculateTabWidth( int tabPlacement, int tabIndex, FontMetrics metrics )
        {
            Icon icon = getIconForTab( tabIndex );
            Insets tabInsets = getTabInsets( tabPlacement, tabIndex );
            int width = tabInsets.left + tabInsets.right + 3;
            int fontHeight = metrics.getHeight();

            if ( icon != null )
            {
                width = Math.max( width, icon.getIconWidth() );
            }
            View v = getTextViewForTab( tabIndex );
            if ( v != null )
            {
                width += ( int ) v.getPreferredSpan( View.X_AXIS );
            }
            else
            {
                width = Math.max( width, fontHeight );
            }

            return width;
        }

        protected void paintText( Graphics g, int tabPlacement,
                                  Font font, FontMetrics metrics, int tabIndex,
                                  String title, Rectangle textRect,
                                  boolean isSelected )
        {
            g.setFont( font );

            if ( isSelected )
            {
                g.setColor( tabPane.getForegroundAt( tabIndex ) );
                drawRotated( g, title, textRect.x, textRect.y, tabIndex, true );
            }
            else
            {
                g.setColor( tabPane.getForegroundAt( tabIndex ).darker() );
                drawRotated( g, title, textRect.x, textRect.y, tabIndex, false );
            }
        }

        protected void drawRotated( Graphics g, String text, int x, int y, int tabIdx, boolean isSelected )
        {
            FontMetrics m = getFontMetrics();
            Rectangle2D bounds = m.getStringBounds( text, g );

            int width = ( int ) bounds.getWidth();
            int height = ( int ) bounds.getHeight();

            BufferedImage temp = new BufferedImage( height, width, BufferedImage.TYPE_INT_RGB );

            Graphics2D g2d = ( Graphics2D ) temp.getGraphics();

            Color selectedColor = UIManager.getColor( "TabbedPane.selected" );

            if ( isSelected )
                g2d.setColor( selectedColor );
            else
                g2d.setColor( tabPane.getBackgroundAt( tabIdx ) );

            g2d.fillRect( 0, 0, height, width );
            g2d.setColor( g.getColor() );

            g2d.setFont( g.getFont() );
            if ( iVerticalLayout )
            g2d.rotate( Math.PI / 2 );
            g2d.drawString( text, 0, -m.getDescent() );
            if ( iVerticalLayout )
            g2d.rotate( -Math.PI / 2 );

            g.drawImage( temp, x, y, null );
        }

        protected void paintIcon( Graphics g, int tabPlacement,
                                  int tabIndex, Icon icon, Rectangle iconRect,
                                  boolean isSelected )
        {
            if ( icon != null )
            {
                icon.paintIcon( tabPane, g, iconRect.x, iconRect.y );
            }
        }

        protected void layoutLabel( int tabPlacement,
                                    FontMetrics metrics, int tabIndex,
                                    String title, Icon icon,
                                    Rectangle tabRect, Rectangle iconRect,
                                    Rectangle textRect, boolean isSelected )
        {
            textRect.x = textRect.y = iconRect.x = iconRect.y = 0;

            View v = getTextViewForTab( tabIndex );
            if ( v != null )
            {
                tabPane.putClientProperty( "html", v );
            }

            XXlayoutCompoundLabel( ( JComponent ) tabPane,
                    metrics, title, icon,
                    SwingUtilities.TOP,
                    SwingUtilities.CENTER,
                    SwingUtilities.TOP,
                    SwingUtilities.CENTER,
                    tabRect,
                    iconRect,
                    textRect,
                    textIconGap );

            tabPane.putClientProperty( "html", null );

            int xNudge = getTabLabelShiftX( tabPlacement, tabIndex, isSelected );
            int yNudge = getTabLabelShiftY( tabPlacement, tabIndex, isSelected );
            iconRect.x += xNudge / 2;
            iconRect.y += yNudge / 2;
            textRect.x += xNudge / 2;
            textRect.y += yNudge / 2;

        }



        /**
         * Compute and return the location of the icons origin, the
         * location of origin of the text baseline, and a possibly clipped
         * version of the compound labels string.  Locations are computed
         * relative to the viewR rectangle.
         * The JComponents orientation (LEADING/TRAILING) will also be taken
         * into account and translated into LEFT/RIGHT values accordingly.
         */
        public String XXlayoutCompoundLabel( JComponent c,
                                             FontMetrics fm,
                                             String text,
                                             Icon icon,
                                             int verticalAlignment,
                                             int horizontalAlignment,
                                             int verticalTextPosition,
                                             int horizontalTextPosition,
                                             Rectangle viewR,
                                             Rectangle iconR,
                                             Rectangle textR,
                                             int textIconGap )
        {
            boolean orientationIsLeftToRight = true;
            int hAlign = horizontalAlignment;
            int hTextPos = horizontalTextPosition;

            if ( c != null )
            {
                if ( !( c.getComponentOrientation().isLeftToRight() ) )
                {
                    orientationIsLeftToRight = false;
                }
            }

            // Translate LEADING/TRAILING values in horizontalAlignment
            // to LEFT/RIGHT values depending on the components orientation
            switch ( horizontalAlignment )
            {
                case LEADING:
                    hAlign = ( orientationIsLeftToRight ) ? LEFT : RIGHT;
                    break;
                case TRAILING:
                    hAlign = ( orientationIsLeftToRight ) ? RIGHT : LEFT;
                    break;
            }

            // Translate LEADING/TRAILING values in horizontalTextPosition
            // to LEFT/RIGHT values depending on the components orientation
            switch ( horizontalTextPosition )
            {
                case LEADING:
                    hTextPos = ( orientationIsLeftToRight ) ? LEFT : RIGHT;
                    break;
                case TRAILING:
                    hTextPos = ( orientationIsLeftToRight ) ? RIGHT : LEFT;
                    break;
            }

            return XXlayoutCompoundLabelImpl( c,
                    fm,
                    text,
                    icon,
                    verticalAlignment,
                    hAlign,
                    verticalTextPosition,
                    hTextPos,
                    viewR,
                    iconR,
                    textR,
                    textIconGap );
        }



        /**
         * Compute and return the location of the icons origin, the
         * location of origin of the text baseline, and a possibly clipped
         * version of the compound labels string.  Locations are computed
         * relative to the viewR rectangle.
         * This layoutCompoundLabel() does not know how to handle LEADING/TRAILING
         * values in horizontalTextPosition (they will default to RIGHT) and in
         * horizontalAlignment (they will default to CENTER).
         * Use the other version of layoutCompoundLabel() instead.
         */
        public String XXlayoutCompoundLabel( FontMetrics fm,
                                             String text,
                                             Icon icon,
                                             int verticalAlignment,
                                             int horizontalAlignment,
                                             int verticalTextPosition,
                                             int horizontalTextPosition,
                                             Rectangle viewR,
                                             Rectangle iconR,
                                             Rectangle textR,
                                             int textIconGap )
        {
            return XXlayoutCompoundLabelImpl( null, fm, text, icon,
                    verticalAlignment,
                    horizontalAlignment,
                    verticalTextPosition,
                    horizontalTextPosition,
                    viewR, iconR, textR, textIconGap );
        }



        /**
         * Compute and return the location of the icons origin, the
         * location of origin of the text baseline, and a possibly clipped
         * version of the compound labels string.  Locations are computed
         * relative to the viewR rectangle.
         * This layoutCompoundLabel() does not know how to handle LEADING/TRAILING
         * values in horizontalTextPosition (they will default to RIGHT) and in
         * horizontalAlignment (they will default to CENTER).
         * Use the other version of layoutCompoundLabel() instead.
         */
        private String XXlayoutCompoundLabelImpl( JComponent c,
                                                  FontMetrics fm,
                                                  String text,
                                                  Icon icon,
                                                  int verticalAlignment,
                                                  int horizontalAlignment,
                                                  int verticalTextPosition,
                                                  int horizontalTextPosition,
                                                  Rectangle viewR,
                                                  Rectangle iconR,
                                                  Rectangle textR,
                                                  int textIconGap )
        {
            /* Initialize the icon bounds rectangle iconR.
             */

            if ( icon != null )
            {
                iconR.width = icon.getIconWidth();
                iconR.height = icon.getIconHeight();
            }
            else
            {
                iconR.width = iconR.height = 0;
            }

            /* Initialize the text bounds rectangle textR.  If a null
             * or and empty String was specified we substitute "" here
             * and use 0,0,0,0 for textR.
             */

            boolean textIsEmpty = ( text == null ) || text.equals( "" );

            View v = null;
            if ( textIsEmpty )
            {
                textR.width = textR.height = 0;
                text = "";
            }
            else
            {
                v = ( c != null ) ? ( View ) c.getClientProperty( "html" ) : null;
                if ( v != null )
                {
                    textR.width = ( int ) v.getPreferredSpan( View.X_AXIS );
                    textR.height = ( int ) v.getPreferredSpan( View.Y_AXIS );
                }
                else
                {
                    textR.height = computeStringWidth( fm, text );
                    textR.width = fm.getHeight();
                }
            }

            /* Unless both text and icon are non-null, we effectively ignore
             * the value of textIconGap.  The code that follows uses the
             * value of gap instead of textIconGap.
             */

            int gap = ( textIsEmpty || ( icon == null ) ) ? 0 : textIconGap;

            int availTextHeight;

            if ( verticalTextPosition == CENTER )
            {
                availTextHeight = viewR.height;
            }
            else
            {
                availTextHeight = viewR.height - ( iconR.height + gap );
            }

            if ( !textIsEmpty )
            {

                /* If the label text string is too wide to fit within the available
                 * space "..." and as many characters as will fit will be
                 * displayed instead.
                 */


                if ( textR.height > availTextHeight )
                {
                    if ( v != null )
                    {
                        textR.height = availTextHeight;
                    }
                    else
                    {
                        String clipString = "...";
                        int totalHeight = computeStringWidth( fm, clipString );
                        int nChars;
                        for ( nChars = 0; nChars < text.length(); nChars++ )
                        {
                            totalHeight += fm.charWidth( text.charAt( nChars ) );
                            if ( totalHeight > availTextHeight )
                            {
                                break;
                            }
                        }
                        text = text.substring( 0, nChars ) + clipString;
                        textR.height = computeStringWidth( fm, text );
                    }
                }
            }


            /* Compute textR.x,y given the verticalTextPosition and
             * horizontalTextPosition properties
             */
/*
            if ( verticalTextPosition == TOP ) {
                if ( horizontalTextPosition != CENTER ) {
                    textR.y = 0;
                } else {
                    textR.y = -( textR.height + gap );
                }
            } else if ( verticalTextPosition == CENTER ) {
                textR.y = ( iconR.height / 2 ) - ( textR.height / 2 );
            } else { // (verticalTextPosition == BOTTOM)
                if ( horizontalTextPosition != CENTER ) {
                    textR.y = iconR.height - textR.height;
                } else {
                    textR.y = ( iconR.height + gap );
                }
            }
*/
            textR.x = 0;
            textR.y = gap + iconR.height + gap;

            iconR.x = 0;
            iconR.y = gap;

            /*
            if ( horizontalTextPosition == LEFT ) {
                textR.x = -( textR.width + gap );
            } else if ( horizontalTextPosition == CENTER ) {
                textR.x = ( iconR.width / 2 ) - ( textR.width / 2 );
            } else { // (horizontalTextPosition == RIGHT)
                textR.x = ( iconR.width + gap );
            }
*/
            /* labelR is the rectangle that contains iconR and textR.
             * Move it to its proper position given the labelAlignment
             * properties.
             *
             * To avoid actually allocating a Rectangle, Rectangle.union
             * has been inlined below.
             */
            int labelR_x = Math.min( iconR.x, textR.x );
            int labelR_width = Math.max( iconR.x + iconR.width,
                    textR.x + textR.width ) - labelR_x;
            int labelR_y = Math.min( iconR.y, textR.y );
            int labelR_height = Math.max( iconR.y + iconR.height,
                    textR.y + textR.height ) - labelR_y;

            int dx, dy;

            if ( verticalAlignment == TOP )
            {
                dy = viewR.y - labelR_y;
            }
            else if ( verticalAlignment == CENTER )
            {
                dy = ( viewR.y + ( viewR.height / 2 ) ) - ( labelR_y + ( labelR_height / 2 ) );
            }
            else
            { // (verticalAlignment == BOTTOM)
                dy = ( viewR.y + viewR.height ) - ( labelR_y + labelR_height );
            }

            if ( horizontalAlignment == LEFT )
            {
                dx = viewR.x - labelR_x;
            }
            else if ( horizontalAlignment == RIGHT )
            {
                dx = ( viewR.x + viewR.width ) - ( labelR_x + labelR_width );
            }
            else
            { // (horizontalAlignment == CENTER)
                dx = ( viewR.x + ( viewR.width / 2 ) ) -
                        ( labelR_x + ( labelR_width / 2 ) );
            }

            /* Translate textR and glypyR by dx,dy.
             */

            textR.x += dx;
            textR.y += dy + gap;

            iconR.x += dx;
            iconR.y += dy + gap;

            return text;
        }



        /**
         * Compute the width of the string using a font with the specified
         * "metrics" (sizes).
         *
         * @param fm  a FontMetrics object to compute with
         * @param str the String to compute
         * @return an int containing the string width
         */
        public int computeStringWidth( FontMetrics fm, String str )
        {
            // You can't assume that a string's width is the sum of its
            // characters' widths in Java2D -- it may be smaller due to
            // kerning, etc.
            return fm.stringWidth( str );
        }
    } // inner class NewUI
}
