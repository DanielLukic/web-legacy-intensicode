/************************************************************************/
/* MUI                  www.intensicode.de                December 2003 */
/************************************************************************/

package de.intensicode.mui;

import java.awt.Dimension;
import java.awt.Graphics2D;



/**
 * Schnittstelle fuer Objekte die sich von einem MUICanvas malen lassen
 * koennen.
 */
public interface Paintable
{
    /**
     * Wird aufgerufen sobald sich das Objekt zeichnen soll.
     */
    public void paintInto( Graphics2D aGc, Dimension aTargetSize );
}
