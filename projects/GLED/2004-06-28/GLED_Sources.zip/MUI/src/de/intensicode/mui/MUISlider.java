/************************************************************************/
/* MUI                   www.intensicode.de               November 2002 */
/************************************************************************/

package de.intensicode.mui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JSlider;
import javax.swing.JTextField;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;



/**
 * Stellt einen Slider bereit.
 */
public class MUISlider extends MUIObject
{
    /**
     * Der bereitgestellte Slider.
     */
    private JSlider iSlider = null;

    /**
     * Das optionale Textfeld zur Anzeige des aktuellen Werts.
     */
    private JTextField iTextField = null;

    /**
     * Der Listener des Sliders.
     */
    private SLIDE_Action iSlideAction = null;

    /**
     * Der Listener des Textfelds.
     */
    private TEXT_Action iTextAction = null;



    /**
     * Erzeugt einen Slider fuer den angegebenen Wertebereich und dem
     * angegebenen Startwert.
     */
    public MUISlider( int min, int max, int value )
    {
        this( min, max, value, true );
    }

    /**
     * Erzeugt einen Slider fuer den angegebenen Wertebereich und dem
     * angegebenen Startwert.
     */
    public MUISlider( int min, int max, int value, boolean showValue )
    {
        iSlider = new JSlider( min, max, value );
        _init( iSlider, MUIPrefs.getMUISliderDefaults() );

        MUIGroup group = new MUIGroupH();
        group.add( iSlider, MUIPrefs.getMUISliderDefaults() );

        if ( showValue )
        {
            MUIConstraints defs = MUIPrefs.getMUISliderDefaults();
            defs.iWeightH = 0.05;

            iTextField = new JTextField( "" + value );
            iTextField.addActionListener( this );
            _init( iTextField, MUIPrefs.getMUISliderDefaults() );
            group.add( iTextField, defs );
        }
        init( group, MUIPrefs.getMUISliderDefaults() );
        addListeners();
    }

    public void setValues( int aMinValue, int aMaxValue, int aValue )
    {
        iSlider.setMinimum( aMinValue );
        iSlider.setMaximum( aMaxValue );
        iSlider.setValue( aValue );
    }

    /**
     * Legt den anzuzeigenden Wert fest.
     */
    public void setValue( int aValue ) throws IllegalArgumentException
    {
        if ( aValue < iSlider.getMinimum() || aValue > iSlider.getMaximum() )
        {
            throw new IllegalArgumentException( "Value out of bounds: " + aValue );
        }
        removeListeners();
        if ( iSlider != null ) iSlider.setValue( aValue );
        if ( iTextField != null ) iTextField.setText( "" + aValue );
        addListeners();
    }



    /**
     * Liefert den gerade angezeigten Wert.
     */
    public int getValue()
    {
        return iSlider.getValue();
    }

    // Implementation

    /**
     * Setzt die Listener damit Veraenderungen der Werte weitergemeldet
     * werden.
     */
    private void addListeners()
    {
        if ( iSlideAction == null )
        {
            iSlideAction = new SLIDE_Action();
        }
        if ( iTextAction == null )
        {
            iTextAction = new TEXT_Action();
        }
        iSlider.addChangeListener( iSlideAction );
        if ( iTextField != null )
        {
            iTextField.addActionListener( iTextAction );
        }
    }

    /**
     * Entfernt die Listener damit Veraenderungen der Werte nicht mehr
     * weitergemeldet werden (zB zum Zuruecksetzen der Werte).
     */
    private void removeListeners()
    {
        iSlider.removeChangeListener( iSlideAction );
        iTextField.removeActionListener( iTextAction );
    }

    /**
     * Hilfsklasse fuer das Entgegenehmen von Aenderungen am Slider.
     */
    private /*inner*/ class SLIDE_Action implements ChangeListener
    {
        public void stateChanged( ChangeEvent event )
        {
            if ( iTextField != null )
            {
                iTextField.setText( "" + iSlider.getValue() );
            }
            if ( iSlider.getValueIsAdjusting() == true )
            {
                return;
            }
            actionPerformed( new ActionEvent( iSlider, 0, null ) );
        }
    }

    /**
     * Hilfsklasse fuer das Entgegenehmen von Aenderungen am Textfeld.
     */
    private /*inner*/ class TEXT_Action implements ActionListener
    {
        public void actionPerformed( ActionEvent event )
        {
            try
            {
                int newValue = Integer.parseInt( iTextField.getText() );
                iSlider.setValue( newValue );
            }
            catch ( NumberFormatException nfEx )
            {

            }
        }
    }
}
