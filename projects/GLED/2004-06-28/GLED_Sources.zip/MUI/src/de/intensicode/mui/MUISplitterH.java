/************************************************************************/
/* MUI                      The.French.DJ                   Januar 2003 */
/************************************************************************/

package de.intensicode.mui;

import de.intensicode.mui.MUISplitter;

import java.awt.Component;

import javax.swing.JSplitPane;



/**
 *
 */
public class MUISplitterH extends MUISplitter {

    public MUISplitterH() {

        super( JSplitPane.HORIZONTAL_SPLIT, MUIPrefs.getMUISplitterHDefaults() );

    } // MUISplitterH()

} // class MUISplitterH
