/************************************************************************/
/* MUI                    www.intensicode.de              November 2002 */
/************************************************************************/

package de.intensicode.mui;

import javax.swing.JProgressBar;



public class MUIProgress extends MUIObject
{
    private JProgressBar iProgress;



    public MUIProgress()
    {
        iProgress = new JProgressBar( JProgressBar.HORIZONTAL, 0, 100 );
        init( iProgress, MUIPrefs.getMUIProgressDefaults() );

        iProgress.setValue( 33 );
    }

    public void setValue( int aNewValue, int aMaxValue )
    {
        iProgress.setMinimum( 0 );
        iProgress.setMaximum( aMaxValue );
        iProgress.setValue( aNewValue );
    }
}
