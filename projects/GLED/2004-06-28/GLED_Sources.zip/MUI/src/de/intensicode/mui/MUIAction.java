/************************************************************************/
/* MUI                   www.intensicode.de               November 2002 */
/************************************************************************/

package de.intensicode.mui;



public interface MUIAction
{
    public void install( OnActionListener receiver );
}
