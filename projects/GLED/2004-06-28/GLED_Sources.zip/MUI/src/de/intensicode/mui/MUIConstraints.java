/************************************************************************/
/* MUI                   www.intensicode.de               November 2002 */
/************************************************************************/

package de.intensicode.mui;

import java.awt.Dimension;
import java.awt.Insets;



public class MUIConstraints
{
    public Insets iInsets = new Insets( 2, 1, 2, 1 );

    public Dimension iSpacing = new Dimension( 0, 0 );

    public boolean iSameSizeH = false;

    public boolean iSameSizeV = false;

    public boolean iSpaceToFitH = false;

    public boolean iSpaceToFitV = false;

    public boolean iStretchToFitH = false;

    public boolean iStretchToFitV = false;

    public double iWeightH = 0.0;

    public double iWeightV = 0.0;



    public MUIConstraints()
    {

    }

    public MUIConstraints( boolean aStretchToFitH, boolean aStretchToFitV )
    {
        iStretchToFitH = aStretchToFitH;
        iStretchToFitV = aStretchToFitV;
    }

    public void clearInsets()
    {
        iInsets.bottom = 0;
        iInsets.left = 0;
        iInsets.top = 0;
        iInsets.right = 0;
    }

    public void setWeights( double aHorizontalWeight, double aVerticalWeight )
    {
        iWeightH = aHorizontalWeight;
        iWeightV = aVerticalWeight;
    }
}
