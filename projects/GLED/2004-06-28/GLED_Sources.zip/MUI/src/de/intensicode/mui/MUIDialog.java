/************************************************************************/
/* MUI                   www.intensicode.de               November 2002 */
/************************************************************************/

package de.intensicode.mui;

import java.awt.Dimension;
import java.awt.Point;
import java.awt.Rectangle;
import java.security.AccessControlException;

import javax.swing.JDialog;
import javax.swing.JFrame;



public class MUIDialog extends JDialog
{
    public MUIDialog( JFrame aParent, String aTitle, boolean aModalFlag )
    {
        super( aParent, aTitle, aModalFlag );

        try
        {
            setDefaultCloseOperation( JDialog.HIDE_ON_CLOSE );
        }
        catch ( AccessControlException acEx )
        {
            // Assume applet context.
            setDefaultCloseOperation( JFrame.HIDE_ON_CLOSE );
        }
        getContentPane().setBackground( MUIPrefs.getBackgroundColor() );
    }

    public void addChild( MUIComponent aComponent )
    {
        getContentPane().add( aComponent.getJava() );
        pack();
    }

    public void centerDialog()
    {
        Dimension frame = getSize();
        Rectangle screen = getParent().getBounds();

        Point offset = new Point();
        offset.x = ( screen.width - frame.width ) / 2;
        offset.y = ( screen.height - frame.height ) / 2;
        offset.translate( screen.x, screen.y );

        Rectangle bounds = new Rectangle( offset, frame );
        setBounds( bounds );
    }
}
