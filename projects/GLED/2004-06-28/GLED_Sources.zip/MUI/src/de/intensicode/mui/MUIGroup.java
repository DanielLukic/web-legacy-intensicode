/************************************************************************/
/* MUI                   www.intensicode.de               November 2002 */
/************************************************************************/

package de.intensicode.mui;

import java.awt.Component;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.NoSuchElementException;

import javax.swing.BorderFactory;
import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.border.Border;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;



/**
 * Basisklasse fuer GUI-Gruppen. Im Gegensatz zu den meisten anderen
 * MUI-Elementen kann die MUIGroup direkt als Swing-Komponente verwendet
 * werden, da sie von JPanel erbt.
 */
public abstract class MUIGroup extends JPanel implements ActionListener, MUIComponent
{
    /**
     * Kommando-Kette fuer das Ausfuehren von Kommandos bei Eintreten
     * bestimmter Ereignisse.
     */
    protected CommandQueue iActionQueue = new CommandQueue();

    /**
     * Das verwendete Layout. Dies haengt von der konkreten Art der Gruppe
     * ab und wird von Unterklassen - meist ueber einen der Konstruktoren -
     * gesetzt.
     */
    protected MUILayout iLayout = null;



    /**
     * Hilfskonstruktor fuer Unterklassen welche die gesamte
     * Initialisierung selbst uebernehmen wollen. Es ist wichtig das Feld
     * {@link #layout iLayout} zu setzen und
     * {@link de.intensicode.mui.MUIObject#_init _init} fuer <code>this</code>
     * aufzurufen.
     */
    protected MUIGroup()
    {

    }

    /**
     * Initialisiert die Gruppe mit dem angegebenen Layout.
     */
    public MUIGroup( MUILayout aLayout )
    {
        setMUILayout( aLayout );
    }

    /**
     * Legt das Layout fuer die Gruppe fest. Dies fuehrt nicht automatisch
     * zu einem Neuzeichnen der Gruppe.
     */
    public void setMUILayout( MUILayout aLayout )
    {
        this.iLayout = aLayout;

        // Das Layout auch der eigentlichen Swing-Komponente bekanntmachen.
        super.setLayout( aLayout );

        // Initialisierung der MUI-Eigenschaften vornehmen.
        MUIObject._init( this, aLayout.getDefaults() );
    }

    /**
     * Legt einen Titel fest, welcher im Rahmen um die Gruppe herum
     * angezeigt werden soll.
     */
    public void setTitle( String aTitle )
    {
        setTitle( aTitle, true );
    }

    /**
     * Legt einen Titel fuer die Gruppe fest und ermoeglicht diesen auch
     * ohne Rahmen <code>etched = false</code> darzustellen.
     */
    public void setTitle( String aTitle, boolean aEtchedFlag )
    {
        Border border = null;
        if ( aEtchedFlag )
        {
            border = new TitledBorder( new EtchedBorder(), aTitle );
        }
        else
        {
            border = new TitledBorder( BorderFactory.createEmptyBorder(), aTitle );
        }
        setBorder( border );
    }

    /**
     * Liefert den Titel (Namen) der Gruppe.
     */
    public String getTitle()
    {
        return ( ( TitledBorder ) getBorder() ).getTitle();
    }

    /**
     * Hilsmethode fuer Unterklassen: Bestimmt die horizontale Gewichtung
     * einer Komponente. Dabei werden die MUI-Eigenschaften von
     * MUI-Komponenten direkt verwendet. Sind keine gesetzt, oder handelt
     * es sich nicht um eine MUI-Komponente, dann werden Defaults
     * verwendet.
     */
    public double getWeightH( Component comp )
    {
        try
        {
            MUIComponent mui = ( MUIComponent ) comp;
            return mui.getWeightH();
        }
        catch ( ClassCastException ccEx )
        {
            MUIConstraints constraints = iLayout.getConstraints( comp );
            return constraints.iWeightH;
        }
    }

    /**
     * Hilsmethode fuer Unterklassen: Bestimmt die vertikale Gewichtung
     * einer Komponente. Dabei werden die MUI-Eigenschaften von
     * MUI-Komponenten direkt verwendet. Sind keine gesetzt, oder handelt
     * es sich nicht um eine MUI-Komponente, dann werden Defaults
     * verwendet.
     */
    public double getWeightV( Component comp )
    {
        try
        {
            MUIComponent mui = ( MUIComponent ) comp;
            return mui.getWeightV();
        }
        catch ( ClassCastException ccEx )
        {
            MUIConstraints constraints = iLayout.getConstraints( comp );
            return constraints.iWeightV;
        }
    }

    /**
     * Fuegt der Gruppe ein weiteres Element hinzu. Dabei werden die
     * MUI-Eigenschaften des Elements fuer das Layouting verwendet.
     */
    public void addChild( MUIComponent component )
    {
        MUIConstraints constraints = component.getConstraints();
        addChild( component, constraints );
    }

    /**
     * Fuegt der Gruppe ein weiteres Element hinzu. Dabei werden die
     * angegebenen Eigenschaften (und nicht die des Elements) fuer das
     * Layouting verwendet.
     */
    public void addChild( MUIComponent component, MUIConstraints constraints )
    {
        add( component.getJava(), constraints );
    }

    /**
     * Aehnlich {@link #addChild addChild} nur das hier die neue Komponente
     * zentriert (in Bezug auf die anderen Gruppenmitglieder) dargestellt
     * wird.
     */
    public abstract void addCentered( MUIComponent component );

    /**
     * Liefert eine enthaltene Komponente anhand ihres Names. Dabei wird
     * geprueft ob der angegebene Name innerhalb des Namens der enthaltenen
     * Komponenten vorkommt. Es wird also nicht auf exakte Gleichheit
     * geprueft. Damit ist es moeglich insbesondere auch ImageButtons zu
     * finden indem man den Namen des Bildes angibt: <code>MoveMode</code>
     * findet so zB den ImageButton der mit dem Dateinamen
     * <code>res/images/buttons/MoveMode.gif</code> initialisiert wurde.
     */
    public Component getComponent( String aComponentName )
    {
        aComponentName = aComponentName.toUpperCase();
        Component[] children = getComponents();
        for ( int idx = 0; idx < children.length; idx++ )
        {
            Component child = children[ idx ];
            if ( child.getName() == null )
            {
                continue;
            }
            String childName = child.getName().toUpperCase();
            if ( childName.indexOf( aComponentName ) == -1 )
            {
                continue;
            }
            return child;
        }
        throw new NoSuchElementException( "Component " + aComponentName + " unknown" );
    }

    // From JComponent

    public void setEnabled( boolean flag )
    {
        for ( int idx = 0; idx < getComponentCount(); idx++ )
        {
            getComponent( idx ).setEnabled( flag );
        }
        super.setEnabled( flag );
    }

    public void setToolTipText( String text )
    {
        for ( int idx = 0; idx < getComponentCount(); idx++ )
        {
            Component component = getComponent( idx );
            if ( component instanceof JComponent )
            {
                ( ( JComponent ) component ).setToolTipText( text );
            }
        }
        super.setToolTipText( text );
    }

    // From ActionListener

    public void actionPerformed( ActionEvent aEvent )
    {
        iActionQueue.fire( aEvent );
    }

    // From MUIComponent

    public JComponent getJava()
    {
        return this;
    }

    public MUIConstraints getConstraints()
    {
        return iLayout.iDefaults;
    }

    public MUIComponent setActionCommand( Command cmd, Commandable main )
    {
        iActionQueue.add( cmd, main );
        return this;
    }

    public MUIComponent setActionForwarding( MUIComponent receiver )
    {
        iActionQueue.add( receiver );
        return this;
    }

    public MUIComponent setFocusability( boolean focusable )
    {
        setFocusable( focusable );
        return this;
    }

    public MUIComponent doEnable()
    {
        setEnabled( true );
        return this;
    }

    public MUIComponent doDisable()
    {
        setEnabled( false );
        return this;
    }

    public void setVisibleRect( Rectangle aBounds )
    {

    }
}
