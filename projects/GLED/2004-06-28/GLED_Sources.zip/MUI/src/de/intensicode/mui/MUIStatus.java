/************************************************************************/
/* MUI                   www.intensicode.de               November 2002 */
/************************************************************************/

package de.intensicode.mui;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ResourceBundle;



public class MUIStatus extends MUIScrollView
{
    private MUITextArea iStatusField = null;

    private SimpleDateFormat format = new SimpleDateFormat( "yyyy/MM/dd HH:mm:ss" );



    public MUIStatus()
    {
        iStatusField = new MUITextArea( 4, 40 );
        iStatusField.setEditable( false );

        setView( iStatusField );
        setPreferredSizeForwarding( true );

        getConstraints().iWeightV = 0;
    }

    /**
     * Gibt eine Meldung im Status-Log aus.
     */
    public void showStatus( String aMessage )
    {
        String buffer = iStatusField.getText();
        if ( buffer.length() > 2500 )
        {
            buffer = buffer.substring( 0, 2500 );
        }
        iStatusField.setText( buffer );

        StringBuffer status = new StringBuffer();
        status.append( format.format( new Date() ) );
        status.append( ": " );
        status.append( aMessage );
        status.append( "\n" );

        iStatusField.insert( status.toString(), 0 );
    }

    /**
     * Zeigt eine Fehlermeldung an.
     */
    public void showError( String aMessage )
    {
        StringBuffer status = new StringBuffer();
        status.append( "ERROR: " );
        status.append( aMessage );
        showStatus( status.toString() );
    }

    /**
     * Zeigt eine Fehlermeldung an.
     */
    public void showError( String aMessage, Throwable aCause )
    {
        if ( aCause != null )
        {
            StringBuffer status = new StringBuffer();
            status.append( "ERROR: " );
            status.append( aMessage );
            status.append( "\n" );
            status.append( "CAUSED BY: " );
            status.append( aCause.toString() );
            aCause.printStackTrace();
            showStatus( status.toString() );
        }
        else
        {
            showError( aMessage );
        }
    }

    /**
     * Zeigt eine Fehlermeldung an.
     */
    public void showError( Throwable aCause )
    {
        StringBuffer status = new StringBuffer();
        status.append( "ERROR: " );
        status.append( aCause.getMessage() );
        showStatus( status.toString() );
        aCause.printStackTrace();
    }

    /**
     * Gibt eine Meldung im Status-Log aus wobei die Meldung aus dem
     * angegebenen Resouce-Bundle genommen wird.
     */
    public void showStatus( ResourceBundle aBundle, String aID )
    {
        showStatus( aBundle.getString( aID ) );
    }
}
