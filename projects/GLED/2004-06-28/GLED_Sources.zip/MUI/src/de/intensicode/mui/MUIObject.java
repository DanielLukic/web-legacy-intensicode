/************************************************************************/
/* MUI                   www.intensicode.de               November 2002 */
/************************************************************************/

package de.intensicode.mui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Rectangle;

import javax.swing.AbstractButton;
import javax.swing.JComponent;
import javax.swing.JTextField;
import javax.swing.JTextArea;



/**
 * Basisklasse fuer MUI-Komponenten die eine Java-Komponente verwenden.
 */
public class MUIObject implements ActionListener, MUIComponent
{
    protected CommandQueue actionQueue = new CommandQueue();

    protected JComponent iJava;

    protected MUIConstraints iDefaults = null;



    protected MUIObject()
    {

    }

    protected MUIObject( JComponent aJava, MUIConstraints aDefaults )
    {
        init( aJava, aDefaults );
    }

    /**
     * Hilfsmethode damit auch Non-MUIObject GUI-Elemente konsistent ihre
     * Java-Komponenten initialisieren koennen.
     */
    public static void _init( JComponent aJava, MUIConstraints aDefaults )
    {
        if ( aJava instanceof AbstractButton )
        {
            ( ( AbstractButton ) aJava ).setMargin( aDefaults.iInsets );
        }

        if ( aJava instanceof JTextField )
        {
            aJava.setBackground( MUIPrefs.getTextBackgroundColor() );
        }
        else if ( aJava instanceof JTextArea )
        {
            aJava.setBackground( MUIPrefs.getTextBackgroundColor() );
        }
        else
        {
            aJava.setBackground( MUIPrefs.getBackgroundColor() );
        }
    }

    /**
     * Legt einen ToolTip fuer die Komponente fest - sofern dies
     * unterstuetzt wird.
     */
    public MUIComponent setToolTip( String aToolTip )
    {
        if ( iJava instanceof JComponent )
        {
            iJava.setToolTipText( aToolTip );
        }
        return this;
    }

    // From ActionListener

    public void actionPerformed( ActionEvent event )
    {
        actionQueue.fire( event );
    }

    // From MUIComponent

    public JComponent getJava()
    {
        return iJava;
    }

    public MUIConstraints getConstraints()
    {
        return iDefaults;
    }

    public double getWeightH()
    {
        return iDefaults.iWeightH;
    }

    public double getWeightV()
    {
        return iDefaults.iWeightV;
    }

    public MUIComponent setActionCommand( Command cmd, Commandable main )
    {
        actionQueue.add( cmd, main );

        if ( cmd instanceof MUICommand )
        {
            MUICommand muiCommand = ( MUICommand ) cmd;
            muiCommand.setComponent( this );
        }
        return this;
    }

    public MUIComponent setActionForwarding( MUIComponent receiver )
    {
        actionQueue.add( receiver );
        return this;
    }

    public MUIComponent setFocusability( boolean focusable )
    {
        iJava.setFocusable( focusable );
        return this;
    }

    public MUIComponent doEnable()
    {
        iJava.setEnabled( true );
        return this;
    }

    public MUIComponent doDisable()
    {
        iJava.setEnabled( false );
        return this;
    }

    public void setVisibleRect( Rectangle aBounds )
    {

    }

    public void setVisible( boolean aVisibleFlag )
    {
        iJava.setVisible( aVisibleFlag );
    }

    public void setEnabled( boolean aEnabledFlag )
    {
        iJava.setEnabled( aEnabledFlag );
    }

    // Protected Interface

    protected void init( JComponent aComponent, MUIConstraints aDefaults )
    {
        iJava = aComponent;
        iDefaults = aDefaults;
        _init( aComponent, aDefaults );
    }
}
