/************************************************************************/
/* MUI                   www.itnensicode.de               November 2002 */
/************************************************************************/

package de.intensicode.mui;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.Rectangle;
import java.awt.Color;

import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;

import javax.swing.DefaultListModel;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.ListCellRenderer;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;



public class MUIList extends MUIObject implements ComponentListener
{
    public MUIAction ON_SELECTION;

    protected MutableList iList = null;

    protected Object[] iValues;



    public MUIList()
    {
        iList = new MutableList();

        super.iJava = iList;
        super.iDefaults = MUIPrefs.getMUIListDefaults();

        iList.setFont( iList.getFont().deriveFont( 0 ).deriveFont( 10.0f ) );
        iList.addComponentListener( this );

        ON_SELECTION = new ON_SELECTION( this );
    }

    public MUIList( Object[] data )
    {
        this();

        iList.setListData( data );
    }

    public MUIList setRenderer( ListCellRenderer renderer )
    {
        iList.setCellRenderer( renderer );
        return this;
    }

    public MUIList setFont( Font font )
    {
        iList.setFont( font );
        return this;
    }

    public MUIList setData( Object[] data )
    {
        iList.setListData( data );
        return this;
    }

    public MUIList setData( Object[] aVisuals, Object[] aValues )
    {
        iList.setListData( aVisuals );
        iValues = aValues;
        return this;
    }

    public Object getSelectedEntry()
    {
        if ( iValues != null )
        {
            return iValues[ iList.getSelectedIndex() ];
        }
        return iList.getSelectedValue();
    }

    public MUIList setAction( MUIAction action, OnActionListener receiver )
    {
        action.install( receiver );
        return this;
    }

    public DefaultListModel getContents()
    {
        return iList.getContents();
    }

    public void removeAll()
    {
        iList.getContents().removeAllElements();
    }

    public void setCellRenderer( ListCellRenderer renderer )
    {
        iList.setCellRenderer( renderer );
    }

    public ListCellRenderer getCellRenderer()
    {
        return iList.getCellRenderer();
    }

    // From ComponentListener

    public void componentHidden( ComponentEvent aEvent )
    {

    }

    public void componentMoved( ComponentEvent aEvent )
    {

    }

    public void componentResized( ComponentEvent aEvent )
    {

    }

    public void componentShown( ComponentEvent aEvent )
    {

    }

    public void setSelectColor( Color aColor )
    {
        iList.setSelectionForeground( aColor );
    }

    public void setBackgroundColor( Color aColor )
    {
        iList.setBackground( aColor );
    }

    // Implementation

    protected /*inner*/ class MutableList extends JList
    {
        MutableList()
        {
            super( new DefaultListModel() );
            setCellRenderer( new MUICellRenderer() );
        }

        public DefaultListModel getContents()
        {
            return ( DefaultListModel ) getModel();
        }

//        public int getScrollableUnitIncrement( Rectangle visibleRect, int orientation, int direction )
//        {
//            return super.getScrollableUnitIncrement( visibleRect, orientation, direction ) / 2 + 1 ;
//        }
    }



    protected /*inner*/ class MUICellRenderer implements ListCellRenderer
    {
        public Component getListCellRendererComponent
            ( JList aList, Object aValue, int aIndex, boolean aSelectedFlag, boolean aHasFocusFlag )
        {
            if ( aValue instanceof MUIComponent )
            {
                MUIComponent mui = ( MUIComponent ) aValue;
                Component java = mui.getJava();
                if ( aSelectedFlag )
                {
                    java.setBackground( MUIPrefs.getSelectedBackgroundColor() );
                }
                else
                {
                    java.setBackground( MUIPrefs.getBackgroundColor() );
                }
                return java;
            }
            return new JLabel( aValue.toString() );
        }
    }



    private /*inner*/ class ON_SELECTION extends MUIAbstractAction implements ListSelectionListener
    {
        public ON_SELECTION( MUIList aList )
        {
            super( aList );

            aList.iList.addListSelectionListener( this );
        }

        // From ListSelectionListener

        public void valueChanged( ListSelectionEvent aEvent )
        {
            broadcast( aEvent );
        }
    }
}
