/************************************************************************/
/* MUI                   www.intensicode.de               November 2002 */
/************************************************************************/

package de.intensicode.mui;

import java.awt.event.ActionListener;
import java.awt.Rectangle;

import javax.swing.JComponent;



/**
 * Basisschnittstelle fuer MUI-Komponenten.
 */
public interface MUIComponent extends ActionListener
{
    /**
     * Liefert die zugehoerige (Swing-)Komponente.
     */
    JComponent getJava();

    /**
     * Liefert die MUI-Eigenschaften.
     */
    MUIConstraints getConstraints();

    /**
     * Hilfsmethode fuer den Zugriff auf die MUI-Eigenschaften: Liefert
     * die horizontale Gewichtung des GUI-Elements.
     */
    double getWeightH();

    /**
     * Hilfsmethode fuer den Zugriff auf die MUI-Eigenschaften: Liefert
     * die vertikale Gewichtung des GUI-Elements.
     */
    double getWeightV();

    /**
     * Legt ein Kommando fest, welches ausgefuehrt werden soll, sobald ein
     * Ereignis (ueber
     * {@link java.awt.event.ActionListener#actionPerformed actionPerformed})
     * auftritt.
     */
    MUIComponent setActionCommand( Command cmd, Commandable commandable );

    /**
     * Legt einen Empfaenger fest, der an Ereignissen interessiert ist, die
     * an <code>this</code> geliefert werden. Damit ist ein Event-Chaining
     * moeglich und zB eine Grupper kann die Ereignisse ihrer enthaltenen
     * Buttons weiterverarbeiten.
     */
    MUIComponent setActionForwarding( MUIComponent receiver );

    MUIComponent setFocusability( boolean focusable );

    MUIComponent doEnable();

    MUIComponent doDisable();

    /**
     * Wird aufgerufen wenn nur ein Teil einer Komponente sichtbar ist.
     * Damit ist es dann moeglich nur die notwendigen (sichtbaren) Teile
     * einer Komponene zu zeichnen (die zB in einer ScrollPane haengt).
     */
    void setVisibleRect( Rectangle aBounds );

    void setVisible( boolean aVisibleFlag );

    void setEnabled( boolean aEnabledFlag );
}
