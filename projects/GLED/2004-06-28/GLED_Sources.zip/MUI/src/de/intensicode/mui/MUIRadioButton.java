/************************************************************************/
/* MUI                      The.French.DJ                 November 2002 */
/************************************************************************/

package de.intensicode.mui;

import de.intensicode.mui.MUIButton;

import javax.swing.JRadioButton;



/**
 *
 */
public class MUIRadioButton extends MUIButton {

    public MUIRadioButton( String name ) {

        iButton = new JRadioButton( name );
        iButton.addActionListener( this );
        iButton.setActionCommand( name );

        init( iButton, MUIPrefs.getMUIRadioButtonDefaults() );

    } // MUIRadioButton( String )

} // class MUIRadioButton
