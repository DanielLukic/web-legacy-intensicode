/************************************************************************/
/* Gimolus3D          Vivatech Software Berlin GmbH         Januar 2003 */
/************************************************************************/

package de.intensicode.mui;

import javax.swing.JSplitPane;



/**
 * Stellt einen vom Benutzer einstellbaren Split-Bereich des GUI bereit.
 * Entspricht der {@link javax.swing.JSplitPane JSplitPane}.
 */
public abstract class MUISplitter extends MUIObject
{
    private MUIComponent first = null;

    private MUIComponent second = null;

    private JSplitPane splitter = null;



    /**
     * Initialisiert den Splitter zunaechst mit zwei leeren MUIScrollViews.
     */
    protected MUISplitter( int orientation )
    {
        this( orientation, MUIPrefs.getMUISplitterDefaults() );
    }

    /**
     * Initialisiert den Splitter zunaechst mit zwei leeren MUIScrollViews.
     */
    protected MUISplitter( int orientation, MUIConstraints defaults )
    {
        first = new MUIScrollView();
        second = new MUIScrollView();

        splitter = new JSplitPane( orientation, false, first.getJava(), second.getJava() );
        splitter.setResizeWeight( 0.6 );

        super.iJava = splitter;
        super.iDefaults = defaults;
    }

    public void setFirst( MUIComponent newFirst )
    {
        first = newFirst;
        splitter.setTopComponent( newFirst.getJava() );
    }

    public void setSecond( MUIComponent newSecond )
    {
        second = newSecond;
        splitter.setBottomComponent( newSecond.getJava() );
    }

    public void setScrollableFirst( MUIComponent newFirst )
    {
        first = new MUIScrollView( newFirst );
        splitter.setTopComponent( first.getJava() );
    }

    public void setScrollableSecond( MUIComponent newSecond )
    {
        second = new MUIScrollView( newSecond );
        splitter.setBottomComponent( second.getJava() );
    }
}
