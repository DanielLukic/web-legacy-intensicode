/************************************************************************/
/* MUI                  www.intensicode.de                November 2002 */
/************************************************************************/

package de.intensicode.mui;

import java.awt.Dimension;

import javax.swing.JMenuBar;



public class MUIMenu extends MUIObject
{
    protected SizedMenuBar iMenuBar = null;



    public MUIMenu()
    {
        iMenuBar = new SizedMenuBar();
        init( iMenuBar, MUIPrefs.getMUIMenuDefaults() );
//        iMenuBar.setMargin( iDefaults.iInsets );
    }

    public void addChild( MUISubMenu submenu )
    {
        iMenuBar.add( submenu.getJava() );
    }

    public JMenuBar getJavaMenu()
    {
        return iMenuBar;
    }

    private /*inner*/ class SizedMenuBar extends JMenuBar
    {
        public Dimension getMinimumSize()
        {
            return super.getPreferredSize();
        }
    }
}
