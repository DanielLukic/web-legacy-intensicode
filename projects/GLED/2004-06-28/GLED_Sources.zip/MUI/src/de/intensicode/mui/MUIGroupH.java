/************************************************************************/
/* MUI                   www.intensicode.de               November 2002 */
/************************************************************************/

package de.intensicode.mui;

import java.awt.Component;



/**
 * Gruppe fuer horizontal anzuordnede GUI-Elemente.
 */
public class MUIGroupH extends MUIGroup
{
    /**
     * Initialisiert die Gruppe.
     */
    public MUIGroupH()
    {
        MUIConstraints defaults = MUIPrefs.getMUIGroupHDefaults();
        MUILayout layout = new MUILayoutH( defaults );
        setMUILayout( layout );
    }

    // From MUIGroup

    public void addCentered( MUIComponent component )
    {
        MUIGroup container = new MUIGroupV();
        container.addChild( new MUISpacerV() );
        container.addChild( component );
        container.addChild( new MUISpacerV() );
        addChild( container );
    }

    // From MUIComponent

    public double getWeightH()
    {
        MUIConstraints defaults = iLayout.iDefaults;
        if ( getComponentCount() == 0 )
        {
            return defaults.iWeightH;
        }
        double result = 0;
        Component[] components = getComponents();
        for ( int idx = 0; idx < components.length; idx++ )
        {
            result += getWeightH( components[ idx ] );
        }

        return result * defaults.iWeightH;
    }

    public double getWeightV()
    {
        MUIConstraints defaults = iLayout.iDefaults;
        if ( getComponentCount() == 0 )
        {
            return ( defaults.iWeightV );
        }
        double result = 0;
        Component[] components = getComponents();
        for ( int idx = 0; idx < components.length; idx++ )
        {
            result = Math.max( result, getWeightV( components[ idx ] ) );
        }
        return result * defaults.iWeightV;
    }
}
