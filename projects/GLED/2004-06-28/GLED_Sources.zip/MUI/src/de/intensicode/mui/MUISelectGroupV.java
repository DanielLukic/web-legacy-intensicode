/************************************************************************/
/* MUI                   www.intensicode.de               November 2002 */
/************************************************************************/

package de.intensicode.mui;

import java.util.Enumeration;

import javax.swing.AbstractButton;
import javax.swing.ButtonGroup;
import javax.swing.ButtonModel;



public class MUISelectGroupV extends MUIGroupV implements MUISelectGroup
{
    private ButtonGroup iButtonGroup;



    public MUISelectGroupV()
    {
        iButtonGroup = new ButtonGroup();
    }

    // From MUISelectGroup

    public void addSelectable( MUIObject aButton )
    {
        aButton.setActionForwarding( this );

        AbstractButton java = ( AbstractButton ) aButton.getJava();
        iButtonGroup.add( java );
        if ( iButtonGroup.getButtonCount() == 1 )
        {
            iButtonGroup.setSelected( java.getModel(), true );
        }
        addChild( aButton );
    }

    public String getSelected()
    {
        return iButtonGroup.getSelection().getActionCommand();
    }

    public Object[] getSelectedObjects()
    {
        return iButtonGroup.getSelection().getSelectedObjects();
    }

    public void setSelected( String aControlName )
    {
        Enumeration entries = iButtonGroup.getElements();
        while ( entries.hasMoreElements() == true )
        {
            AbstractButton button = ( AbstractButton ) entries.nextElement();
            if ( button.getActionCommand().equals( aControlName ) )
            {
                ButtonModel model = button.getModel();
                iButtonGroup.setSelected( model, true );
            }
        }
    }
}
