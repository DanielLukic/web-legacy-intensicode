/************************************************************************/
/* MUI                  www.intensicode.de                November 2002 */
/************************************************************************/

package de.intensicode.mui;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.Insets;
import java.awt.Point;



public class MUILayoutV extends MUILayout
{
    public MUILayoutV( MUIConstraints defaults )
    {
        super( defaults );
    }

    // From MUILayout

    /**
     * Aktualisiert die Position <code>pos</code> unter Betrachtung der
     * Groesse der gerade auszulegenden Komponente.
     */
    protected void prepareLayout( Point aPosition, Dimension aComponentSize )
    {
        aPosition.y += aComponentSize.getHeight();
        aPosition.y += iDefaults.iSpacing.getHeight();
    }

    protected StretchData determineStretchDataH( Point aUsedSpace, Container aParent )
    {
        StretchData result = new StretchData();
        result.weightDeltaH = 1.0;
        result.weightOffsetH = 0.0;
        result.askWidth = true;
        return result;
    }

    protected StretchData determineStretchDataV( Point usedSpace, Container parent )
    {
        StretchData result = new StretchData();
        result.weightDeltaV = 1.0;
        result.weightOffsetV = 1.0;
        result.askHeight = false;
        return result;
    }

    /**
     * Aktualisiert die #aPreferredSize unter Betrachtung einer horizontalen
     * Auslegung der Komponenten.
     */
    protected void calculateLayoutSize( CalculatedSize aPreferredSize, Dimension aSize, Insets aInsets )
    {
        aPreferredSize.height += aSize.getHeight();
        aPreferredSize.width = Math.max( aPreferredSize.width, aInsets.left + aSize.getWidth() );
        aPreferredSize.height += iDefaults.iSpacing.getHeight();
    }
}
