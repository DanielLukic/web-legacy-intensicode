/************************************************************************/
/* MUI                  www.intensicode.de                December 2003 */
/************************************************************************/

package de.intensicode.mui;



/**
 * Basisklasse fuer Kommandos. Uebernimmt das Liefern des Namens (anhand
 * des Namens der implementierenden Klasse) und implementiert damit
 * {@link #toString toString}.
 * <p>
 * Ueber das Setzen von {@link #iAmAsync iAmAsync} auf <code>false</code> koennen
 * sich implementierende Klassen als synchron kennzeichnen.
 */
public abstract class AbstractCommand implements Command
{
    /**
     * Kann von Unterklassen auf <code>false</code> gesetzt werden wenn das
     * implementierte Kommando synchron ausgefuehrt werden soll.
     */
    protected boolean iAmAsync = true;



    // From Command

    public boolean isAsync()
    {
        return iAmAsync;
    }

    public String getName()
    {
        String className = getClass().getName();
        return ( className.substring( className.lastIndexOf( '.' ) + 1 ) );
    }

    // From Object

    /**
     * Liefert den Namen des Kommandos.
     */
    public String toString()
    {
        return getName();
    }
}
