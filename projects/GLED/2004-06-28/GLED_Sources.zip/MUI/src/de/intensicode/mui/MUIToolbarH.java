/************************************************************************/
/* MUI                 www.intensicode.de                 November 2002 */
/************************************************************************/

package de.intensicode.mui;

import java.awt.Component;



public class MUIToolbarH extends MUIToolbar
{
    public MUIToolbarH()
    {
        MUIConstraints defaults = MUIPrefs.getMUIToolbarHDefaults();
        MUILayout layout = new MUILayoutH( defaults );
        setLayout( layout );
    }

    // From MUIComponent

    public double getWeightH()
    {
        MUIConstraints defaults = layout.iDefaults;
        if ( getComponentCount() == 0 )
        {
            return defaults.iWeightH;
        }

        double result = 0;
        Component[] components = getComponents();
        for ( int idx = 0; idx < components.length; idx++ )
        {
            result += getWeightH( components[ idx ] );
        }
        return result * defaults.iWeightH;
    }

    public double getWeightV()
    {
        MUIConstraints defaults = layout.iDefaults;
        if ( getComponentCount() == 0 )
        {
            return defaults.iWeightV;
        }

        double result = 0;
        Component[] components = getComponents();
        for ( int idx = 0; idx < components.length; idx++ )
        {
            result = Math.max( result, getWeightV( components[ idx ] ) );
        }
        return result * defaults.iWeightV;
    }
}
