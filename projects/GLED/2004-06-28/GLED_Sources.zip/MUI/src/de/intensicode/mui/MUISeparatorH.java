/************************************************************************/
/* MUI                      The.French.DJ                 November 2002 */
/************************************************************************/

package de.intensicode.mui;

import javax.swing.JSeparator;
import javax.swing.SwingConstants;

/**
 *
 */
public class MUISeparatorH extends MUIObject {

  public MUISeparatorH() {

    super.iJava = new JSeparator(SwingConstants.HORIZONTAL);
    super.iDefaults = MUIPrefs.getMUISeparatorHDefaults();

  } // MUISeparatorH(String)

} // class MUISeparatorH
