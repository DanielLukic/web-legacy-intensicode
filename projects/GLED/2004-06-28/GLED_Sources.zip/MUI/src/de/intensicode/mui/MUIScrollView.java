/************************************************************************/
/* MUI                    www.intensicode.de              November 2002 */
/************************************************************************/

package de.intensicode.mui;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;

import javax.swing.JScrollPane;



public class MUIScrollView extends MUIObject implements ComponentListener
{
    protected SizableScrollPane iScrollPane;

    protected MUIComponent iView;

    protected boolean iHorizontalFlag;

    protected boolean iVerticalFlag;



    public MUIScrollView()
    {
        iScrollPane = new SizableScrollPane();

        super.iJava = iScrollPane;
        super.iDefaults = MUIPrefs.getMUIScrollViewDefaults();

        iScrollPane.addComponentListener( this );
    }

    public MUIScrollView( MUIComponent view )
    {
        this();
        setView( view );
    }

    public void setView( MUIComponent view )
    {
        iView = view;

        Component java = view.getJava();

        iScrollPane.setViewportView( java );

        java.setSize( iScrollPane.getViewportBorderBounds().getSize() );
    }

    public MUIComponent setScrollDirections( boolean aHorizontalFlag, boolean aVerticalFlag )
    {
        iHorizontalFlag = aHorizontalFlag;
        iVerticalFlag = aVerticalFlag;

        if ( aHorizontalFlag )
        {
            iScrollPane.setHorizontalScrollBarPolicy( JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS );
        }
        else
        {
            iScrollPane.setHorizontalScrollBarPolicy( JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED );
        }
        if ( aVerticalFlag )
        {
            iScrollPane.setVerticalScrollBarPolicy( JScrollPane.VERTICAL_SCROLLBAR_ALWAYS );
        }
        else
        {
            iScrollPane.setVerticalScrollBarPolicy( JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED );
        }
        return this;
    }

    public void setPreferredSizeForwarding( boolean aForwardingFlag )
    {
        iScrollPane.setPreferredSizeForwarding( aForwardingFlag );
    }

    // From ComponentListener

    public void componentShown( ComponentEvent aEvent )
    {

    }

    public void componentResized( ComponentEvent aEvent )
    {
        Component view = iScrollPane.getViewport().getView();

        Dimension mySize = iScrollPane.getViewportBorderBounds().getSize();
        Dimension viewSize = view.getSize();

        iView.setVisibleRect( iScrollPane.getViewportBorderBounds() );

        // Enact constraints
        if ( iHorizontalFlag == false )
        {
            viewSize.width = mySize.width;
        }
        if ( iVerticalFlag == false )
        {
            viewSize.height = mySize.height;
        }

        if ( viewSize.equals( view.getSize() ) == false )
        {
            view.setSize( viewSize );
        }
    }

    public void componentMoved( ComponentEvent aEvent )
    {

    }

    public void componentHidden( ComponentEvent aEvent )
    {

    }

    // Implementation

    protected /*inner*/ class SizableScrollPane extends JScrollPane
    {
        private boolean iForwardPreferredSize;



        public void setPreferredSizeForwarding( boolean aForwardingFlag )
        {
            iForwardPreferredSize = aForwardingFlag;
        }

        // From JComponent

        public Dimension getPreferredSize()
        {
            if ( iForwardPreferredSize )
            {
                return iView.getJava().getPreferredSize();
            }
            else
            {
                return super.getPreferredSize();
            }
        }

        public Dimension getMinimumSize()
        {
            if ( iForwardPreferredSize )
            {
                return super.getPreferredSize();
            }
            else
            {
                return super.getMinimumSize();
            }
        }
    }
}
