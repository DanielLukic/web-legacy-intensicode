/************************************************************************/
/* MUI                   www.intensicode.de               November 2002 */
/************************************************************************/

package de.intensicode.mui;

import javax.swing.JSeparator;



public class MUIMenuSeparator extends MUIObject
{
    protected JSeparator iSeparator = null;



    public MUIMenuSeparator()
    {
        iSeparator = new JSeparator();
        init( iSeparator, MUIPrefs.getMUIMenuSeparatorDefaults() );
    }
}
