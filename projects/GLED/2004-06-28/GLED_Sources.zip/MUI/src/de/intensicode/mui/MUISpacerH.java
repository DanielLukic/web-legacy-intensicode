/************************************************************************/
/* MUI                      The.French.DJ                 November 2002 */
/************************************************************************/

package de.intensicode.mui;

import javax.swing.JPanel;



/**
 *
 */
public class MUISpacerH extends MUIObject {

    public MUISpacerH() {

        super.iJava = new JPanel();
        super.iDefaults = MUIPrefs.getMUISpacerDefaults();
        super.iDefaults.iWeightH = 1.0;

        init( iJava, iDefaults );

    } // MUISpacerH(String)

} // class MUISpacerH
