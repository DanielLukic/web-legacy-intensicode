/************************************************************************/
/* MUI                  www.intensicode.de                November 2002 */
/************************************************************************/

package de.intensicode.mui;

import javax.swing.JMenu;



public class MUISubMenu extends MUIObject
{
    protected JMenu iMenu = null;



    public MUISubMenu( String aMenuName )
    {
        iMenu = new JMenu( aMenuName );
        init( iMenu, MUIPrefs.getMUISubMenuDefaults() );
    }

    public void addChild( MUIComponent aEntry )
    {
        iMenu.add( aEntry.getJava() );
    }
}
