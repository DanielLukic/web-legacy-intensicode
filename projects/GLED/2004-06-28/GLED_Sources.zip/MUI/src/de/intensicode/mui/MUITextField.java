/************************************************************************/
/* MUI                   www.intensicode.de               November 2002 */
/************************************************************************/

package de.intensicode.mui;

import java.awt.Dimension;
import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.JTextField;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.Document;
import javax.swing.text.PlainDocument;



public class MUITextField extends MUIObject
{
    private SizeRestrictedTextField iTextField = null;

    public static final float KAlignLeft = JTextField.LEFT_ALIGNMENT;

    public static final float KAlignRight = JTextField.RIGHT_ALIGNMENT;

    public static final float KAlignCenbter = JTextField.CENTER_ALIGNMENT;



    public MUITextField()
    {
        iTextField = new SizeRestrictedTextField();
        preInit();
    }

    public MUITextField( String aText )
    {
        iTextField = new SizeRestrictedTextField( aText );
        preInit();
    }

    public MUITextField( int aNumberOfColumns )
    {
        iTextField = new SizeRestrictedTextField( aNumberOfColumns );
        preInit();
    }

    public MUITextField( String aText, float aAlignment )
    {
        iTextField = new SizeRestrictedTextField( aText, aAlignment );
        preInit();
    }

    public MUITextField setText( String aText )
    {
        iTextField.setText( aText );
        return this;
    }

    public MUITextField setMaxLength( int aMaxTextLength )
    {
        iDefaults.iStretchToFitH = false;
        iTextField.setMaxLength( aMaxTextLength );
        return this;
    }

    public MUITextField setFont( Font aFont )
    {
        iTextField.setFont( aFont );
        return this;
    }

    public String getText()
    {
        return iTextField.getText();
    }

    public void setEditable( boolean aEditableFlag )
    {
        iTextField.setEditable( aEditableFlag );
    }

    // Implementation

    private void preInit()
    {
        iTextField.addActionListener( this );

        MUIConstraints defaults = MUIPrefs.getMUITextFieldDefaults();
        if ( iTextField.iRestrictLength != -1 )
        {
            defaults.iStretchToFitH = false;
        }
        init( iTextField, defaults );
    }

    public void removeBorder()
    {
        iTextField.setBorder( BorderFactory.createEmptyBorder() );
    }



    private /*inner*/ class SizeRestrictedTextField extends JTextField
    {
        private int iRestrictLength = -1;



        public SizeRestrictedTextField()
        {

        }

        public SizeRestrictedTextField( String aText )
        {
            super( aText );
        }

        public SizeRestrictedTextField( int aNumberOfColumns )
        {
            super( aNumberOfColumns );
            iRestrictLength = aNumberOfColumns;
        }

        public SizeRestrictedTextField( String aText, float aAlignment )
        {
            super( aText );
            setAlignmentX( aAlignment );
        }

        public void setMaxLength( int aMaxTextLength )
        {
            iRestrictLength = aMaxTextLength;
            setColumns( iRestrictLength );
        }

        // From JTextField

        protected Document createDefaultModel()
        {
            return new SizeRestrictedDocument();
        }

        // From JComponent

        public Dimension getMinimumSize()
        {
            return getPreferredSize();
        }



        private /*inner*/ class SizeRestrictedDocument extends PlainDocument
        {
            public void insertString( int offs, String str, AttributeSet a ) throws BadLocationException
            {
                if ( str == null )
                {
                    return;
                }
                super.insertString( offs, str, a );

                int length = getLength();
                if ( iRestrictLength >= 0 && length > iRestrictLength )
                {
                    int tooMuch = length - iRestrictLength;
                    remove( iRestrictLength, tooMuch );
                }
            }
        }
    }
}
