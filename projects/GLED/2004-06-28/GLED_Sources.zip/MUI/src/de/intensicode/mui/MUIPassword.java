/*
 * Created by IntelliJ IDEA.
 * User: Lukic
 * Date: Jan 20, 2003
 * Time: 8:54:28 PM
 * To change template for new class use
 * Code Style | Class Templates options (Tools | IDE Options).
 */
package de.intensicode.mui;

import javax.swing.*;

public class MUIPassword extends MUIObject {

  private JPasswordField passwordField = null;



    public MUIPassword() {

      passwordField = new JPasswordField();

      super.iJava = passwordField;
      super.iDefaults = MUIPrefs.getMUITextFieldDefaults();

    } // MUIPassword()



    public MUIPassword( int columns ) {

      passwordField = new JPasswordField( columns );

      super.iJava = passwordField;
      super.iDefaults = MUIPrefs.getMUITextFieldDefaults();

    } // MUIPassword( int )



    public String getText() {

      return(new String(passwordField.getPassword()));

    } // String getText()



    public MUIPassword setText(String text) {

      passwordField.setText(text);

      return(this);

    } // MUIPassword setText(String)

} // class MUIPassword
