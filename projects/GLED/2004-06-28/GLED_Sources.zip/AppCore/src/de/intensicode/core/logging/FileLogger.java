/************************************************************************/
/* AppCore                www.intensicode.de                  Juni 2002 */
/************************************************************************/

package de.intensicode.core.logging;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;



public class FileLogger extends AbstractLogger
{
    protected ConsoleLogger iBackup = new ConsoleLogger();

    protected String iFileName;

    protected File iLog;

    private boolean iAppendMode = false;

    private boolean iTriedMkDirs = false;



    public FileLogger( String aFileName )
    {
        iFileName = aFileName;
        iLog = new File( aFileName );

        if ( iLog.exists() == true && iLog.canWrite() == false )
        {
            throw new LoggingException( "Cannot write to file " + aFileName );
        }
        else if ( iLog.exists() )
        {
            iAppendMode = true;
        }
    }

    // From Logger

    public void print( String msg )
    {
        String fullMsg = getHeader() + " " + msg;
        try
        {
            FileOutputStream out = new FileOutputStream( iLog, iAppendMode );
            out.write( fullMsg.getBytes( "iso-8859-1" ) );
            out.write( '\n' );
            out.flush();
            out.close();
        }
        catch ( FileNotFoundException fnfEx )
        {
            if ( iTriedMkDirs == false )
            {
                iLog.getParentFile().mkdirs();
                iTriedMkDirs = true;
                print( msg );
            }
            else
            {
                // Das hier wuerde potentiell einen Dead-Lock erzeugen:
                // Logging._error("Cannot iLog to file " + iLog.getName(), ioEx);

                // Deshalb so:
                iBackup.print( "EXCEPTION " + fnfEx.toString() );
                iBackup.print( "Cannot log to file " + iLog.getName() );
            }
        }
        catch ( IOException ioEx )
        {
            // Das hier wuerde potentiell einen Dead-Lock erzeugen:
            // Logging._error("Cannot iLog to file " + iLog.getName(), ioEx);

            // Deshalb so:
            iBackup.print( "EXCEPTION " + ioEx.toString() );
            iBackup.print( "Cannot log to file " + iLog.getName() );
        }
    }

    // From AbstractLogger

    public Object clone()
    {
        return new FileLogger( iFileName );
    }
}
