/************************************************************************/
/* GIS Server           VIVATECH Software Berlin GmbH         Juni 2002 */
/************************************************************************/

package de.intensicode.core.config;

import de.intensicode.core.GeneralException;



/**
 * Ausnahme fuer den Fall das ein Fehler in der Verarbeitung der
 * Konfigurationsdatei auftritt.
 */
public class ConfigurationException extends GeneralException {

  /**
   * Erzeugt eine neue Ausnahme mit der uebergebenen Fehlermeldung.
   */
  public ConfigurationException(String message) {

    super(message);

  } // ConfigurationException(String)



  /**
   * Erzeugt eine neue Ausnahme mit der uebergebenen Fehlermeldung und der
   * uebergebene Ausnahme als Grund.
   */
  public ConfigurationException(String message, Throwable cause) {

    super(message, cause);

  } // ConfigurationException(String, Throwable)



  /**
   * Erzeugt eine neue Ausnahme mit der uebergebeneb Ausnahme als Grund.
   */
  public ConfigurationException(Throwable cause) {

    super(cause);

  } // ConfigurationException(Throwable)

} // class ConfigurationException
