/************************************************************************/
/* AppCore               www.intensicode.de                   Juni 2002 */
/************************************************************************/

package de.intensicode.core.logging;



public class AppletLog extends Log
{
    /**
     * Initialisiert das Log-Objekt fuer das Modul mit dem angegebenen
     * Namen.
     */
    public AppletLog( String moduleName )
    {
        super( moduleName );
        iLogLevel = Logging.KDefaultLogLevel;
        addLoggers( iInfoLogs, "Applet" );
        addLoggers( iWarnLogs, "Applet" );
        addLoggers( iErrorLogs, "Applet" );
        iDateFormat = Logging.KDefaultDateFormat;
    }
}
