/*************************************************************************/
/* ReUse            Vivatech Software Berlin GmbH               May 2001 */
/*************************************************************************/

package de.intensicode.core.io;

// Import Java packages

import java.io.Reader;
import java.io.IOException;
import java.io.StreamTokenizer;

/**
 * Liest typisierte Token aus einem
 * {@link java.io.Reader Reader}. Aehnlich einem
 * {@link java.io.StreamTokenizer StreamTokenizer}, jedoch koennen direkt
 * String-, Double- und Integer-Werte ausgelesen werden.
 */
public class TypedTokenReader extends StreamTokenizer {

  /**
   * Erzeugt einen neuen Reader auf Basis des uebergebenen
   * {@link java.io.InputStream InputStream}.
   */
  public TypedTokenReader(final Reader in) {

    super(in);

  }



  /**
   * Prueft, ob das Dateiende erreicht ist.
   */
  public boolean isEOF() throws IOException {

    nextToken();

    pushBack();

    if (ttype == TT_EOF) return(true);

    return(false);

  }



  /**
   * Liest den naechsten Wert aus der Datei und erwartet einen String.
   *
   * @throws de.viatech.core.io.TokenTypException falls der Datentyp nicht
   * stimmt.
   */
  public String readString() throws IOException, TokenTypeException {

    nextToken();

    if (ttype != TT_WORD && ttype != '"')
      throw(new TokenTypeException("Kein String", lineno()));

    return(sval);

  }



  /**
   * Liest den naechsten Wert aus der Datei und erwartet ein Double.
   *
   * @throws de.viatech.core.io.TokenTypException falls der Datentyp nicht
   * stimmt.
   */
  public double readDouble() throws IOException, TokenTypeException {

    nextToken();

    if (ttype != TT_NUMBER)
      throw(new TokenTypeException("Kein Double", lineno()));

    return(nval);

  }



  /**
   * Liest den naechsten Wert aus der Datei und erwartet ein Integer.
   *
   * @throws de.viatech.core.io.TokenTypException falls der Datentyp nicht
   * stimmt.
   */
  public int readInt() throws IOException, TokenTypeException {

    nextToken();

    if (ttype != TT_NUMBER)
      throw(new TokenTypeException("Kein Integer", lineno()));

    if ((int) nval != nval)
      throw(new TokenTypeException("Kein Integer", lineno()));

    return((int) nval);

  }

}
