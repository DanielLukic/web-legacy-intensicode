/************************************************************************/
/* Gimolus3D        Vivatech Software Berlin GmbH           Januar 2003 */
/************************************************************************/

package de.intensicode.core;

import java.util.ArrayList;



/**
 * Klasse fuer die Verarbeitung von Kommandozeilenoptionen.
 */
public class CLIOptions {

    /**
     * Enthaelt die noch verfuegbaren Argumente.
     */
    private String[] args = null;



    /**
     * Initialisiert die Optionen auf Basis der uebergebenen Argumente.
     */
    public CLIOptions( String[] _args ) {

        args = _args;

    }



    /**
     * Liefert den zum angegebenen Schluessel definierten Wert von der
     * Kommandozeile falls dieser vorhanden ist. Ansonsten wird
     * <code>null</code> geliefert.
     */
    public String getArgument( String key ) {

        for ( int idx = 0; idx < args.length; idx++ ) {

            if ( args[ idx ] == null ) continue;

            String arg = args[ idx ];
            if ( arg.startsWith( key ) == false ) continue;

            if ( arg.indexOf( "=" ) < 1 )
                throw( new IllegalArgumentException
                    ( "Invalid command line. Missing assignment for key " + key ) );

            String value = arg.substring( arg.indexOf( "=" ) + 1 );

            return ( value );
        }

        return ( null );

    }



    /**
     * Liefert alle zum angegebenen Schluessel definierten Werte von der
     * Kommandozeile, falls diese vorhanden sind. Ansonsten wird eine leere
     * Liste geliefert.
     */
    public ArrayList getMultiArgument( String key ) {

        ArrayList result = new ArrayList();

        for ( int idx = 0; idx < args.length; idx++ ) {

            if ( args[ idx ] == null ) continue;

            String arg = args[ idx ];
            if ( arg.startsWith( key ) == false ) continue;

            if ( arg.indexOf( "=" ) < 1 )
                throw( new IllegalArgumentException
                    ( "Invalid command line. Missing assignment for key " + key ) );

            String value = arg.substring( arg.indexOf( "=" ) + 1 );

            result.add( value );

        }

        return ( result );

    }



    /**
     * Prueft ob das angegebene Argument auf der Kommandozeile definiert
     * ist.
     */
    public boolean hasArgument( String argumentName ) {

        for ( int idx = 0; idx < args.length; idx++ ) {

            if ( args[ idx ] == null ) continue;

            String arg = args[ idx ];
            if ( arg.startsWith( argumentName ) == true )
                return ( true );
        }

        return ( false );

    }



    /**
     * Prueft ob die angegebene Option auf der Kommandozeile vorhanden ist.
     */
    public boolean hasOption( String optionName ) {

        for ( int idx = 0; idx < args.length; idx++ ) {

            if ( args[ idx ] == null ) continue;

            String arg = args[ idx ];
            if ( arg.equals( optionName ) == true )
                return ( true );
        }

        return ( false );

    }

}
