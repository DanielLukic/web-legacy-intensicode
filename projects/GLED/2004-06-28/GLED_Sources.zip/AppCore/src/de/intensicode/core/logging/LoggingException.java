/************************************************************************/
/* AppCore                www.intensicode.de                  Juni 2002 */
/************************************************************************/

package de.intensicode.core.logging;



public class LoggingException extends RuntimeException
{
    /**
     * Erzeugt eine neue Ausnahme mit der uebergebenen Fehlermeldung.
     */
    public LoggingException( String message )
    {
        super( message );
    }

    /**
     * Erzeugt eine neue Ausnahme mit der uebergebenen Fehlermeldung und der
     * uebergebene Ausnahme als Grund.
     */
    public LoggingException( String message, Throwable cause )
    {
        super( message, cause );
    }
}
