/************************************************************************/
/* GIS Server           VIVATECH Software Berlin GmbH         Juni 2002 */
/************************************************************************/

package de.intensicode.core.logging;

/**
 * Hilfsklasse fuer den Fall das die Initialisierung des Logging-Subsystems
 * fehlschlaegt und keine Konfiguration gelesen werden kann bzw diese
 * fehlerhaft ist.
 */
public class BackupLog extends Log {

  /**
   * Initialisiert das Log-Objekt fuer das Modul mit dem angegebenen
   * Namen.
   */
  public BackupLog(String moduleName) {

    super(moduleName);

    iLogLevel = Logging.KDefaultLogLevel;

    addLoggers(iInfoLogs, Logging.KDefaultInfoLog);
    addLoggers(iWarnLogs, Logging.KDefaultWarnLog);
    addLoggers(iErrorLogs, Logging.KDefaultErrorLog);

    iDateFormat = Logging.KDefaultDateFormat;

  } // BackupLog(String)

} // class BackupLog
