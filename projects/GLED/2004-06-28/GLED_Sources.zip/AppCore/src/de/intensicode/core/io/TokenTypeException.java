/*************************************************************************/
/* ReUse            Vivatech Software Berlin GmbH               May 2000 */
/*************************************************************************/

package de.intensicode.core.io;

import java.io.PrintStream;
import java.io.PrintWriter;

/**
 * Ausnahme fuer den Fall, dass ein Token einen unbekannten oder nict
 * erwarteten Typ besitzt. Wird primaer vom
 * {@link de.intensicode.core.io.TypedTokenReader TypedTokenReader} verwendet.
 */
public class TokenTypeException extends Exception {

  /**
   * Erzeugt eine neue Ausnahme mit der uebergebenen Fehlermeldung und fuer
   * die angegebene Zeile (der Eingabedatei).
   */
  public TokenTypeException(String message, int line) {

    super(message + " - Zeile " + line);

  }

}
