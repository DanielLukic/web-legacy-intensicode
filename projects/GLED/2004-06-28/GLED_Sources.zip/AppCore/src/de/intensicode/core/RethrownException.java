/*************************************************************************/
/* MapGEN           Vivatech Software Berlin GmbH          Dezember 2000 */
/*************************************************************************/

package de.intensicode.core;

import java.io.PrintStream;
import java.io.PrintWriter;

/**
 * Allgemeine Ausnahme, welche es insbesondere ermoeglicht, andere
 * Ausnahmen in einer {@link java.lang.RuntimeException RuntimeException}
 * gekapselt zu werfen.
 * <p>
 * Ueber den primaeren Konstruktor
 * <code>RethrownException(String, Throwable)</code>
 * ist es moeglich, Ausnahmen, die explizit in <code>throws</code>-Klauseln
 * genannt werden muessen, in eine
 * {@link java.lang.RuntimeException RuntimeException} zu
 * verwandeln. Diese muessen dann nicht mehr explizit genannt werden und
 * koennen so auch ueber feste Schnittstellen hinweg geworfen werden.
 * <p>
 * Dabei sorgt die Implementierung dafuer, das der <i>Stack-Trace</i>
 * entsprechend aussagekraefitg bleibt.
 */
public class RethrownException extends RuntimeException {

  /**
   * Enthaelt ggf. eine gekapselte Ausnahme.
   */
  Throwable nestedException = null;

  /**
   * Eine ggf. vorhandene Beschreibung der Ausnahme.
   */
  String message = "";



  /**
   * Erzeugt eine neue Ausnahme und kapselt in dieser die uebergeben
   * Ausnahme. Zsuaetzlich wird eine Beschreibung uebergeben.
   * <p>
   * Dabei muss die uebergebene Ausnahme nicht notwendigerweise eine
   * <code>RuntimeException</code> sein.
   */
  public RethrownException(String message, Throwable exception) {

    this.message = message;

    this.nestedException = exception;

  }



  /**
   * Erzeugt eine neue Ausnahme und kapselt in dieser die uebergeben
   * Ausnahme.
   * <p>
   * Dabei muss die uebergebene Ausnahme nicht notwendigerweise eine
   * <code>RuntimeException</code> sein.
   */
  public RethrownException(Throwable exception) {

    this.nestedException = exception;

  }



  /**
   * Erzeugt eine neue Ausnahme mit der uebergebenen Beschreibung.
   */
  public RethrownException(String message) {

    this.message = message;

  }



  /**
   * Erzeugt eine allgemeine Ausnahme ohne Beschreibung und ohne
   * gekapselte Ausnahme.
   */
  public RethrownException() {

  }



  /**
   * Liefert die Beschreibung der Ausnahme oder einen leeren String,
   * falls keine Beschreibung angegeben wurde.
   */
  public String getMessage() {

    return(message);

  }



  /**
   * Gibt die Ausnahme auf <code>System.err</code> aus.
   * <p>
   * Dabei wird die ggf. vorhanden Beschreibung sowie die ggf. gekapselte
   * Ausnahme in die Ausgabe integriert.
   */
  public void printStackTrace() {

    printStackTrace(System.err);

  }



  /**
   * Gibt die Ausnahme auf <code>ausgabe</code> aus.
   * <p>
   * Dabei wird die ggf. vorhanden Beschreibung sowie die ggf. gekapselte
   * Ausnahme in die Ausgabe integriert.
   */
  public void printStackTrace(PrintStream out) {

    if (nestedException != null) {

      out.print(getClass().getName() + ": ");

      if (message != null) out.print(getMessage());

      out.println(); out.print("\t");

      nestedException.printStackTrace(out);

    } else {

      super.printStackTrace(out);

    }

  }



  /**
   * Gibt die Ausnahme auf <code>ausgabe</code> aus.
   * <p>
   * Dabei wird die ggf. vorhanden Beschreibung sowie die ggf. gekapselte
   * Ausnahme in die Ausgabe integriert.
   */
  public void printStackTrace(PrintWriter out) {

    if (nestedException != null) {

      out.print(getClass().getName() + ": ");

      if (message != null) out.print(getMessage());

      out.println(); out.print("\t");

      nestedException.printStackTrace(out);

    } else {

      super.printStackTrace(out);

    }

  }

}
