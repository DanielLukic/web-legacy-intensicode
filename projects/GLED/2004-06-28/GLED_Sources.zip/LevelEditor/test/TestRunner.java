/*************************************************************************/
/* Coordinates      Vivatech Software Berlin GmbH          Dezember 2000 */
/*************************************************************************/

import junit.framework.TestFailure;
import junit.framework.TestResult;
import junit.framework.TestSuite;

import java.util.Enumeration;
import java.io.*;



/**
 * Hilfsklasse zum Ausfuehren der Modultests.
 * <p>
 * Stellt eine einfache Version der JUnit-TestRunner dar. Die Tests werden
 * stillschweigend durchgefuehrt und am Ende wird ein <code>OK</code>
 * ausgegeben, falls keine Fehler auftraten.
 * <p>
 * Treten Fehler auf, werden diese ausgegeben.
 */
public class TestRunner {

    /**
     * Startet den TestRunner mit der auf der Kommandozeile uebergebenen
     * Testklasse.
     */
    public static void main( String args[] ) throws IOException {

        if ( args.length != 1 ) {

            System.out.println
                ( "Alternative 1: TestRunner <CLASSNAME>" );
            System.out.println
                ( "Alternative 2: TestRunner <CLASSFILE>.class" );
            System.out.println
                ( "Alternative 3: TestRunner <TEXTFILE>.tests" );
            System.out.println
                ( "Alternative 4: TestRunner <DIR>" );
            System.out.println
                ( );
            System.out.println
                ( "With alternative 3 the textfield should contain" );
            System.out.println
                ( "class- or filenames of the JUnit tests to be run." );
            System.out.println
                ( );

            System.exit( 10 );

        }


        File testDir = new File( args[ 0 ] );

        if ( testDir.exists() && testDir.isDirectory() ) {

            recurse( "", testDir );

        } else if ( args[ 0 ].endsWith( ".tests" ) == true ) {

            BufferedReader in = new BufferedReader( new FileReader( args[ 0 ] ) );

            String line = null;

            while ( ( line = in.readLine() ) != null )
                process( line );

        } else {

            process( args[ 0 ] );

        }

    } // void main( String[] )



    /**
     * Fuehrt einen Test aus wobei dessen Klassenname oder der Dateiname
     * der Klassendatei erwartet wird.
     */
    private static int process( String classOrFilename ) {

        Class unitTest = null;

        try {

            String arg = classOrFilename;

            if ( arg.endsWith( ".class" ) == true ) {
                arg = arg.replace( '/', '.' );
                arg = arg.replace( '\\', '.' );
                arg = arg.substring( 0, arg.length() - 6 );
            }

            unitTest = Class.forName( arg );

        } catch ( ClassNotFoundException cnfException ) {

            System.out.println
                ( "ERROR: Failed loading JUnit test class " + classOrFilename );

            return( 10 );
        }


        int lastDot = unitTest.getName().lastIndexOf( '.' );

        String name = unitTest.getName().substring
            ( lastDot + 1, unitTest.getName().length() );

        System.out.print
            ( "  Testing " + name.substring( 0, name.length() - 4 ) + ": " );


        TestResult result = new TestResult();

        new TestSuite( unitTest ).run( result );

        if ( result.wasSuccessful() == true ) {

            System.out.println( "OK" );

            return( 0 );

        } else {

            Enumeration errors = result.errors();

            while ( errors.hasMoreElements() == true ) {

                TestFailure error = ( TestFailure ) errors.nextElement();

                System.out.println( "  ERROR: " + error.failedTest() );

                error.thrownException().printStackTrace();

            }

            Enumeration failures = result.failures();

            while ( failures.hasMoreElements() == true ) {

                TestFailure failure = ( TestFailure ) failures.nextElement();

                System.out.println( "  FAILURE: " + failure.failedTest() );

                Throwable exception = failure.thrownException();

                exception.printStackTrace();

            }

            return( 10 );

        }

    } // int process( String )



    /**
     * Liest das Verzeichnis, folgt allen Unterverzeichnissen und fuehrt
     * alle enthaltenen <code>*Test.class</code> JUnit Tests durch.
     */
    private static void recurse( String path, File dir ) {

        String[] entries = dir.list();

        for ( int idx = 0; idx < entries.length; idx++) {

            String entry = entries[ idx ];

            if ( entry.equals( "CVS" ) == true ) continue;

            if ( entry.endsWith( "Test.class" ) == true ) {

                String className = null;
                if ( path.length() > 0 )
                    className = path + "." + entry.substring( 0, entry.length() - 6 );
                else
                    className = entry;

                process( className );

            } else {

                File testDir = new File( dir, entry );

                if ( testDir.isDirectory() == true ) {

                    String fullPath = null;

                    if ( path.length() > 0 )
                        fullPath = path + "." + entry;
                    else
                        fullPath = entry;

                    recurse( fullPath, new File( dir, entry ) );

                }

            }

        }

    } // void recurse( String, File )

} // class TestRunner
