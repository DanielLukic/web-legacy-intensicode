/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.actions;

import de.intensicode.gled.commands.SaveProjectAs;
import de.intensicode.mui.MUIUtils;

import java.awt.event.ActionEvent;

import javax.swing.Action;



public class SaveProjectAsAction extends GledAction
{
    public SaveProjectAsAction()
    {
        putValue( Action.NAME, "Save As" );
        putValue( Action.SHORT_DESCRIPTION, "Save project to new file" );
        putValue( Action.SMALL_ICON, MUIUtils.getIcon( "/icons/saveAs.png" ) );
        setEnabled( true );
    }

    // From ActionListener

    public void actionPerformed( ActionEvent aEvent )
    {
        iMainFrame.addCommand( new SaveProjectAs() );
    }
}
