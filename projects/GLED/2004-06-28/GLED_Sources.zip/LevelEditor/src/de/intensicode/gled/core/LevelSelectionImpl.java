/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.core;

import de.intensicode.gled.domain.LevelDataContainerListener;
import de.intensicode.gled.domain.LevelSelection;
import de.intensicode.gled.domain.LevelSelectionListener;

import java.util.ArrayList;



/**
 *
 */
public class LevelSelectionImpl implements LevelSelection, LevelDataContainerListener
{
    private static final int KLevelUnselectedID = -1;

    private LevelDataContainerImpl iLevelDataContainer;

    private ArrayList /*LevelSelectionListener*/ iListeners = new ArrayList();

    private int iNumberOfLevels = 0;

    private int iLevelIndex = KLevelUnselectedID;

    private int iLastLevelFired = iLevelIndex - 1;



    public LevelSelectionImpl( LevelDataContainerImpl aLevelDataContainer )
    {
        iLevelDataContainer = aLevelDataContainer;
        iLevelDataContainer.addListener( this );
    }

    // From LevelSelection

    public void addListener( LevelSelectionListener aListener )
    {
        iListeners.add( aListener );
    }

    public boolean isValid()
    {
        return iLevelIndex != KLevelUnselectedID;
    }

    public int getLevelIndex()
    {
        return iLevelIndex;
    }

    public void setLevelIndex( int aLevelIndex )
    {
        if ( aLevelIndex < 0 || aLevelIndex >= iNumberOfLevels )
        {
            throw new IllegalArgumentException( "Invalid level index: " + aLevelIndex );
        }
        iLevelIndex = aLevelIndex;

        checkAndUpdateSelection();
    }

    public void unselect()
    {
        iLevelIndex = KLevelUnselectedID;

        checkAndUpdateSelection();
    }

    // From LevelDataContainerListener

    public void onLevelDataChanged()
    {
        checkAndUpdateSelection();
    }

    public void onLevelDataChanged( int aLevelIndex )
    {
        checkAndUpdateSelection();
    }

    // Implementation

    private void checkAndUpdateSelection()
    {
        iNumberOfLevels = iLevelDataContainer.getNumberOfLevels();

        if ( iNumberOfLevels == 0 )
        {
            iLevelIndex = KLevelUnselectedID;
        }
        else
        {
            if ( iLevelIndex < 0 || iLevelIndex >= iNumberOfLevels )
            {
                iLevelIndex = 0;
            }
        }

        fireLevelSelectionChanged();
    }

    private void fireLevelSelectionChanged()
    {
        if ( iLastLevelFired != iLevelIndex )
        {
            iLastLevelFired = iLevelIndex;

            for ( int idx = 0; idx < iListeners.size(); ++idx )
            {
                LevelSelectionListener listener = ( LevelSelectionListener ) iListeners.get( idx );
                if ( iLevelIndex != KLevelUnselectedID )
                {
                    listener.onLevelSelectionChanged( iLevelIndex );
                }
                else
                {
                    listener.onLevelUnselected();
                }
            }
        }
    }
}
