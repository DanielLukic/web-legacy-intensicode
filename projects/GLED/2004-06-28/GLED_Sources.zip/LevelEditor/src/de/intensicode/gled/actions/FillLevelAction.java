/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.actions;

import de.intensicode.mui.MUIUtils;
import de.intensicode.gled.gui.LevelEditorView;

import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

import javax.swing.Action;
import javax.swing.KeyStroke;



public class FillLevelAction extends GledAction
{
    public FillLevelAction()
    {
        putValue( Action.NAME, "Fill level" );
        putValue( Action.SHORT_DESCRIPTION, "Fill level with currently selected tile" );
        putValue( Action.SMALL_ICON, MUIUtils.getIcon( "/icons/fill.png" ) );
        putValue( Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke( KeyEvent.VK_F, KeyEvent.CTRL_DOWN_MASK ) );
    }

    // From ActionListener

    public void actionPerformed( ActionEvent e )
    {
        LevelEditorView editor = iMainFrame.getLevelEditor();
        editor.fillLevel();
    }
}
