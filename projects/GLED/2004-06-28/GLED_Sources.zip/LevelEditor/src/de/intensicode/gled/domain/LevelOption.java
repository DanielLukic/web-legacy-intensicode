/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.domain;



/**
 *
 */
public interface LevelOption
{
    static final int KBoolean = 0;

    static final int KChoosable = 1;

    static final int KInteger = 2;

    static final int KString = 3;



    int getType();

    String getName();

    String getDefault();

    String getOptionTag();

    String getValue();

    void setValue( String aNewValue );

    void resetToDefault();

    LevelOption cloned();

    BooleanExtension getBooleanExtension();

    ChoosableExtension getChoosableExtension();

    IntegerExtension getIntegerExtension();

    StringExtension getStringExtension();



    public interface BooleanExtension
    {
        boolean getBooleanValue();
    }



    public interface ChoosableExtension
    {
        String[] getEntries();

        boolean isSetTo( String aEntry );

        int getSelectedItem();

        void setSelectedItem( int aIndex );
    }



    public interface IntegerExtension
    {
        int getMinValue();

        int getMaxValue();

        int getIntegerValue();
    }



    public interface StringExtension
    {
        int getMaxLength();

        String getStringValue();
    }
}
