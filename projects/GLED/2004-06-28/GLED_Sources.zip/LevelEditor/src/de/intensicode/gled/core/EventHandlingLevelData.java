/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.core;

import de.intensicode.gled.domain.BlockData;
import de.intensicode.gled.domain.LevelData;
import de.intensicode.gled.domain.LevelOptions;
import de.intensicode.gled.domain.TileSelection;



/**
 *
 */
class EventHandlingLevelData implements LevelData
{
    LevelData iLevelData;

    int iLevelIndex;

    LevelDataContainerImpl iContainer;



    public EventHandlingLevelData( LevelDataContainerImpl aLevelDataContainer, LevelData aLevelData, int aLevelIndex )
    {
        iContainer = aLevelDataContainer;
        iLevelData = aLevelData;
        iLevelIndex = aLevelIndex;
    }

    // From LevelData

    public BlockData getBlockData( int aX, int aY )
    {
        return new EventHandlingBlockData( this, iLevelData.getBlockData( aX, aY ) );
    }

    public int getLevelHeight()
    {
        return iLevelData.getLevelHeight();
    }

    public int getLevelWidth()
    {
        return iLevelData.getLevelWidth();
    }

    public LevelOptions getOptions()
    {
        return new EventHandlingLevelOptions( iContainer, iLevelData.getOptions(), iLevelIndex );
    }

    public void fillLevel( TileSelection aTileSelection )
    {
        iLevelData.fillLevel( aTileSelection );
        iContainer.fireLevelDataChanged( iLevelIndex );
    }

    public void scrollData( int aDeltaX, int aDeltaY )
    {
        iLevelData.scrollData( aDeltaX, aDeltaY );
        iContainer.fireLevelDataChanged( iLevelIndex );
    }
}
