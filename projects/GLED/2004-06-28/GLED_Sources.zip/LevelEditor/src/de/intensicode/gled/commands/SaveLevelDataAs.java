/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.commands;

import de.intensicode.core.logging.Log;
import de.intensicode.gled.util.AsciiFileFilter;

import java.io.File;

import javax.swing.JFileChooser;



public class SaveLevelDataAs extends GledCommand
{
    private static Log iLog = Log.getLog( "SaveLevelDataAs" );

    private static JFileChooser iFileChooser;



    public SaveLevelDataAs()
    {
        if ( iFileChooser == null )
        {
            iFileChooser = new JFileChooser( "data" );
            iFileChooser.setFileFilter( new AsciiFileFilter() );
            iFileChooser.setDialogTitle( "Save level data to new file" );
        }
    }

    // From Command

    public void execute() throws Throwable
    {
        int result = iFileChooser.showSaveDialog( iMainFrame );
        if ( result == JFileChooser.APPROVE_OPTION )
        {
            File selected = iFileChooser.getSelectedFile();
            if ( selected.getName().endsWith( ".asc" ) == false )
            {
                selected = new File( selected.getPath() + ".asc" );
            }
            iApplication.setLevelDataFile( selected );
            iCommandable.execute( new SaveLevelData() );
        }
        else if ( result == JFileChooser.ERROR_OPTION )
        {
            iLog.error( "Error showing file chooser" );
        }
    }
}
