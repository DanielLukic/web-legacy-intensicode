/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.domain;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Point;



public interface Tile
{
    void paintSized( Graphics aGc, Point aPos, Dimension aSize );

    void paintScaled( Graphics aGc, Point aPos, Dimension aSize, int aPercentage );
}
