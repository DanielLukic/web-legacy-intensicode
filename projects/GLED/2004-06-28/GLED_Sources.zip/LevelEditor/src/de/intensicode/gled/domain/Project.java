/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.domain;

import de.intensicode.gled.core.ProjectInfo;

import java.io.File;
import java.io.IOException;



public interface Project
{
    SystemFactory getSystemFactory();

    File getTileSetFile();

    File getLevelDataFile();

    TileProvider getTileProvider();

    LevelDataProvider getLevelDataProvider();

    void setTileSetFile( File aTileSetFile );

    void setTileProvider( TileProvider aTileGenerator );

    void setLevelDataFile( File aLevelDataFile );

    void setLevelDataProvider( LevelDataProvider aLevelProvider );

    ProjectInfo getDataForOutput() throws IOException;

    void dispose();
}
