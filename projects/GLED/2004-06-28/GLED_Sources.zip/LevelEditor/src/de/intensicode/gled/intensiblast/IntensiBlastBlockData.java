/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.intensiblast;

import de.intensicode.gled.domain.BlockData;
import de.intensicode.gled.domain.TileSelection;
import de.intensicode.symbian.TDes8;



/**
 *
 */
class IntensiBlastBlockData implements BlockData
{
    private IntensiBlastLevelOptions iLevelOptions;

    private final static int KNumberOfTilesPerSkin = 80;

    private final static int KDefaultSkinIndexID = -1;

    private int iTileIndex;

    private int iSkinIndex;



    public IntensiBlastBlockData( IntensiBlastLevelOptions aLevelOptions )
    {
        iLevelOptions = aLevelOptions;
    }

    public void load( TDes8 aBlockData )
    {
        iTileIndex = ( char ) aBlockData.at( 0 ) - ' ';
        iSkinIndex = ( char ) aBlockData.at( 1 ) - '0';

        if ( iSkinIndex < 0 || iSkinIndex > 3 || iSkinIndex == iLevelOptions.getBaseSkinIndex() )
        {
            iSkinIndex = KDefaultSkinIndexID;
        }

        checkConstraints();
    }

    public void save( TDes8 aBlockData )
    {
        char tileIndex = ( char ) ( iTileIndex + ' ' );
        char skinIndex = ( char ) ( iSkinIndex + '0' );

        aBlockData.set( 0, ( byte ) tileIndex );
        if ( iSkinIndex != KDefaultSkinIndexID && iSkinIndex != iLevelOptions.getBaseSkinIndex() )
        {
            aBlockData.set( 1, ( byte ) skinIndex );
        }
        else
        {
            aBlockData.set( 1, ( byte ) ' ' );
        }
        aBlockData.set( 2, ( byte ) ' ' );
    }

    // From BlockData

    public boolean isEmpty( int aLayerIndex )
    {
       return false;
    }

    public boolean matches( TileSelection aTileSelection )
    {
        int index = getTileIndex( aTileSelection.getLayerIndex() );
        return index == aTileSelection.getTileIndex();
    }

    public int getTileIndex( int aLayerIndex )
    {
        switch ( aLayerIndex )
        {
            case 0:
                if ( iSkinIndex != KDefaultSkinIndexID )
                {
                    return iTileIndex + iSkinIndex * KNumberOfTilesPerSkin;
                }
                else
                {
                    int skinIndex = iLevelOptions.getBaseSkinIndex();
                    return iTileIndex + skinIndex * KNumberOfTilesPerSkin;
                }
            default:
                throw new IllegalArgumentException( "Invalid layer index: " + aLayerIndex );
        }
    }

    public void setTileIndex( int aLayerIndex, int aSelectedTile )
    {
        switch ( aLayerIndex )
        {
            case 0:
                iTileIndex = aSelectedTile % KNumberOfTilesPerSkin;
                iSkinIndex = aSelectedTile / KNumberOfTilesPerSkin;
                break;
            default:
                throw new IllegalArgumentException( "Invalid layer index: " + aLayerIndex );
        }

        checkConstraints();
    }

    public void setFrom( TileSelection aTileSelection )
    {
        setTileIndex( aTileSelection.getLayerIndex(), aTileSelection.getTileIndex() );
    }

    public void setFrom( BlockData aData )
    {
        setTileIndex( 0, aData.getTileIndex( 0 ) );
        setTileIndex( 1, aData.getTileIndex( 1 ) );
    }

    public BlockData cloned()
    {
        IntensiBlastBlockData clone = new IntensiBlastBlockData( iLevelOptions );
        clone.iSkinIndex = this.iSkinIndex;
        clone.iTileIndex = this.iTileIndex;
        return clone;
    }

    // Implementation

    private void checkConstraints()
    {
        if ( iTileIndex < 0 || iTileIndex >= KNumberOfTilesPerSkin )
        {
            throw new IllegalArgumentException( "Tile index out of range (0..79): " + iTileIndex );
        }
        if ( iSkinIndex >= 4 )
        {
            throw new IllegalArgumentException( "Skin index out of range (0..3): " + iSkinIndex );
        }
    }
}
