/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.core;

import de.intensicode.gled.domain.LevelData;
import de.intensicode.gled.domain.LevelDataProvider;

import java.awt.Dimension;
import java.io.File;
import java.io.IOException;



class LevelDataProviderDummy implements LevelDataProvider
{
    public void load( File aLevelDataFile ) throws IOException
    {
    }

    public void save( File aLevelDataFile ) throws IOException
    {
    }

    public int getNumberOfLevels()
    {
        return 0;
    }

    public Dimension getLevelSize()
    {
        return new Dimension( 0, 0 );
    }

    public LevelData getLevelData( int aIdx )
    {
        return new LevelDataDummy();
    }

    public void addNewLevel()
    {
        throw new UnsupportedOperationException();
    }

    public void cloneLevel( int aSelected )
    {

    }

    public void copyLevel( int aSourceLevel, int aDestinationLevel )
    {
        throw new UnsupportedOperationException();
    }

    public void swapLevels( int aSourceLevel, int aDestinationLevel )
    {
        throw new UnsupportedOperationException();
    }

    public void deleteLevel( int aLevelIndex )
    {
        throw new UnsupportedOperationException();
    }
}
