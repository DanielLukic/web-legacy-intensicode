/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.constraints;

import de.intensicode.gled.core.GledApplication;
import de.intensicode.gled.domain.LevelSelection;
import de.intensicode.gled.domain.LevelSelectionListener;
import de.intensicode.gled.domain.TileSelection;
import de.intensicode.gled.domain.TileSelectionListener;



public class IfLevelAndTileSelectedConstraint extends GledConstraint implements LevelSelectionListener, TileSelectionListener
{
    private LevelSelection iLevelSelection;

    private TileSelection iTileSelection;



    public IfLevelAndTileSelectedConstraint( GledApplication aApplication )
    {
        iLevelSelection = aApplication.getLevelSelection();
        iTileSelection = aApplication.getTileSelection();

        iLevelSelection.addListener( this );
        iTileSelection.addListener( this );
    }

    // From LevelSelectionListener

    public void onLevelSelectionChanged( int aLevelIndex )
    {
        onTileSelectionChanged( iTileSelection );
    }

    public void onLevelUnselected()
    {
        onTileSelectionChanged( iTileSelection );
    }

    // From TileSelectionListener

    public void onTileSelectionChanged( TileSelection aTileSelection )
    {
        if ( iLevelSelection.isValid() && iTileSelection.isValid() )
        {
            setEnabled( true );
        }
        else
        {
            setEnabled( false );
        }
    }
}
