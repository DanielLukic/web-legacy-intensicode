/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.actions;

import de.intensicode.gled.commands.NewProject;
import de.intensicode.mui.MUIUtils;

import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

import javax.swing.Action;
import javax.swing.KeyStroke;



public class NewProjectAction extends GledAction
{
    public NewProjectAction()
    {
        putValue( Action.NAME, "New Project" );
        putValue( Action.SHORT_DESCRIPTION, "Create a new project" );
        putValue( Action.SMALL_ICON, MUIUtils.getIcon( "/icons/new.png" ) );
        putValue( Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke( KeyEvent.VK_N, KeyEvent.CTRL_DOWN_MASK ) );
        setEnabled( true );
    }

    // From ActionListener

    public void actionPerformed( ActionEvent e )
    {
        iMainFrame.addCommand( new NewProject() );
    }
}
