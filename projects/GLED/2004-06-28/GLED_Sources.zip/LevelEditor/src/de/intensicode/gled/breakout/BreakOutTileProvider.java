/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.breakout;

import de.intensicode.core.config.Configuration;
import de.intensicode.gled.domain.TileProvider;
import de.intensicode.gled.domain.TileSet;

import java.awt.Dimension;
import java.io.File;
import java.io.IOException;



public class BreakOutTileProvider implements TileProvider
{
    private Dimension iTileSize = new Dimension( 16, 12 );

    private BreakOutTileSet iBricks;

    private BreakOutTileSet iExtras;



    public BreakOutTileProvider( Configuration aConfiguration )
    {
        iTileSize.width = aConfiguration.getInt( "TileSet.TileWidth", iTileSize.width );
        iTileSize.height = aConfiguration.getInt( "TileSet.TileHeight", iTileSize.height );

        iBricks = new BreakOutTileSet( this, 0 );
        iExtras = new BreakOutTileSet( this, 1 );
    }

    // From TileProvider

    public void load( File aTileSetFile ) throws IOException
    {
        File dir = aTileSetFile.getParentFile();
        iBricks.load( new File( dir, "Bricks.png" ) );
        iExtras.load( new File( dir, "Extras.png" ) );
    }

    public int getNumberOfLayers()
    {
        return 2;
    }

    public String getLayerName( int aLayerIndex )
    {
        switch ( aLayerIndex )
        {
            case 0:
                return "Bricks";
            case 1:
                return "Extras";
            default:
                throw new IllegalArgumentException( "Invalid layer: " + aLayerIndex );
        }
    }

    public TileSet getLayerTileSet( int aLayerIndex )
    {
        switch ( aLayerIndex )
        {
            case 0:
                return iBricks;
            case 1:
                return iExtras;
            default:
                throw new IllegalArgumentException( "Invalid layer: " + aLayerIndex );
        }
    }

    public Dimension getTileSize()
    {
        return iTileSize;
    }
}
