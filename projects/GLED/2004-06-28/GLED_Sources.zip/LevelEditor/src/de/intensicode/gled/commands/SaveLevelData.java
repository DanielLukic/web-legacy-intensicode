/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.commands;

import de.intensicode.gled.domain.LevelDataContainer;

import java.io.File;
import java.io.IOException;



public class SaveLevelData extends GledCommand
{
    // From Command

    public void execute()
    {
        File file = iApplication.getLevelDataFile();
        if ( file != null )
        {
            makeBackupIfNecessary( file );
            saveLevelData();
        }
        else
        {
            iCommandable.execute( new SaveLevelDataAs() );
        }
    }

    private void makeBackupIfNecessary( File aFile )
    {
        if ( aFile.exists() )
        {
            File backup = new File( aFile.getPath() + ".bak" );
            if ( backup.exists() )
            {
                backup.delete();
            }
            aFile.renameTo( backup );
        }
    }

    private void saveLevelData()
    {
        iUserInterface.updateData();

        try
        {
            File levelDataFile = iApplication.getLevelDataFile();

            LevelDataContainer container = iApplication.getLevelDataContainer();
            container.save( levelDataFile );

            iCommandable.execute( new ShowStatusMessage( "Level data saved to " + levelDataFile.getName() ) );
        }
        catch ( IOException ex )
        {
            iCommandable.execute( new ShowErrorMessage( "Failed saving level data", ex ) );
        }
    }
}
