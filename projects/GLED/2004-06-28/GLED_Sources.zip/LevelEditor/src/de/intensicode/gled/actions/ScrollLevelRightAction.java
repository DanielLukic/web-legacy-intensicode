/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.actions;

import de.intensicode.gled.commands.ScrollLevel;
import de.intensicode.mui.MUIUtils;

import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

import javax.swing.Action;
import javax.swing.KeyStroke;



public class ScrollLevelRightAction extends GledAction
{
    private ScrollLevel iCommand;

    public ScrollLevelRightAction()
    {
        putValue( Action.NAME, "Scroll level right" );
        putValue( Action.SHORT_DESCRIPTION, "Scroll level right" );
        putValue( Action.SMALL_ICON, MUIUtils.getIcon( "/icons/right.png" ) );
        putValue( Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke( KeyEvent.VK_RIGHT, KeyEvent.ALT_DOWN_MASK | KeyEvent.CTRL_DOWN_MASK ) );
    }

    // From ActionListener

    public void actionPerformed( ActionEvent aEvent )
    {
        if ( iCommand == null )
        {
            iCommand = new ScrollLevel( +1, 0 );
        }
        iMainFrame.addCommand( iCommand );
    }
}
