/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.actions;

import de.intensicode.gled.commands.ScrollLevel;
import de.intensicode.mui.MUIUtils;

import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

import javax.swing.Action;
import javax.swing.KeyStroke;



public class ScrollLevelUpAction extends GledAction
{
    private ScrollLevel iCommand;

    public ScrollLevelUpAction()
    {
        putValue( Action.NAME, "Scroll level up" );
        putValue( Action.SHORT_DESCRIPTION, "Scroll level up" );
        putValue( Action.SMALL_ICON, MUIUtils.getIcon( "/icons/up.png" ) );
        putValue( Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke( KeyEvent.VK_UP, KeyEvent.ALT_DOWN_MASK | KeyEvent.CTRL_DOWN_MASK ) );
    }

    // From ActionListener

    public void actionPerformed( ActionEvent aEvent )
    {
        if ( iCommand == null )
        {
            iCommand = new ScrollLevel( 0, -1 );
        }
        iMainFrame.addCommand( iCommand );
    }
}
