/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.core;

import de.intensicode.gled.domain.Tile;

import java.awt.*;



public class ScaledTile implements Tile
{
    private Image iImage;

    private Rectangle iTileRect;

    private int iPercentage;



    public ScaledTile( Image aImage, Rectangle aTileRect, int aPercentage )
    {
        iImage = aImage;
        iTileRect = aTileRect;
        iPercentage = aPercentage;
    }

    // From Tile

    public void paintSized( Graphics aGc, Point aPos, Dimension aSize )
    {
        int width = aSize.width * iPercentage / 100;
        int height = aSize.height * iPercentage / 100;
        int xOff = ( aSize.width - width ) / 2;
        int yOff = ( aSize.height - height ) / 2;

        int dx1 = aPos.x + xOff;
        int dy1 = aPos.y + yOff;
        int dx2 = dx1 + width;
        int dy2 = dy1 + height;
        int sx1 = iTileRect.x;
        int sy1 = iTileRect.y;
        int sx2 = sx1 + iTileRect.width;
        int sy2 = sy1 + iTileRect.height;
        aGc.drawImage( iImage, dx1, dy1, dx2, dy2, sx1, sy1, sx2, sy2, null );
    }

    public void paintScaled( Graphics aGc, Point aPos, Dimension aSize, int aPercentage )
    {
        int width = aSize.width * aPercentage / 100;
        int height = aSize.height * aPercentage / 100;
        int xOff = ( aSize.width - width ) / 2;
        int yOff = ( aSize.height - height ) / 2;

        int dx1 = aPos.x + xOff;
        int dy1 = aPos.y + yOff;
        int dx2 = dx1 + width;
        int dy2 = dy1 + height;
        int sx1 = iTileRect.x;
        int sy1 = iTileRect.y;
        int sx2 = sx1 + iTileRect.width;
        int sy2 = sy1 + iTileRect.height;
        aGc.drawImage( iImage, dx1, dy1, dx2, dy2, sx1, sy1, sx2, sy2, null );
    }
}
