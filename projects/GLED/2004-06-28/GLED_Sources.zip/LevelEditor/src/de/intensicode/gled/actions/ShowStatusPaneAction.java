/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.actions;

import de.intensicode.mui.MUIUtils;

import java.awt.event.ActionEvent;

import javax.swing.Action;



public class ShowStatusPaneAction extends GledAction
{
    public ShowStatusPaneAction()
    {
        putValue( Action.NAME, "Show status pane" );
        putValue( Action.SHORT_DESCRIPTION, "Show status pane" );
        putValue( Action.SMALL_ICON, MUIUtils.getIcon( "/icons/unhide.png" ) );
        setEnabled( true );
    }

    // From ActionListener

    public void actionPerformed( ActionEvent e )
    {
        iMainFrame.showStatusPane();
    }
}
