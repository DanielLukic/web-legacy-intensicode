/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.core;

import de.intensicode.gled.domain.*;

import java.awt.AlphaComposite;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.image.BufferedImage;



public class LevelDrawer
{
    private GledPreferences iPreferences;

    private TileProvider iTileProvider;

    private LayerSelection iLayerSelection;



    public LevelDrawer( TileProviderHandler aTileProvider )
    {
        this( aTileProvider, new LayerSelectionImpl( aTileProvider ) );
    }

    public LevelDrawer( TileProviderHandler aTileProvider, LayerSelection aLayerSelection )
    {
        iPreferences = GledPreferences.getInstance();
        iTileProvider = aTileProvider;
        iLayerSelection = aLayerSelection;
    }

    /**
     * This will create an image of the level data. The level will be
     * scaled to fit the desired image size.
     */
    public BufferedImage createImage( LevelData aData, Dimension aSize )
    {
        BufferedImage image = new BufferedImage( aSize.width, aSize.height, iPreferences.getImageType() );
        drawLevel( aData, image, aSize );
        return image;
    }

    public void drawLevel( LevelData aData, BufferedImage aImage, Dimension aSize )
    {
        Graphics2D gc = ( Graphics2D ) aImage.getGraphics();
        gc.clearRect( 0, 0, aImage.getWidth( null ), aImage.getHeight( null ) );
        drawLevel( aData, gc, aSize );
    }

    public void drawLevel( LevelData aData, Graphics2D aGc, Dimension aSize )
    {
        int width = aData.getLevelWidth();
        int height = aData.getLevelHeight();

        double tileWidth = aSize.width / width;
        double tileHeight = aSize.height / height;

        if ( tileWidth < 1 && tileHeight < 1 )
        {
            return;
        }

        int layers = iTileProvider.getNumberOfLayers();
        for ( int layer = 0; layer < layers; layer++ )
        {
            TileSet tileSet = iTileProvider.getLayerTileSet( layer );

            if ( tileSet.getNumberOfTiles() == 0 )
            {
                continue;
            }

            if ( iLayerSelection.getVisibility( layer ) == false )
            {
                continue;
            }

            boolean reducedSize = iLayerSelection.getReducedSize( layer );
            int sizePercentage = iLayerSelection.getSizePercentage( layer );

            if ( iLayerSelection.getTransparency( layer ) )
            {
                int transPercentage = iLayerSelection.getTransparencyPercentage( layer );
                aGc.setComposite( AlphaComposite.getInstance( AlphaComposite.SRC_OVER, transPercentage * 1.0f / 100.0f ) );
            }
            else if ( tileSet.needsAlphaBlit() )
            {
                aGc.setComposite( AlphaComposite.SrcOver );
            }
            else
            {
                aGc.setPaintMode();
            }

            for ( int y = 0; y < height; y++ )
            {
                for ( int x = 0; x < width; x++ )
                {
                    BlockData id = aData.getBlockData( x, y );
                    if ( tileSet.isEmpty( id ) )
                    {
                        continue;
                    }

                    Tile aTile = tileSet.getTile( id );

                    int xStart = ( int ) ( x * aSize.width / width );
                    int yStart = ( int ) ( y * aSize.height / height );
                    int xEnd = ( int ) ( ( x + 1 ) * aSize.width / width );
                    int yEnd = ( int ) ( ( y + 1 ) * aSize.height / height );

                    Point pos = new Point( xStart, yStart );
                    Dimension size = new Dimension( xEnd - xStart, yEnd - yStart );
                    if ( size.width < 1 && size.height < 1 )
                    {
                        continue;
                    }
                    if ( reducedSize == false )
                    {
                        aTile.paintSized( aGc, pos, size );
                    }
                    else
                    {
                        aTile.paintScaled( aGc, pos, size, sizePercentage );
                    }
                }
            }
        }
    }

    public void drawLevel( LevelData aData, Graphics2D aGc, Dimension aSize, Point aClipIndex )
    {
        int width = aData.getLevelWidth();
        int height = aData.getLevelHeight();

        double tileWidth = aSize.width / width;
        double tileHeight = aSize.height / height;

        if ( tileWidth < 1 && tileHeight < 1 )
        {
            return;
        }

        int layers = iTileProvider.getNumberOfLayers();
        for ( int layer = 0; layer < layers; layer++ )
        {
            TileSet tileSet = iTileProvider.getLayerTileSet( layer );

            if ( tileSet.getNumberOfTiles() == 0 )
            {
                continue;
            }

            if ( iLayerSelection.getVisibility( layer ) == false )
            {
                continue;
            }

            boolean reducedSize = iLayerSelection.getReducedSize( layer );
            int sizePercentage = iLayerSelection.getSizePercentage( layer );

            if ( iLayerSelection.getTransparency( layer ) )
            {
                int transPercentage = iLayerSelection.getTransparencyPercentage( layer );
                aGc.setComposite( AlphaComposite.getInstance( AlphaComposite.SRC_OVER, transPercentage * 1.0f / 100.0f ) );
            }
            else if ( tileSet.needsAlphaBlit() )
            {
                aGc.setComposite( AlphaComposite.SrcOver );
            }
            else
            {
                aGc.setPaintMode();
            }

            int x = aClipIndex.x;
            int y = aClipIndex.y;
            {
                {
                    BlockData id = aData.getBlockData( x, y );
                    if ( tileSet.isEmpty( id ) )
                    {
                        continue;
                    }

                    Tile aTile = tileSet.getTile( id );

                    int xStart = ( int ) ( x * aSize.width / width );
                    int yStart = ( int ) ( y * aSize.height / height );
                    int xEnd = ( int ) ( ( x + 1 ) * aSize.width / width );
                    int yEnd = ( int ) ( ( y + 1 ) * aSize.height / height );

                    Point pos = new Point( xStart, yStart );
                    Dimension size = new Dimension( xEnd - xStart, yEnd - yStart );
                    if ( size.width < 1 && size.height < 1 )
                    {
                        continue;
                    }
                    if ( reducedSize == false )
                    {
                        aTile.paintSized( aGc, pos, size );
                    }
                    else
                    {
                        aTile.paintScaled( aGc, pos, size, sizePercentage );
                    }
                }
            }
        }
    }
}
