/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.core;

import de.intensicode.gled.domain.LevelOption;



/**
 *
 */
class EventHandlingLevelOption implements LevelOption
{
    private LevelDataContainerImpl iContainer;

    private LevelOption iLevelOption;

    private int iLevelIndex;



    public EventHandlingLevelOption( LevelDataContainerImpl aContainer, LevelOption aLevelOption, int aLevelIndex )
    {
        iContainer = aContainer;
        iLevelOption = aLevelOption;
        iLevelIndex = aLevelIndex;
    }

    // From LevelOption

    public String getName()
    {
        return iLevelOption.getName();
    }

    public int getType()
    {
        return iLevelOption.getType();
    }

    public String getDefault()
    {
        return iLevelOption.getDefault();
    }

    public String getOptionTag()
    {
        return iLevelOption.getOptionTag();
    }

    public String getValue()
    {
        return iLevelOption.getValue();
    }

    public void setValue( String aNewValue )
    {
        iLevelOption.setValue( aNewValue );
        iContainer.fireLevelDataChanged( iLevelIndex );
    }

    public void resetToDefault()
    {
        iLevelOption.resetToDefault();
        iContainer.fireLevelDataChanged( iLevelIndex );
    }

    public LevelOption cloned()
    {
        return new EventHandlingLevelOption( iContainer, iLevelOption.cloned(), iLevelIndex );
    }

    public LevelOption.BooleanExtension getBooleanExtension()
    {
        return iLevelOption.getBooleanExtension();
    }

    public LevelOption.ChoosableExtension getChoosableExtension()
    {
        return iLevelOption.getChoosableExtension();
    }

    public LevelOption.IntegerExtension getIntegerExtension()
    {
        return iLevelOption.getIntegerExtension();
    }

    public LevelOption.StringExtension getStringExtension()
    {
        return iLevelOption.getStringExtension();
    }

    // From Object

    public String toString()
    {
        return iLevelOption.toString();
    }
}
