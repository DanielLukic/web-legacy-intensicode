/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.commands;

import de.intensicode.gled.gui.LevelSorter;



public class ShowLevelSorter extends GledCommand
{
    private LevelSorter iLevelSorter;



    public ShowLevelSorter( LevelSorter aLevelSorter )
    {
        iLevelSorter = aLevelSorter;
    }

    // From Command

    public void execute() throws Throwable
    {
        iLevelSorter.show();
    }
}
