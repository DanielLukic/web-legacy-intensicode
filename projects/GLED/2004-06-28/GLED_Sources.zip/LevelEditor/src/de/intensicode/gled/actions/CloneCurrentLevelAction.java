/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.actions;

import de.intensicode.gled.commands.CloneCurrentLevel;
import de.intensicode.mui.MUIUtils;

import java.awt.event.ActionEvent;

import javax.swing.Action;



public class CloneCurrentLevelAction extends GledAction
{
    public CloneCurrentLevelAction()
    {
        putValue( Action.NAME, "Clone current level" );
        putValue( Action.SHORT_DESCRIPTION, "Clone current level" );
        putValue( Action.SMALL_ICON, MUIUtils.getIcon( "/icons/clone.png" ) );
    }

    // From ActionListener

    public void actionPerformed( ActionEvent e )
    {
        iMainFrame.addCommand( new CloneCurrentLevel() );
    }
}
