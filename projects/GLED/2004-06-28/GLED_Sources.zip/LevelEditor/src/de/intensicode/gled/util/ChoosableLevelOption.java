/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.util;

import de.intensicode.gled.domain.LevelOption;

import java.util.ArrayList;



/**
 *
 */
public class ChoosableLevelOption extends AbstractLevelOption implements LevelOption.ChoosableExtension
{
    private ArrayList iEntries = new ArrayList();

    private String[] iStrings = null;



    public ChoosableLevelOption()
    {
        super( KChoosable );
    }

    public void addEntry( String aEntry )
    {
        iEntries.add( aEntry );

        iStrings = null;
    }

    // From LevelOption

    public LevelOption cloned()
    {
        ChoosableLevelOption clone = new ChoosableLevelOption();
        clone.copyFrom( this );
        clone.iEntries = ( ArrayList ) iEntries.clone();
        return clone;
    }

    public LevelOption.ChoosableExtension getChoosableExtension()
    {
        return this;
    }

    // From ChoosableExtension

    public String[] getEntries()
    {
        if ( iStrings == null )
        {
            iStrings = new String[ iEntries.size() ];
            iEntries.toArray( iStrings );
        }
        return iStrings;
    }

    public boolean isSetTo( String aEntry )
    {
        return iValue.equals( aEntry );
    }

    public int getSelectedItem()
    {
        int numberOfEntries = iEntries.size();
        for ( int idx = 0; idx < numberOfEntries; idx++ )
        {
            String entry = getEntry( idx );
            if ( entry.equals( iValue ) )
            {
                return idx;
            }
        }
        throw new IllegalStateException( "Level option not initialized" );
    }

    public void setSelectedItem( int aIndex )
    {
        iValue = getEntry( aIndex );
    }

    // Implementation

    private String getEntry( int aIndex )
    {
        return ( String ) iEntries.get( aIndex );
    }
}
