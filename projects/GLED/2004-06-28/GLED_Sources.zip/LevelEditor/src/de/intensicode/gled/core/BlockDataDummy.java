/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.core;

import de.intensicode.gled.domain.BlockData;
import de.intensicode.gled.domain.TileSelection;



class BlockDataDummy implements BlockData
{
    // From BlockData

    public boolean isEmpty( int aLayerIndex )
    {
        return true;
    }

    public boolean matches( TileSelection aTileSelection )
    {
        return false;
    }

    public int getTileIndex( int aLayerIndex )
    {
        return 0;
    }

    public void setTileIndex( int aLayerIndex, int aSelectedTile )
    {

    }

    public void setFrom( TileSelection aTileSelection )
    {

    }

    public void setFrom( BlockData aData )
    {

    }

    public BlockData cloned()
    {
        return this;
    }
}
