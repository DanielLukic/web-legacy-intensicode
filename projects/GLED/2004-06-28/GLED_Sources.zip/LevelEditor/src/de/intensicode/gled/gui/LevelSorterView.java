/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.gui;

import de.intensicode.gled.core.GledPreferences;
import de.intensicode.gled.domain.*;
import de.intensicode.gled.core.LevelDrawer;
import de.intensicode.mui.MUIAction;
import de.intensicode.mui.MUIComponent;
import de.intensicode.mui.MUITable;
import de.intensicode.mui.OnActionListener;

import java.awt.Dimension;
import java.awt.event.ComponentEvent;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.EventObject;



public class LevelSorterView extends MUITable implements LevelDataContainerListener, TileProviderListener, OnActionListener
{
    private GledPreferences iPreferences;

    private LevelDataContainer iLevelDataContainer;

    private TileProviderHandler iTileContainer;

    private Dimension iThumbnailSize;

    private LevelDrawer iLevelDrawer;

    private ArrayList /*BufferedImage*/ iThumbnails;

    private ThumbnailComponent[] iThumbnailArray;

    private Dimension iDesiredThumbnailSize;

    private int iSelectedLevel = -1;

    private boolean iShowingLevelNames = false;

    private boolean iAmUpdating;



    public LevelSorterView( Application aApplication )
    {
        this( aApplication, new Dimension( -1, -1 ) );
    }

    public LevelSorterView( Application aApplication, Dimension aThumbnailSize )
    {
        iPreferences = GledPreferences.getInstance();

        iLevelDataContainer = aApplication.getLevelDataContainer();
        iTileContainer = aApplication.getTileContainer();

        iThumbnailSize = aThumbnailSize;
        iLevelDrawer = new LevelDrawer( iTileContainer );
        iThumbnails = new ArrayList();
        iDesiredThumbnailSize = new Dimension( iJava.getWidth(), iJava.getWidth() );

        iLevelDataContainer.addListener( this );
        iTileContainer.addListener( this );

        setAction( ON_SELECTION, this );
    }

    public void setShowingLevelNames( boolean aShowingFlag )
    {
        iShowingLevelNames = aShowingFlag;

        if ( iThumbnailArray == null )
        {
            return;
        }

        if ( iShowingLevelNames )
        {
            for ( int idx = 0; idx < iThumbnailArray.length; ++idx )
            {
                iThumbnailArray[ idx ].showTitle();
            }
        }
        else
        {
            for ( int idx = 0; idx < iThumbnailArray.length; ++idx )
            {
                iThumbnailArray[ idx ].hideTitle();
            }
        }
        iJava.repaint( 250 );
    }

    // From LevelDataContainerListener

    public void onLevelDataChanged()
    {
        validateSelection();
        if ( allDataAvailable() )
        {
            updateThumbnailSizeIfNecessary();
            if ( thumbnailSizeValid() )
            {
                prepareThumbnails();
                setData( iThumbnailArray );
                redrawThumbnails();
            }
        }
        else
        {
            clearData();
        }
        iJava.repaint( 250 );
    }

    public void onLevelDataChanged( int aLevelIndex )
    {
        int levels = iLevelDataContainer.getNumberOfLevels();
        for ( int idx = 0; idx < levels; idx++ )
        {
            if ( idx == aLevelIndex && iThumbnails.size() > idx )
            {
                BufferedImage thumbnail = ( BufferedImage ) iThumbnails.get( idx );
                LevelData data = iLevelDataContainer.getLevelData( idx );
                iLevelDrawer.drawLevel( data, thumbnail, iThumbnailSize );
            }
        }
        iTable.repaint( 250 );
    }

    // From TileProviderListener

    public void onTileProviderChanged()
    {
        validateSelection();
        if ( allDataAvailable() )
        {
            updateThumbnailSizeIfNecessary();
            if ( thumbnailSizeValid() )
            {
                prepareThumbnails();
                iAmUpdating = true;
                setData( iThumbnailArray );
                iAmUpdating = false;
                redrawThumbnails();
            }
        }
        else
        {
            clearData();
        }
        iJava.repaint( 250 );
    }

    // From ComponentListener

    public void componentResized( ComponentEvent aEvent )
    {
        super.componentResized( aEvent );

        iDesiredThumbnailSize.width = iTable.getCellWidth();
        iDesiredThumbnailSize.height = iTable.getCellWidth();
        if ( iDesiredThumbnailSize.width < 8 )
        {
            return;
        }
        iTable.setCellSize( iDesiredThumbnailSize );

        if ( allDataAvailable() )
        {
            updateThumbnailSizeIfNecessary();
            if ( thumbnailSizeValid() )
            {
                redrawThumbnails();
            }
        }
        iJava.repaint( 250 );
    }

    // From OnActionListener

    public void onAction( MUIComponent comp, MUIAction action, EventObject event )
    {
        if ( iAmUpdating )
        {
            return;
        }
//        if ( iSelectedLevel != iList.getSelectedIndex() )
//        {
//            iSelectedLevel = iList.getSelectedIndex();
//            fireSelectedLevel();
//        }
    }



    // Implementation

    private void validateSelection()
    {
        if ( iSelectedLevel < 0 || iSelectedLevel >= iLevelDataContainer.getNumberOfLevels() )
        {
            iSelectedLevel = -1;
        }
    }

    private boolean allDataAvailable()
    {
        if ( iLevelDataContainer.getNumberOfLevels() == 0 )
        {
            return false;
        }
        if ( iTileContainer.getNumberOfLayers() == 0 )
        {
            return false;
        }
        return true;
    }

    private void updateThumbnailSizeIfNecessary()
    {
        iDesiredThumbnailSize.width = iJava.getWidth();
        iDesiredThumbnailSize.height = iJava.getWidth();

        if ( iThumbnailSize.width == -1 || iThumbnailSize.height == -1 )
        {
            Dimension levelSize = iLevelDataContainer.getLevelSize();
            Dimension tileSize = iTileContainer.getTileSize();

            int width = levelSize.width * tileSize.width;
            int height = levelSize.height * tileSize.height;

            if ( width > 0 && height > 0 )
            {
                iThumbnailSize.width = width;
                iThumbnailSize.height = height;
            }
        }
    }

    private boolean thumbnailSizeValid()
    {
        return iThumbnailSize.width > 0 && iThumbnailSize.height > 0;
    }

    private void prepareThumbnails()
    {
        int levels = iLevelDataContainer.getNumberOfLevels();

        int width = iThumbnailSize.width;
        int height = iThumbnailSize.height;

        while ( iThumbnails.size() < levels )
        {
            iThumbnails.add( new BufferedImage( width, height, iPreferences.getImageType() ) );
        }
        resizeThumbnailsIfNecessary( width, height );

        if ( iThumbnailArray == null || iThumbnailArray.length != levels )
        {
            iThumbnailArray = new ThumbnailComponent[ levels ];
        }
        updateThumbnailsArray();
    }

    private void resizeThumbnailsIfNecessary( int aWidth, int aHeight )
    {
        for ( int idx = 0; idx < iThumbnails.size(); idx++ )
        {
            BufferedImage thumbnail = ( BufferedImage ) iThumbnails.get( idx );

            boolean badSize = false;
            if ( thumbnail.getWidth() != aWidth )
            {
                badSize = true;
            }
            else if ( thumbnail.getHeight() != aHeight )
            {
                badSize = true;
            }

            if ( badSize )
            {
                iThumbnails.remove( idx );
                iThumbnails.add( idx, new BufferedImage( aWidth, aHeight, iPreferences.getImageType() ) );
            }
        }
    }

    private void updateThumbnailsArray()
    {
        for ( int idx = 0; idx < iThumbnailArray.length; idx++ )
        {
            BufferedImage thumbnail = ( BufferedImage ) iThumbnails.get( idx );
            if ( iThumbnailArray[ idx ] == null )
            {
                LevelData levelData = iLevelDataContainer.getLevelData( idx );
                iThumbnailArray[ idx ] = new ThumbnailComponent( levelData.getOptions(), thumbnail, iShowingLevelNames );
            }
            else
            {
                iThumbnailArray[ idx ].setImage( thumbnail );
            }
        }
    }

    private void redrawThumbnails()
    {
        int levels = iLevelDataContainer.getNumberOfLevels();
        for ( int idx = 0; idx < levels; idx++ )
        {
            if ( idx < iThumbnails.size() )
            {
                BufferedImage thumbnail = ( BufferedImage ) iThumbnails.get( idx );
                LevelData data = iLevelDataContainer.getLevelData( idx );
                iLevelDrawer.drawLevel( data, thumbnail, iThumbnailSize );
            }
        }
    }

    private void clearData()
    {
        iThumbnailArray = null;
        setData( new Object[ 0 ] );
    }

//    private void fireSelectedLevel()
//    {
//        for ( int idx = 0; idx < iListeners.size(); idx++ )
//        {
//            LevelSelectorListener listener = ( LevelSelectorListener ) iListeners.get( idx );
//            if ( iSelectedLevel > -1 )
//            {
//                listener.onLevelSelected( iSelectedLevel );
//                iList.scrollRectToVisible( iList.getCellBounds( iSelectedLevel, iSelectedLevel ) );
//            }
//            else
//            {
//                listener.onLevelUnSelected();
//            }
//        }
//    }
}
