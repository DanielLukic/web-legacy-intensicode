/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.domain;

import de.intensicode.core.config.ConfigurationException;



public interface SystemFactory
{
    LevelDataProvider createLevelDataProvider() throws ConfigurationException;

    TileProvider createTileProvider() throws ConfigurationException;

    BackgroundPainter createBackgroundPainter( Application aApplication );

    void dispose();
}
