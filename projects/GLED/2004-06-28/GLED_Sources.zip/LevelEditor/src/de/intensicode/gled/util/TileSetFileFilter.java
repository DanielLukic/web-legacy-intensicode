/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.util;

import java.io.File;

import javax.swing.filechooser.FileFilter;



public class TileSetFileFilter extends FileFilter
{
    public boolean accept( File aFile )
    {
        if ( aFile.getName().toLowerCase().endsWith( ".gif" ) )
        {
            return true;
        }
        else if ( aFile.getName().toLowerCase().endsWith( ".png" ) )
        {
            return true;
        }
        else if ( aFile.getName().toLowerCase().endsWith( ".bmp" ) )
        {
            return true;
        }
        return aFile.isDirectory();
    }

    public String getDescription()
    {
        return "Bitmap Tile Set Data";
    }
}
