/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.commands;

import de.intensicode.gled.gui.NewProjectDialog;



public class NewProject extends GledCommand
{
    private NewProjectDialog iDialog = null;



    // From Command

    public void execute() throws Throwable
    {
        if ( iDialog == null )
        {
            iDialog = new NewProjectDialog( iMainFrame, iApplication );
        }
        iDialog.show();
    }
}
