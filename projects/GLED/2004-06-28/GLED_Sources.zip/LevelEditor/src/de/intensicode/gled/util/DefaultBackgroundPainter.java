/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.util;

import de.intensicode.gled.domain.BackgroundPainter;
import de.intensicode.gled.domain.LevelData;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.Rectangle;



/**
 *
 */
public class DefaultBackgroundPainter implements BackgroundPainter
{
    public void paintInto( Graphics2D aGc, Dimension aSize, LevelData aLevelData )
    {
        aGc.setColor( Color.BLACK );
        aGc.fillRect( 0, 0, aSize.width, aSize.height );
    }

    public void paintRestricted( Graphics2D aGc, Dimension aSize, LevelData aLevelData, Rectangle aClipRect )
    {
        aGc.setClip( aClipRect );
        paintInto( aGc, aSize, aLevelData );
    }
}
