/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.util;

import de.intensicode.gled.domain.LevelOption;



/**
 *
 */
public abstract class AbstractLevelOption implements LevelOption
{
    protected int iType;

    protected String iName;

    protected String iValue;

    protected String iDefault;

    protected String iTag;



    public AbstractLevelOption( int aType )
    {
        iType = aType;
    }

    public void setName( String aName )
    {
        iName = aName;
    }

    public void setDefault( String aDefault )
    {
        iDefault = aDefault;
    }

    public void setTag( String aTag )
    {
        iTag = aTag;
    }

    // From LevelOption

    public int getType()
    {
        return iType;
    }

    public String getName()
    {
        return iName;
    }

    public String getDefault()
    {
        return iDefault;
    }

    public String getOptionTag()
    {
        return iTag;
    }

    public String getValue()
    {
        return iValue;
    }

    public void setValue( String aNewValue )
    {
        iValue = aNewValue;
    }

    public void resetToDefault()
    {
        setValue( iDefault );
    }

    public LevelOption.BooleanExtension getBooleanExtension()
    {
        throw new UnsupportedOperationException();
    }

    public LevelOption.ChoosableExtension getChoosableExtension()
    {
        throw new UnsupportedOperationException();
    }

    public LevelOption.IntegerExtension getIntegerExtension()
    {
        throw new UnsupportedOperationException();
    }

    public LevelOption.StringExtension getStringExtension()
    {
        throw new UnsupportedOperationException();
    }

    // From Object

    public String toString()
    {
        return iName;
    }

    // Protected Interface

    protected void copyFrom( AbstractLevelOption aSource )
    {
        iType = aSource.iType;
        iName = aSource.iName;
        iValue = aSource.iValue;
        iDefault = aSource.iDefault;
        iTag = aSource.iTag;
    }
}
