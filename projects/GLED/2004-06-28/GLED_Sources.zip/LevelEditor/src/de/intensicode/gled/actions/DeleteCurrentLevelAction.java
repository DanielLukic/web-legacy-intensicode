/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.actions;

import de.intensicode.mui.MUIUtils;
import de.intensicode.gled.commands.DeleteCurrentLevel;

import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

import javax.swing.Action;
import javax.swing.KeyStroke;



public class DeleteCurrentLevelAction extends GledAction
{
    public DeleteCurrentLevelAction()
    {
        putValue( Action.NAME, "Delete level" );
        putValue( Action.SHORT_DESCRIPTION, "Delete currently selected level" );
        putValue( Action.SMALL_ICON, MUIUtils.getIcon( "/icons/delete.png" ) );
        putValue( Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke( KeyEvent.VK_D, KeyEvent.ALT_DOWN_MASK ) );
    }

    // From ActionListener

    public void actionPerformed( ActionEvent e )
    {
        iMainFrame.addCommand( new DeleteCurrentLevel() );
    }
}
