/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.constraints;

import de.intensicode.gled.core.GledApplication;
import de.intensicode.gled.domain.LevelSelection;
import de.intensicode.gled.domain.LevelSelectionListener;
import de.intensicode.gled.domain.TileProviderHandler;
import de.intensicode.gled.domain.TileProviderListener;



public class IfLevelSelectedConstraint extends GledConstraint implements LevelSelectionListener, TileProviderListener
{
    private LevelSelection iLevelSelection;

    private TileProviderHandler iTileContainer;



    public IfLevelSelectedConstraint( GledApplication aApplication )
    {
        iLevelSelection = aApplication.getLevelSelection();
        iTileContainer = aApplication.getTileContainer();

        iLevelSelection.addListener( this );
        iTileContainer.addListener( this );
    }

    // From LevelSelectorListener

    public void onLevelSelectionChanged( int aLevelIndex )
    {
        onTileProviderChanged();
    }

    public void onLevelUnselected()
    {
        onTileProviderChanged();
    }

    // From TileProviderListener

    public void onTileProviderChanged()
    {
        if ( iLevelSelection.isValid() && iTileContainer.getNumberOfLayers() > 0 )
        {
            setEnabled( true );
        }
        else
        {
            setEnabled( false );
        }
    }
}
