/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.util;

import de.intensicode.core.Reflection;
import de.intensicode.core.ResourceManager;
import de.intensicode.gled.domain.LevelOption;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.NoSuchElementException;



public class ExternalLevelOptions
{
    private ArrayList iOptions = new ArrayList();



    public ExternalLevelOptions()
    {
//        iDigester.push( this );
//
//        iDigester.addObjectCreate( "LevelOptions/BooleanLevelOption", "de.intensicode.gled.util.BooleanLevelOption" );
//        iDigester.addCallMethod( "LevelOptions/BooleanLevelOption/Name", "setName", 0 );
//        iDigester.addCallMethod( "LevelOptions/BooleanLevelOption/Default", "setDefault", 0 );
//        iDigester.addCallMethod( "LevelOptions/BooleanLevelOption/Tag", "setTag", 0 );
//        iDigester.addSetNext( "LevelOptions/BooleanLevelOption", "addLevelOption" );
//
//        iDigester.addObjectCreate( "LevelOptions/IntegerLevelOption", "de.intensicode.gled.util.IntegerLevelOption" );
//        iDigester.addCallMethod( "LevelOptions/IntegerLevelOption/Name", "setName", 0 );
//        iDigester.addCallMethod( "LevelOptions/IntegerLevelOption/Default", "setDefault", 0 );
//        iDigester.addCallMethod( "LevelOptions/IntegerLevelOption/Tag", "setTag", 0 );
//        iDigester.addCallMethod( "LevelOptions/IntegerLevelOption/Min", "setMin", 0 );
//        iDigester.addCallMethod( "LevelOptions/IntegerLevelOption/Max", "setMax", 0 );
//        iDigester.addSetNext( "LevelOptions/IntegerLevelOption", "addLevelOption" );
//
//        iDigester.addObjectCreate( "LevelOptions/StringLevelOption", "de.intensicode.gled.util.StringLevelOption" );
//        iDigester.addCallMethod( "LevelOptions/StringLevelOption/Name", "setName", 0 );
//        iDigester.addCallMethod( "LevelOptions/StringLevelOption/Default", "setDefault", 0 );
//        iDigester.addCallMethod( "LevelOptions/StringLevelOption/Tag", "setTag", 0 );
//        iDigester.addCallMethod( "LevelOptions/StringLevelOption/MaxLength", "setMaxLength", 0 );
//        iDigester.addSetNext( "LevelOptions/StringLevelOption", "addLevelOption" );
//
//        iDigester.addObjectCreate( "LevelOptions/ChoosableLevelOption", "de.intensicode.gled.util.ChoosableLevelOption" );
//        iDigester.addCallMethod( "LevelOptions/ChoosableLevelOption/Name", "setName", 0 );
//        iDigester.addCallMethod( "LevelOptions/ChoosableLevelOption/Default", "setDefault", 0 );
//        iDigester.addCallMethod( "LevelOptions/ChoosableLevelOption/Tag", "setTag", 0 );
//        iDigester.addCallMethod( "LevelOptions/ChoosableLevelOption/Entry", "addEntry", 0 );
//        iDigester.addSetNext( "LevelOptions/ChoosableLevelOption", "addLevelOption" );
    }

    public void load( String aExternalConfig ) throws IOException
    {
        iOptions.clear();

        URL config = ResourceManager.getResource( aExternalConfig );
        if ( config == null )
        {
            throw new FileNotFoundException( aExternalConfig );
        }

        InputStreamReader reader = new InputStreamReader( config.openStream() );
        BufferedReader in = new BufferedReader( reader );

        LevelOption option = null;
        for ( ; ; )
        {
            String line = in.readLine();
            if ( line == null )
            {
                break;
            }
            if ( line.startsWith( "//" ) )
            {
                continue;
            }
            if ( line.equals( "" ) )
            {
                option = null;
            }
            if ( line.startsWith( "[" ) )
            {
                String className = "de.intensicode.gled.util." + line.substring( 1, line.length() - 1 );
                option = ( LevelOption ) Reflection.createInstance( className );
                addLevelOption( option );
            }
            int assignmentColon = line.indexOf( ':' );
            if ( assignmentColon > 0 )
            {
                if ( line.startsWith( "+" ) == false )
                {
                    String property = line.substring( 0, assignmentColon ).trim();
                    String value = line.substring( assignmentColon + 1 ).trim();
                    Reflection.callMethod( option, "set" + property, new Object[]{value} );
                }
                else
                {
                    String property = line.substring( 1, assignmentColon ).trim();
                    String value = line.substring( assignmentColon + 1 ).trim();
                    Reflection.callMethod( option, "add" + property, new Object[]{value} );
                }
            }
        }
    }

    public void addLevelOption( LevelOption aLevelOption )
    {
        iOptions.add( aLevelOption );
    }

    public int getNumberOfOptions()
    {
        return iOptions.size();
    }

    public LevelOption getOption( int aIndex )
    {
        return ( LevelOption ) iOptions.get( aIndex );
    }

    public void resetToDefaults()
    {
        int numberOfOptions = getNumberOfOptions();
        for ( int idx = 0; idx < numberOfOptions; idx++ )
        {
            LevelOption option = getOption( idx );
            option.resetToDefault();
        }
    }

    public LevelOption getOption( String aOptionName ) throws NoSuchElementException
    {
        int numberOfOptions = getNumberOfOptions();
        for ( int idx = 0; idx < numberOfOptions; idx++ )
        {
            LevelOption option = getOption( idx );
            if ( option.getName().equals( aOptionName ) )
            {
                return option;
            }
        }
        throw new NoSuchElementException( "Unknown level option: " + aOptionName );
    }

    public LevelOption getOptionByTag( int aCode ) throws NoSuchElementException
    {
        int numberOfOptions = getNumberOfOptions();
        for ( int idx = 0; idx < numberOfOptions; idx++ )
        {
            LevelOption option = getOption( idx );
            String tag = option.getOptionTag();
            if ( tag != null && tag.charAt( 0 ) == aCode )
            {
                return option;
            }
        }
        throw new NoSuchElementException( "Unknown level option tag: " + ( char ) aCode );
    }

    public ExternalLevelOptions cloned()
    {
        ExternalLevelOptions clone = new ExternalLevelOptions();
        for ( int idx = 0; idx < getNumberOfOptions(); idx++ )
        {
            LevelOption option = getOption( idx );
            clone.addLevelOption( option.cloned() );
        }
        return clone;
    }
}
