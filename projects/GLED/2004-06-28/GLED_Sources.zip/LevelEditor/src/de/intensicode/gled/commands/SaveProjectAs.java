/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.commands;

import de.intensicode.core.logging.Log;
import de.intensicode.gled.util.GledFileFilter;

import java.io.File;

import javax.swing.JFileChooser;



public class SaveProjectAs extends GledCommand
{
    private static Log iLog = Log.getLog( "SaveProjectAs" );

    private static GledFileFilter iFileFilter = new GledFileFilter();

    private static JFileChooser iFileChooser;



    public SaveProjectAs()
    {
        if ( iFileChooser == null )
        {
            iFileChooser = new JFileChooser( "data" );
            iFileChooser.setFileFilter( iFileFilter );
            iFileChooser.setDialogTitle( "Save project to new file" );
        }
    }

    // From Command

    public void execute() throws Throwable
    {
        int result = iFileChooser.showSaveDialog( iMainFrame );
        if ( result == JFileChooser.APPROVE_OPTION )
        {
            File selected = iFileChooser.getSelectedFile();
            if ( selected.getName().endsWith( iFileFilter.getExtension() ) == false )
            {
                selected = new File( selected.getPath() + ".gled" );
            }
            iApplication.setProjectFile( selected );
            iCommandable.execute( new SaveProject() );
        }
        else if ( result == JFileChooser.ERROR_OPTION )
        {
            iLog.error( "Error showing file chooser" );
        }
    }
}
