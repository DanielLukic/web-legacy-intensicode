/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.core;

import de.intensicode.core.logging.Log;
import de.intensicode.gled.domain.*;

import java.awt.Dimension;
import java.util.ArrayList;
import java.io.File;
import java.io.IOException;



class TileProviderHandlerImpl implements TileProviderHandler
{
    private static Log iLog = Log.getLog( "TileProviderHandlerImpl" );

    private TileProvider iProvider;

    private ArrayList iListeners = new ArrayList();

    private ArrayList iLayers = new ArrayList();



    public TileProviderHandlerImpl( Project aProject )
    {
        iLog.info( "TileProviderHandlerImpl" );

        iProvider = aProject.getTileProvider();

        createLayers();
    }

    public void setProject( Project aNewProject )
    {
        iLog.info( "setProject " + aNewProject );

        iProvider = aNewProject.getTileProvider();

        createLayers();

        fireTileContainerChanged();
    }

    // From TileProviderHandler

    public void addListener( TileProviderListener aListener )
    {
        iListeners.add( aListener );
    }

    public void removeListener( TileProviderListener aListener )
    {
        iListeners.remove( aListener );
    }

    public TileSetHandler getLayerTileSetHandler( int aLayerIndex )
    {
        return ( TileSetHandler ) iLayers.get( aLayerIndex );
    }

    // From TileProvider

    public int getNumberOfLayers()
    {
        return iProvider.getNumberOfLayers();
    }

    public String getLayerName( int aLayerIndex )
    {
        return iProvider.getLayerName( aLayerIndex );
    }

    public TileSet getLayerTileSet( int aLayerIndex )
    {
        return iProvider.getLayerTileSet( aLayerIndex );
    }

    public Dimension getTileSize()
    {
        return iProvider.getTileSize();
    }

    public void load( File aTileSetFile ) throws IOException
    {
        iProvider.load( aTileSetFile );
    }

    // Implementation

    private void createLayers()
    {
        iLayers.clear();
        int layers = iProvider.getNumberOfLayers();
        for ( int idx = 0; idx < layers; idx++ )
        {
            TileSet tileSet = getLayerTileSet( idx );
            iLayers.add( new TileSetHandlerImpl( tileSet ) );
        }
    }

    private void fireTileContainerChanged()
    {
        for ( int idx = 0; idx < iListeners.size(); idx++ )
        {
            TileProviderListener listener = ( TileProviderListener ) iListeners.get( idx );
            listener.onTileProviderChanged();
        }
    }
}
