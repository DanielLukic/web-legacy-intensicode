/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.domain;



public interface LevelDataContainer extends LevelDataProvider
{
    void addListener( LevelDataContainerListener aListener );

    /**
     * Use this lock the leveldata. While being locked, listeners
     * won't be notified of data changes. If data changed during
     * lock, however, the will be notified as soon as the lock has
     * been released.
     */
    void setUpdateLock( boolean aUpdateLock );
}
