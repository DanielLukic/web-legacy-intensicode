/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.breakout;

import de.intensicode.core.Assert;
import de.intensicode.core.logging.Log;
import de.intensicode.gled.domain.*;
import de.intensicode.gled.util.LimitedTileSet;

import java.awt.*;
import java.awt.image.ColorModel;
import java.awt.image.Raster;
import java.awt.image.WritableRaster;
import java.io.File;
import java.io.IOException;
import java.util.Random;



/**
 *
 */
public class BreakOutBackgroundPainter implements BackgroundPainter, TileProviderListener
{
    private final static int KNumberOfStars = 256;

    private final static int KStarFieldSize = 256;

    private final static int KGradientLength = 256;

    private Log iLog = Log.getLog();

    private Application iApplication;

    private Point[] iStars = null;

    private Color[] iStarColors = null;

    private Color[] iGradient = null;

    private TileProviderHandler iTileContainer;

    private LayerSelection iLayerSelection;

    private ShadowComposite iShadowComposite = new ShadowComposite();

    private Point iShadowOffset = new Point( 20, 16 );

    private TileSet iScoreBoardTileSet;

    private TileSet iBackgroundTileSet;

    private TileSet iBatTileSet;

    private final int KPlayFieldWidth = 176;

    private final int KPlayFieldHeight = 188;

    private final int KBackgrounTileSize = 64;

    private final int KScoreBoardWidth = KPlayFieldWidth;

    private final int KScoreBoardHeight = 32;

    private final int KScoreBoardInvisibleHeight = 20;

    private final int KBatWidth = 40;

    private final int KBatHeight = 8;

    private boolean iAmDisposed = false;



    public BreakOutBackgroundPainter( Application aApplication )
    {
        iApplication = aApplication;

        initStars();
        initGradient();

        iTileContainer = aApplication.getTileContainer();
        iLayerSelection = aApplication.getLayerSelection();

        iScoreBoardTileSet = new LimitedTileSet( new Dimension( KScoreBoardWidth, KScoreBoardHeight ) );
        iBackgroundTileSet = new LimitedTileSet( new Dimension( KBackgrounTileSize, KBackgrounTileSize ) );
        iBatTileSet = new LimitedTileSet( new Dimension( KBatWidth, KBatHeight ) );

        onTileProviderChanged();

        iTileContainer.addListener( this );
    }

    public void paintInto( Graphics2D aGc, Dimension aSize, LevelData aLevelData )
    {
        if ( iAmDisposed )
        {
            return;
        }

        LevelOptions options = aLevelData.getOptions();

        if ( getBackgroundColoring( options ) )
        {
            drawColoredBackground( aGc, aSize, aLevelData.getOptions() );
        }
        else if ( getBackgroundTiling( options ) )
        {
            drawTiledBackground( aGc, aSize, options );
        }
        else
        {
            aGc.setColor( Color.BLACK );
            aGc.fillRect( 0, 0, aSize.width, aSize.height );
        }

        if ( getGradientBackgroundSet( options ) )
        {
            drawGradient( aGc, aSize );
        }
        if ( getBackgroundStarsSet( options ) )
        {
            drawStars( aGc, aSize );
        }

        if ( getDrawShadows( options ) )
        {
            drawShadows( aGc, aSize, aLevelData );
        }

        drawScoreBoardAndBat( aGc, aSize );
    }

    public void paintRestricted( Graphics2D aGc, Dimension aSize, LevelData aLevelData, Rectangle aClipRect )
    {
        aGc.setClip( aClipRect );
        paintInto( aGc, aSize, aLevelData );
    }

    public void dispose()
    {
        iTileContainer.removeListener( this );
        iTileContainer = null;
        iLayerSelection = null;
        iBatTileSet = null;
        iBackgroundTileSet = null;
        iScoreBoardTileSet = null;
        iApplication = null;
        iStars = null;
        iStarColors = null;
        iGradient = null;

        iAmDisposed = true;
    }

    // From TileProviderListener

    public void onTileProviderChanged()
    {
        File tileSetFile = iApplication.getTileSetFile();
        if ( tileSetFile == null )
        {
            return;
        }

        try
        {
            File dir = tileSetFile.getParentFile();
            iScoreBoardTileSet.load( new File( dir, "ScoreBoard.png" ) );
            iBackgroundTileSet.load( new File( dir, "BackTiles.png" ) );
            iBatTileSet.load( new File( dir, "Bat.png" ) );
        }
        catch ( IOException e )
        {
            iLog.error( "Failed loading background tiles", e );
        }
    }

    // Implementation

    private void initStars()
    {
        iStars = new Point[ KNumberOfStars ];
        iStarColors = new Color[ KNumberOfStars ];

        Random random = new Random();
        for ( int idx = 0; idx < iStars.length; idx++ )
        {
            int x = random.nextInt( KStarFieldSize );
            int y = random.nextInt( KStarFieldSize );
            iStars[ idx ] = new Point( x, y );

            int grey = idx * 256 / iStars.length;
            iStarColors[ idx ] = new Color( grey, grey, grey );
        }
    }

    private void initGradient()
    {
        iGradient = new Color[ KGradientLength ];

        int gradientStart = KGradientLength * 2 / 3;
        int darkEnd = KGradientLength * 3 / 4;

        Color black = Color.BLACK;
        Color dark = new Color( 0, 16, 64 );
        Color light = new Color( 100, 150, 220 );

        calcGradient( black, dark, gradientStart, darkEnd );
        calcGradient( dark, light, darkEnd, KGradientLength );
    }

    private void calcGradient( Color aFrom, Color aTo, int aStart, int aEnd )
    {
        int redBase = aFrom.getRed();
        int greenBase = aFrom.getGreen();
        int blueBase = aFrom.getBlue();

        int redDelta = aTo.getRed() - redBase;
        int greenDelta = aTo.getGreen() - greenBase;
        int blueDelta = aTo.getBlue() - blueBase;

        int delta = aEnd - aStart;

        for ( int y = aStart; y < aEnd; y++ )
        {
            int offset = y - aStart;
            int r = redDelta * offset / delta + redBase;
            int g = greenDelta * offset / delta + greenBase;
            int b = blueDelta * offset / delta + blueBase;
            iGradient[ y ] = new Color( r, g, b );
        }
    }

    private boolean getBackgroundColoring( LevelOptions aOptions )
    {
        return getChoosableOption( aOptions ).isSetTo( "Color" );
    }

    private boolean getBackgroundTiling( LevelOptions aOptions )
    {
        return getChoosableOption( aOptions ).isSetTo( "Tiled" );
    }

    private boolean getGradientBackgroundSet( LevelOptions aOptions )
    {
        return getChoosableOption( aOptions ).isSetTo( "Gradient" );
    }

    private LevelOption.ChoosableExtension getChoosableOption( LevelOptions aOptions )
    {
        return aOptions.getLevelOption( BreakOutLevelOptions.KBackgroundStyle ).getChoosableExtension();
    }

    private boolean getBackgroundStarsSet( LevelOptions aOptions )
    {
        return aOptions.getLevelOption( BreakOutLevelOptions.KDrawStars ).getBooleanExtension().getBooleanValue();
    }

    private boolean getDrawShadows( LevelOptions aOptions )
    {
        return aOptions.getLevelOption( BreakOutLevelOptions.KDrawShadows ).getBooleanExtension().getBooleanValue();
    }

    private void drawColoredBackground( Graphics2D aGc, Dimension aSize, LevelOptions aOptions )
    {
        LevelOption redOption = aOptions.getLevelOption( BreakOutLevelOptions.KBackgroundColorR );
        LevelOption greenOption = aOptions.getLevelOption( BreakOutLevelOptions.KBackgroundColorG );
        LevelOption blueOption = aOptions.getLevelOption( BreakOutLevelOptions.KBackgroundColorB );

        int red = redOption.getIntegerExtension().getIntegerValue();
        int green = greenOption.getIntegerExtension().getIntegerValue();
        int blue = blueOption.getIntegerExtension().getIntegerValue();

        aGc.setColor( new Color( red << 4, green << 4, blue << 4 ) );
        aGc.fillRect( 0, 0, aSize.width, aSize.height );
    }

    private void drawTiledBackground( Graphics2D aGc, Dimension aSize, LevelOptions aOptions )
    {
        if ( iBackgroundTileSet == null )
        {
            return;
        }

        LevelOption tileIndexOption = aOptions.getLevelOption( BreakOutLevelOptions.KBackgroundTileIndex );
        int tileIndex = tileIndexOption.getIntegerExtension().getIntegerValue();
        Tile tile = iBackgroundTileSet.getTile( tileIndex );

        int tileWidth = aSize.width * 64 / KPlayFieldWidth;
        int tileHeight = aSize.height * 64 / KPlayFieldHeight;
        Dimension tileSize = new Dimension( tileWidth, tileHeight );
        Point offset = new Point( 0, 0 );
        for ( int y = 0; y < aSize.height; y += tileHeight )
        {
            offset.y = y;
            for ( int x = 0; x < aSize.width; x += tileWidth )
            {
                offset.x = x;
                tile.paintSized( aGc, offset, tileSize );
            }
        }
    }

    private void drawGradient( Graphics2D aGc, Dimension aSize )
    {
        int width = aSize.width;
        int height = aSize.height;
        for ( int y = 0; y < height; y++ )
        {
            int idx = y * KGradientLength / height;
            Color gradient = iGradient[ idx ];
            if ( gradient != null )
            {
                aGc.setColor( gradient );
                aGc.drawLine( 0, y, width, y );
            }
        }
    }

    private void drawStars( Graphics2D aGc, Dimension aSize )
    {
        int width = aSize.width;
        int height = aSize.height;
        for ( int idx = 0; idx < iStars.length; idx++ )
        {
            int x1 = toScreen( iStars[ idx ].x, width );
            int y1 = toScreen( iStars[ idx ].y, height );
            int x2 = toScreen( iStars[ idx ].x + 1, width );
            int y2 = y1;

            aGc.setColor( iStarColors[ idx ] );
            aGc.drawLine( x1, y1, x2, y2 );
        }
    }

    private int toScreen( int aOrdinate, int aScreenSize )
    {
        return aOrdinate * aScreenSize / KStarFieldSize;
    }

    private void drawShadows( Graphics2D aGc, Dimension aSize, LevelData aData )
    {
        if ( iTileContainer == null )
        {
            return;
        }

        Dimension tileSize = iTileContainer.getTileSize();
        int factor = 256 * tileSize.width / tileSize.height;

        int distanceInPixels = getShadowDistance( aData.getOptions() );
        iShadowOffset.x = distanceInPixels;
        iShadowOffset.y = ( distanceInPixels << 8 ) / factor;

        iShadowOffset.x = iShadowOffset.x * aSize.width / KPlayFieldWidth;
        iShadowOffset.y = iShadowOffset.y * aSize.height / 208;

        aGc.translate( iShadowOffset.x, iShadowOffset.y );

        int width = aData.getLevelWidth();
        int height = aData.getLevelHeight();

        double tileWidth = aSize.width / width;
        double tileHeight = aSize.height / height;

        if ( tileWidth < 1 && tileHeight < 1 )
        {
            return;
        }

        int intensity = 15 - getShadowIntensity( aData.getOptions() );
        iShadowComposite.setIntensity( intensity << 4 );
        aGc.setComposite( iShadowComposite );

        int layers = iTileContainer.getNumberOfLayers();
        for ( int layer = 0; layer < layers; layer++ )
        {
            TileSet tileSet = iTileContainer.getLayerTileSet( layer );

            if ( tileSet.getNumberOfTiles() == 0 )
            {
                continue;
            }

            if ( iLayerSelection.getVisibility( layer ) == false )
            {
                continue;
            }

            boolean reducedSize = iLayerSelection.getReducedSize( layer );
            int sizePercentage = iLayerSelection.getSizePercentage( layer );

            for ( int y = 0; y < height; y++ )
            {
                for ( int x = 0; x < width; x++ )
                {
                    BlockData id = aData.getBlockData( x, y );
                    if ( tileSet.isEmpty( id ) )
                    {
                        continue;
                    }

                    Tile aTile = tileSet.getTile( id );

                    int xStart = ( int ) ( x * aSize.width / width );
                    int yStart = ( int ) ( y * aSize.height / height );
                    int xEnd = ( int ) ( ( x + 1 ) * aSize.width / width );
                    int yEnd = ( int ) ( ( y + 1 ) * aSize.height / height );

                    Point pos = new Point( xStart, yStart );
                    Dimension size = new Dimension( xEnd - xStart, yEnd - yStart );
                    if ( size.width < 1 && size.height < 1 )
                    {
                        continue;
                    }
                    if ( reducedSize == false )
                    {
                        aTile.paintSized( aGc, pos, size );
                    }
                    else
                    {
                        aTile.paintScaled( aGc, pos, size, sizePercentage );
                    }
                }
            }
        }

        drawScoreBoardAndBat( aGc, aSize );

        aGc.translate( -iShadowOffset.x, -iShadowOffset.y );
        aGc.setPaintMode();
    }

    private void drawScoreBoardAndBat( Graphics2D aGc, Dimension aSize )
    {
        if ( iScoreBoardTileSet.getNumberOfTiles() == 0 )
        {
            return;
        }

        {
            int yPos = -KScoreBoardInvisibleHeight * aSize.height / KPlayFieldHeight;
            int height = KScoreBoardHeight * aSize.height / KPlayFieldHeight;
            Point iOutside = new Point( 0, yPos );
            Dimension scoreBoardSize = new Dimension( aSize.width, height );

            Tile scoreBoard = iScoreBoardTileSet.getTile( 0 );
            scoreBoard.paintSized( aGc, iOutside, scoreBoardSize );
        }

        {
            int xPos = ( ( KPlayFieldWidth - KBatWidth ) >> 1 ) * aSize.width / KPlayFieldWidth;
            int yPos = ( KPlayFieldHeight - KBatHeight * 2 ) * aSize.height / KPlayFieldHeight;
            int width = KBatWidth * aSize.width / KPlayFieldWidth;
            int height = KBatHeight * aSize.height / KPlayFieldHeight;

            Tile bat = iBatTileSet.getTile( 0 );
            bat.paintSized( aGc, new Point( xPos, yPos ), new Dimension( width, height ) );
        }
    }

    private int getShadowDistance( LevelOptions aOptions )
    {
        return aOptions.getLevelOption( BreakOutLevelOptions.KShadowDistance ).getIntegerExtension().getIntegerValue();
    }

    private int getShadowIntensity( LevelOptions aOptions )
    {
        return aOptions.getLevelOption( BreakOutLevelOptions.KShadowIntensity ).getIntegerExtension().getIntegerValue();
    }



    private /*inner*/ class ShadowComposite implements Composite
    {
        private ShadowContext iShadowContext = new ShadowContext();



        // From Composite

        public CompositeContext createContext( ColorModel srcColorModel, ColorModel dstColorModel, RenderingHints hints )
        {
            return iShadowContext;
        }

        public void setIntensity( int aIntensity /*0..255*/ )
        {
            Assert.MAKE_SURE( aIntensity >= 0 && aIntensity < 256 );
            iShadowContext.setIntensity( aIntensity );
        }
    }



    private /*inner*/ class ShadowContext implements CompositeContext
    {
        private int iShadowIntensity = 128;



        // From CompositeContext

        public void compose( Raster src, Raster dstIn, WritableRaster dstOut )
        {
            int[] srcPixels = new int[ 4 ];
            int[] dstPixels = new int[ 4 ];
            for ( int x = 0; x < dstOut.getWidth(); x++ )
            {
                for ( int y = 0; y < dstOut.getHeight(); y++ )
                {
                    src.getPixel( x, y, srcPixels );
                    dstIn.getPixel( x, y, dstPixels );

                    if ( srcPixels[ 3 ] > 0 )
                    {
                        dstPixels[ 0 ] = ( dstPixels[ 0 ] * iShadowIntensity ) >> 8;
                        dstPixels[ 1 ] = ( dstPixels[ 1 ] * iShadowIntensity ) >> 8;
                        dstPixels[ 2 ] = ( dstPixels[ 2 ] * iShadowIntensity ) >> 8;
                        dstOut.setPixel( x, y, dstPixels );
                    }
                }
            }
        }

        public void dispose()
        {

        }

        public void setIntensity( int aIntensity )
        {
            Assert.MAKE_SURE( aIntensity >= 0 && aIntensity < 256 );
            iShadowIntensity = aIntensity;
        }
    }
}
