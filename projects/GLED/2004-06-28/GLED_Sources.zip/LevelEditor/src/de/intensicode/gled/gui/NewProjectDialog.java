/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.gui;

import de.intensicode.gled.commands.GledCommand;
import de.intensicode.gled.core.GledProject;
import de.intensicode.gled.domain.Application;
import de.intensicode.gled.util.Plugin;
import de.intensicode.gled.util.Plugins;
import de.intensicode.mui.*;

import javax.swing.JButton;
import javax.swing.JFrame;



public class NewProjectDialog extends MUIDialog
{
    private Commandable iCommandable = new ModalCommandable();

    private MUIButton iOkButton = new MUIButton( "OK" );

    private MUIButton iCancelButton = new MUIButton( "Cancel" );

    private Plugins iPlugins;

    private MUISelectGroupH iGameModes;



    public NewProjectDialog( JFrame aParentFrame, Application aApplication )
    {
        super( aParentFrame, "New Project", true );

        iPlugins = aApplication.getPlugins();

        MUIGroup controls = new MUIGroupH();
        controls.addChild( buildGameList() );

        MUIGroup contents = new MUIGroupV();
        contents.addChild( controls );
        contents.addCentered( buildCommands() );

        getRootPane().setDefaultButton( ( JButton ) iOkButton.getJava() );

        iOkButton.setActionCommand( new OkButton(), iCommandable );
        iCancelButton.setActionCommand( new CancelButton(), iCommandable );

        addChild( contents );
        centerDialog();
    }

    // Implementation

    private MUIComponent buildGameList()
    {
        iGameModes = new MUISelectGroupH();
        iGameModes.setTitle( "Game Data Mode" );

        int numberOfPlugins = iPlugins.getNumberOfPlugins();
        for ( int idx = 0; idx < numberOfPlugins; idx++ )
        {
            Plugin plugin = iPlugins.getPlugin( idx );
            MUIRadioButton gameDataMode = new MUIRadioButton( plugin.getName() );
            iGameModes.addSelectable( gameDataMode );
        }
        return iGameModes;
    }

    private MUIComponent buildCommands()
    {
        MUIGroup group = new MUIGroupH();
        group.addChild( iOkButton );
        group.addChild( iCancelButton );
        return group;
    }



    private /*inner*/ class ModalCommandable extends Commandable
    {

    }



    private /*inner*/ class OkButton extends GledCommand
    {
        public void execute() throws Throwable
        {
            hide();

            Plugin plugin = iPlugins.forName( iGameModes.getSelected() );
            iApplication.setProject( new GledProject( plugin ) );
        }
    }



    private /*inner*/ class CancelButton extends GledCommand
    {
        public void execute() throws Throwable
        {
            hide();
        }
    }
}
