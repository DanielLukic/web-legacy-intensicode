/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.intensiblast;

import de.intensicode.core.config.Configuration;
import de.intensicode.gled.domain.TileProvider;
import de.intensicode.gled.domain.TileSet;

import java.awt.Dimension;
import java.io.File;
import java.io.IOException;



public class IntensiBlastTileProvider implements TileProvider
{
    private Dimension iTileSize = new Dimension( 16, 16 );

    private IntensiBlastTileSet iBlocks;



    public IntensiBlastTileProvider( Configuration aConfiguration )
    {
        iTileSize.width = aConfiguration.getInt( "TileSet.TileWidth", iTileSize.width );
        iTileSize.height = aConfiguration.getInt( "TileSet.TileHeight", iTileSize.height );

        iBlocks = new IntensiBlastTileSet( this );
    }

    // From TileProvider

    public int getNumberOfLayers()
    {
        return 1;
    }

    public String getLayerName( int aLayerIndex )
    {
        switch ( aLayerIndex )
        {
            case 0:
                return "Blocks";
            default:
                throw new IllegalArgumentException( "Invalid layer: " + aLayerIndex );
        }
    }

    public TileSet getLayerTileSet( int aLayerIndex )
    {
        switch ( aLayerIndex )
        {
            case 0:
                return iBlocks;
            default:
                throw new IllegalArgumentException( "Invalid layer: " + aLayerIndex );
        }
    }

    public Dimension getTileSize()
    {
        return iTileSize;
    }

    public void load( File aTileSetFile ) throws IOException
    {
        iBlocks.load( aTileSetFile );
    }
}
