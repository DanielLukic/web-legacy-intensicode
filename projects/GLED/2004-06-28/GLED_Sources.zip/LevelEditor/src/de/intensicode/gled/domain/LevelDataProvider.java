/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.domain;

import java.awt.Dimension;
import java.io.File;
import java.io.IOException;



public interface LevelDataProvider
{
    void load( File aLevelDataFile ) throws IOException;

    void save( File aLevelDataFile ) throws IOException;

    int getNumberOfLevels();

    Dimension getLevelSize();

    LevelData getLevelData( int aIdx );

    void addNewLevel();

    void cloneLevel( int aSelected );

    void copyLevel( int aSourceLevel, int aDestinationLevel );

    void swapLevels( int aSourceLevel, int aDestinationLevel );

    void deleteLevel( int aLevelIndex );
}
