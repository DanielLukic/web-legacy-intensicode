/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.core;

import de.intensicode.gled.domain.*;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;



class TileSetHandlerImpl implements TileSetHandler
{
    private TileSet iTileSet;

    private ArrayList iListeners = new ArrayList();



    public TileSetHandlerImpl()
    {
        iTileSet = new TileSetDummy();
    }

    public TileSetHandlerImpl( TileSet aTileSet )
    {
        iTileSet = aTileSet;
    }

    // From TileProviderHandler

    public void addListener( TileSetListener aListener )
    {
        iListeners.add( aListener );
    }

    // From TileSet

    public void load( File aTileSetFile ) throws IOException
    {
        iTileSet.load( aTileSetFile );
        fireTileSetChanged();
    }

    public int getNumberOfTiles()
    {
        return iTileSet.getNumberOfTiles();
    }

    public int getTilesPerRow()
    {
        return iTileSet.getTilesPerRow();
    }

    public int getTilesPerColumn()
    {
        return iTileSet.getTilesPerColumn();
    }

    public Tile getTile( int aIdx )
    {
        return iTileSet.getTile( aIdx );
    }

    public Tile getTile( BlockData aBlockData )
    {
        return iTileSet.getTile( aBlockData.getTileIndex( 0 ) );
    }

    public boolean isEmpty( BlockData aBlockData )
    {
        return iTileSet.isEmpty( aBlockData );
    }

    public boolean needsAlphaBlit()
    {
        return iTileSet.needsAlphaBlit();
    }
    // Implementation

    private void fireTileSetChanged()
    {
        for ( int idx = 0; idx < iListeners.size(); idx++ )
        {
            TileSetListener listener = ( TileSetListener ) iListeners.get( idx );
            listener.onTileSetChanged();
        }
    }
}
