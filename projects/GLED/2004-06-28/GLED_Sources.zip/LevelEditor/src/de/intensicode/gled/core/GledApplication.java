/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.core;

import de.intensicode.core.config.ConfigurationException;
import de.intensicode.gled.domain.*;
import de.intensicode.gled.util.Plugins;

import java.io.File;
import java.io.IOException;



public class GledApplication implements Application
{
    private UserInterface iUserInterface;

    private Plugins iPlugins;

    private File iProjectFile;

    private Project iProject;

    private TileProviderHandlerImpl iTileContainer;

    private LevelDataContainerImpl iLevelDataContainer;

    private LayerSelectionImpl iLayerSelection;

    private TileSelection iTileSelection;

    private LevelSelectionImpl iLevelSelection;



    public GledApplication() throws ConfigurationException
    {
        iPlugins = new Plugins();

        iProject = new GledProject( iPlugins.getDefaultPlugin() );
        iTileContainer = new TileProviderHandlerImpl( iProject );
        iLevelDataContainer = new LevelDataContainerImpl( iProject );

        iLayerSelection = new LayerSelectionImpl( iTileContainer );
        iTileSelection = new TileSelectionImpl( iTileContainer );
        iLevelSelection = new LevelSelectionImpl( iLevelDataContainer );
    }

    public void setUserInterface( UserInterface aUserInterface )
    {
        iUserInterface = aUserInterface;
    }

    // From Application

    public File getProjectFile()
    {
        return iProjectFile;
    }

    public void setProjectFile( File aFile )
    {
        iProjectFile = aFile;
    }

    public void setProject( Project aNewProject )
    {
        iProject.dispose();

        iProject = aNewProject;
        iTileContainer.setProject( iProject );
        iLevelDataContainer.setProject( iProject );
    }

    public TileProviderHandler getTileContainer()
    {
        return iTileContainer;
    }

    public LevelDataContainer getLevelDataContainer()
    {
        return iLevelDataContainer;
    }

    public ProjectInfo getDataForOutput() throws IOException
    {
        return iProject.getDataForOutput();
    }

    public LayerSelection getLayerSelection()
    {
        return iLayerSelection;
    }

    public LevelSelection getLevelSelection()
    {
        return iLevelSelection;
    }

    public TileSelection getTileSelection()
    {
        return iTileSelection;
    }

    public UserInterface getUserInterface()
    {
        if ( iUserInterface == null )
        {
            throw new IllegalStateException( "No user interface set" );
        }
        return iUserInterface;
    }

    public Plugins getPlugins()
    {
        return iPlugins;
    }

    // From Project

    public SystemFactory getSystemFactory()
    {
        return iProject.getSystemFactory();
    }

    public File getTileSetFile()
    {
        return iProject.getTileSetFile();
    }

    public File getLevelDataFile()
    {
        return iProject.getLevelDataFile();
    }

    public TileProvider getTileProvider()
    {
        return iProject.getTileProvider();
    }

    public LevelDataProvider getLevelDataProvider()
    {
        return iProject.getLevelDataProvider();
    }

    public void setTileSetFile( File aTileSetFile )
    {
        iProject.setTileSetFile( aTileSetFile );
    }

    public void setTileProvider( TileProvider aTileProvider )
    {
        iProject.setTileProvider( aTileProvider );
        iTileContainer.setProject( iProject );
    }

    public void setLevelDataFile( File aLevelDataFile )
    {
        iProject.setLevelDataFile( aLevelDataFile );
    }

    public void setLevelDataProvider( LevelDataProvider aLevelProvider )
    {
        iProject.setLevelDataProvider( aLevelProvider );
        iLevelDataContainer.setProject( iProject );
    }

    public void dispose()
    {
        iProject.dispose();
    }
}
