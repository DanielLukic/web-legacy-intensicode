/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.commands;

import de.intensicode.gled.domain.LevelDataContainer;
import de.intensicode.gled.domain.LevelSelection;



public class MoveLevelToFront extends GledCommand
{
    public void execute() throws Throwable
    {
        LevelDataContainer container = iApplication.getLevelDataContainer();

        LevelSelection levelSelection = iApplication.getLevelSelection();
        if ( levelSelection.isValid() == false )
        {
            return;
        }

        int selectedLevel = levelSelection.getLevelIndex();

        levelSelection.unselect();

        if ( selectedLevel > 0 )
        {
            int newIndex = selectedLevel - 1;
            container.swapLevels( selectedLevel, newIndex );

            levelSelection.setLevelIndex( selectedLevel - 1 );
        }
    }
}
