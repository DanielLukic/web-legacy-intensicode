/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.actions;

import de.intensicode.gled.commands.NewLevelData;
import de.intensicode.mui.MUIUtils;

import java.awt.event.ActionEvent;

import javax.swing.Action;



public class NewLevelDataAction extends GledAction
{
    public NewLevelDataAction()
    {
        putValue( Action.NAME, "New Level Data" );
        putValue( Action.SHORT_DESCRIPTION, "New level data" );
        putValue( Action.SMALL_ICON, MUIUtils.getIcon( "/icons/new.png" ) );
        setEnabled( true );
    }

    // From ActionListener

    public void actionPerformed( ActionEvent aEvent )
    {
        iMainFrame.addCommand( new NewLevelData() );
    }
}
