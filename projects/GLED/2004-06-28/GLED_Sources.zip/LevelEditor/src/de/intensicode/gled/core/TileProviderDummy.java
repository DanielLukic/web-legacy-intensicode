/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.core;

import de.intensicode.gled.domain.TileProvider;
import de.intensicode.gled.domain.TileSet;

import java.awt.Dimension;
import java.io.File;
import java.io.IOException;



class TileProviderDummy implements TileProvider
{
    private Dimension iDummyTileSize = new Dimension( 16, 16 );



    public TileProviderDummy()
    {

    }

    // From TileProvider

    public int getNumberOfLayers()
    {
        return 0;
    }

    public String getLayerName( int aLayerIndex )
    {
        return "[LAYER NAME]";
    }

    public TileSet getLayerTileSet( int aLayerIndex )
    {
        return new TileSetDummy();
    }

    public Dimension getTileSize()
    {
        return iDummyTileSize;
    }

    public void load( File aTileSetFile ) throws IOException
    {

    }
}
