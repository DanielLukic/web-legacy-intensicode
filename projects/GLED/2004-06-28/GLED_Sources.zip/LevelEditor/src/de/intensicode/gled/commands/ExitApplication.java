/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.commands;



import javax.swing.JOptionPane;



public class ExitApplication extends GledCommand
{
    // From Command

    public void execute() throws Throwable
    {
        int result = JOptionPane.showConfirmDialog( iMainFrame, "Exit GLED?", "GLED Confirmation Request", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE );
        if ( result == JOptionPane.OK_OPTION )
        {
            System.exit( 0 );
        }
    }
}
