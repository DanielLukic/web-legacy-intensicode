/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.domain;

import java.io.File;
import java.io.IOException;



public interface TileSet
{
    void load( File aTileSetFile ) throws IOException;

    int getNumberOfTiles();

    int getTilesPerRow() throws IllegalStateException;

    int getTilesPerColumn() throws IllegalStateException;

    Tile getTile( int aIdx );

    Tile getTile( BlockData aBlockData );

    boolean isEmpty( BlockData aBlockData );

    boolean needsAlphaBlit();
}
