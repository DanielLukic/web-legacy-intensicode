/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.util;

import de.intensicode.gled.domain.LevelOption;
import de.intensicode.core.Assert;



/**
 *
 */
public class IntegerLevelOption extends AbstractLevelOption implements LevelOption.IntegerExtension
{
    private int iMinValue;

    private int iMaxValue;



    public IntegerLevelOption()
    {
        super( KInteger );
    }

    public void setMin( String aMinValue )
    {
        iMinValue = Integer.parseInt( aMinValue );
    }

    public void setMax( String aMaxValue )
    {
        iMaxValue = Integer.parseInt( aMaxValue );
    }

    // From LevelOption

    public String getValue()
    {
        checkValue();
        return super.getValue();
    }

    public void setValue( String aNewValue )
    {
        super.setValue( aNewValue );
        checkValue();
    }

    public LevelOption cloned()
    {
        IntegerLevelOption clone = new IntegerLevelOption();
        clone.copyFrom( this );
        clone.iMinValue = iMinValue;
        clone.iMaxValue = iMaxValue;
        return clone;
    }

    public LevelOption.IntegerExtension getIntegerExtension()
    {
        return this;
    }

    // From IntegerExtension

    public int getMinValue()
    {
        return iMinValue;
    }

    public int getMaxValue()
    {
        return iMaxValue;
    }

    public int getIntegerValue()
    {
        return Integer.parseInt( iValue );
    }

    // Implementation

    private void checkValue()
    {
        int test = Integer.parseInt( iValue );
        Assert.MAKE_SURE( test >= iMinValue && test <= iMaxValue );
    }
}
