/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.breakout;

import de.intensicode.core.config.Configuration;
import de.intensicode.core.config.ConfigurationException;
import de.intensicode.gled.domain.*;



public class BreakOutFactory implements SystemFactory
{
    private Configuration iConfiguration;

    private BreakOutBackgroundPainter iBreakOutBackgroundPainter;



    public BreakOutFactory() throws ConfigurationException
    {
        iConfiguration = new Configuration( "/BreakOut.config" );
    }

    // From SystemFactory

    public LevelDataProvider createLevelDataProvider() throws ConfigurationException
    {
        return new BreakOutLevelDataProvider( iConfiguration );
    }

    public TileProvider createTileProvider()
    {
        return new BreakOutTileProvider( iConfiguration );
    }

    public BackgroundPainter createBackgroundPainter( Application aApplication )
    {
        if ( iBreakOutBackgroundPainter == null )
        {
            iBreakOutBackgroundPainter = new BreakOutBackgroundPainter( aApplication );
        }
        return iBreakOutBackgroundPainter;
    }

    public void dispose()
    {
        iConfiguration.clear();
        iConfiguration = null;

        iBreakOutBackgroundPainter.dispose();
        iBreakOutBackgroundPainter = null;
    }
}
