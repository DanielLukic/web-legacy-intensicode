/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.commands;

import de.intensicode.core.config.ConfigurationException;
import de.intensicode.gled.domain.LevelDataProvider;
import de.intensicode.gled.domain.Project;

import java.io.File;



public class LoadLevelData extends GledCommand
{
    private Project iProject;

    private File iLevelDataFile;



    public LoadLevelData( Project aProject, File aLevelDataFile )
    {
        iProject = aProject;
        iLevelDataFile = aLevelDataFile;
    }

    // From Command

    public void execute() throws ConfigurationException
    {
        iUserInterface.showStatus( "Loading level data" );
        try
        {
            LevelDataProvider provider = iProject.getSystemFactory().createLevelDataProvider();
            provider.load( iLevelDataFile );

            iProject.setLevelDataProvider( provider );
            iProject.setLevelDataFile( iLevelDataFile );

            iUserInterface.showStatus( "Level data loaded" );
            iCommandable.execute( new ShowStatusMessage( "Level data loaded from " + iLevelDataFile ) );
        }
        catch ( Throwable t )
        {
            iUserInterface.showStatus( "Failed loading level data" );
            iCommandable.execute( new ShowErrorMessage( "Failed loading level data", t ) );
        }
    }
}
