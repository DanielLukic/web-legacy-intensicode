/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.domain;



public interface LevelData
{
    LevelOptions getOptions();

    int getLevelWidth();

    int getLevelHeight();

    BlockData getBlockData( int aX, int aY );

    void fillLevel( TileSelection aTileSelection );

    void scrollData( int aDeltaX, int aDeltaY );
}
