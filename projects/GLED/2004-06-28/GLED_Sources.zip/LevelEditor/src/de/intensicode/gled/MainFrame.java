/************************************************************************/
/* GLED                 www.intensicode.de                December 2003 */
/************************************************************************/

package de.intensicode.gled;

import de.intensicode.core.config.ConfigurationException;
import de.intensicode.core.logging.Log;
import de.intensicode.gled.actions.GledAction;
import de.intensicode.gled.commands.GledCommand;
import de.intensicode.gled.commands.NewProject;
import de.intensicode.gled.constraints.*;
import de.intensicode.gled.core.GledApplication;
import de.intensicode.gled.core.GledPreferences;
import de.intensicode.gled.domain.LevelDataContainer;
import de.intensicode.gled.domain.TileProviderHandler;
import de.intensicode.gled.domain.UserInterface;
import de.intensicode.gled.gui.*;
import de.intensicode.mui.*;

import java.awt.Dimension;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;



public class MainFrame extends Commandable implements UserInterface, ComponentListener
{
    private static Log iLog = Log.getLog( "MainFrame" );

    private GledPreferences iPreferences;

    private GledApplication iApplication;

    private MUIFrame iFrame;

    private MUIStatus iStatus;

    private MUIToolbar iToolBar;

    private LevelSelectorView iLevelSelector;

    private LayerSelectionView iLayerSelection;

    private LevelEditorView iLevelEditor;

    private TileSelectionView iTileSelection;

    private TileChooserView iTileChooser;

    private LevelOptionsView iLevelOptions;

    private MUIGroup iStatusPane;

    private LevelSorter iLevelSorter;

    private MUIImageButton iShowButton;

    private MUIImageButton iHideButton;

    private StatusMessageComponent iStatusMessage = new StatusMessageComponent();



    public MainFrame( GledApplication aApplication ) throws ConfigurationException
    {
        iLog.info( "Creating main frame" );

        iPreferences = GledPreferences.getInstance();
        iApplication = aApplication;

        iApplication.setUserInterface( this );

        iFrame = new MUIFrame( "GLED - www.intensicode.de" );
        iFrame.addComponentListener( this );

        iStatus = new MUIStatus();

        GledAction.init( iApplication, this );
        GledCommand.init( iApplication, this );
        GledCommand.setMainFrame( iFrame );
        GledCommand.setStatusLog( iStatus );
        GledCommand.setUserInterface( this );

        MUIGroup editing = new MUIGroupH();
        editing.getConstraints().clearInsets();
        editing.addChild( buildLevelEditor() );
        editing.addChild( buildTileChooser() );

//        MUIGroup editingWithOptions = new MUIGroupV();
//        editingWithOptions.getConstraints().clearInsets();
//        editingWithOptions.addChild( editing );
//        editingWithOptions.addChild( buildLevelOptions() );

        MUISplitterV editingWithOptions = new MUISplitterV();
        editingWithOptions.setFirst( editing );
        editingWithOptions.setSecond( buildLevelOptions() );

        MUIGroup contents = new MUIGroupH();
        contents.getConstraints().clearInsets();
        contents.addChild( buildLevelList() );
        contents.addChild( editingWithOptions );

        iHideButton = new MUIImageButton( GledAction.getAction( "HideStatusPane" ) );
        iHideButton.getConstraints().iStretchToFitV = false;
        iHideButton.getConstraints().iWeightV = 0;
        iHideButton.setVisible( true );

        iShowButton = new MUIImageButton( GledAction.getAction( "ShowStatusPane" ) );
        iShowButton.getConstraints().iStretchToFitV = false;
        iShowButton.getConstraints().iWeightV = 0;
        iShowButton.setVisible( false );

        MUIGroup toolbar = new MUIGroupH();
        toolbar.addChild( buildToolBar() );
        toolbar.addChild( new MUISpacerH() );
        toolbar.addChild( iStatusMessage );
        toolbar.addChild( new MUISpacerH() );
        toolbar.addChild( iHideButton );
        toolbar.addChild( iShowButton );

        MUIGroup statusArea = new MUIGroupH();
        statusArea.setTitle( "Status Log" );
        statusArea.addChild( iStatus );

        iStatusPane = new MUIGroupH();
        iStatusPane.getConstraints().clearInsets();
        iStatusPane.addChild( statusArea );
        iStatusPane.addChild( new MUIImageLabel( "/images/Logo Small.png" ) );

        MUIGroup main = new MUIGroupV();
        main.getConstraints().clearInsets();
        main.addChild( toolbar );
        main.addChild( contents );
        main.addChild( iStatusPane );
        iFrame.addChild( main );

        iFrame.setMenu( buildMenu() );

        restoreFramePosition();

        iLevelSorter = new LevelSorter( iFrame, iApplication );

        hideStatusPane();
        initConstraints();

        iFrame.show();
    }

    public TileChooserView getTileChooser()
    {
        return iTileChooser;
    }

    public LevelEditorView getLevelEditor()
    {
        return iLevelEditor;
    }

    public LevelSelectorView getLevelSelector()
    {
        return iLevelSelector;
    }

    public LevelSorter getLevelSorter()
    {
        return iLevelSorter;
    }

    public void hideStatusPane()
    {
        iStatusPane.setVisible( false );
        iHideButton.setVisible( false );
        iShowButton.setVisible( true );
    }

    public void showStatusPane()
    {
        iShowButton.setVisible( false );
        iHideButton.setVisible( true );
        iStatusPane.setVisible( true );
    }

    public MUIFrame getFrame()
    {
        return iFrame;
    }

    // From UserInterface

    public void updateData()
    {
        iLevelOptions.updateLevelOptions();
    }

    public void showStatus( String aStatusMessage )
    {
        iStatusMessage.showStatus( aStatusMessage );
    }

    // From ComponentListener

    public void componentShown( ComponentEvent aEvent )
    {

    }

    public void componentResized( ComponentEvent aEvent )
    {
        if ( iFrame.isShowing() )
        {
            Rectangle bounds = iFrame.getBounds();
            Point position = new Point( bounds.x, bounds.y );
            iPreferences.setFrameShape( position, bounds.getSize() );
        }
    }

    public void componentMoved( ComponentEvent aEvent )
    {
        if ( iFrame.isShowing() )
        {
            Rectangle bounds = iFrame.getBounds();
            Point position = new Point( bounds.x, bounds.y );
            iPreferences.setFrameShape( position, bounds.getSize() );
        }
    }

    public void componentHidden( ComponentEvent aEvent )
    {

    }

    // Implementation

    private MUIMenu buildMenu() throws ConfigurationException
    {
        MUISubMenu project = new MUISubMenu( "Project" );
        project.addChild( new MUIMenuTextEntry( GledAction.getAction( "NewProject" ) ) );
        project.addChild( new MUIMenuSeparator() );
        project.addChild( new MUIMenuTextEntry( GledAction.getAction( "OpenProject" ) ) );
        project.addChild( new MUIMenuTextEntry( GledAction.getAction( "SaveProject" ) ) );
        project.addChild( new MUIMenuTextEntry( GledAction.getAction( "SaveProjectAs" ) ) );
        project.addChild( new MUIMenuSeparator() );
        project.addChild( new MUIMenuTextEntry( GledAction.getAction( "ExitApplication" ) ) );

        MUISubMenu edit = new MUISubMenu( "Edit" );
        edit.addChild( new MUIMenuTextEntry( GledAction.getAction( "UndoLastChange" ) ) );
        project.addChild( new MUIMenuSeparator() );
        edit.addChild( new MUIMenuTextEntry( GledAction.getAction( "ScrollLevelUp" ) ) );
        edit.addChild( new MUIMenuTextEntry( GledAction.getAction( "ScrollLevelDown" ) ) );
        edit.addChild( new MUIMenuTextEntry( GledAction.getAction( "ScrollLevelLeft" ) ) );
        edit.addChild( new MUIMenuTextEntry( GledAction.getAction( "ScrollLevelRight" ) ) );
        project.addChild( new MUIMenuSeparator() );
        edit.addChild( new MUIMenuTextEntry( GledAction.getAction( "FillLevel" ) ) );

        MUISubMenu view = new MUISubMenu( "View" );
        view.addChild( new MUIMenuTextEntry( GledAction.getAction( "ShowLevelNames" ) ) );
        view.addChild( new MUIMenuSeparator() );
        view.addChild( new MUIMenuTextEntry( GledAction.getAction( "ZoomAsNeeded" ) ) );
        view.addChild( new MUIMenuTextEntry( GledAction.getAction( "ZoomOriginalSize" ) ) );

        MUISubMenu levelData = new MUISubMenu( "Level Data" );
        levelData.addChild( new MUIMenuTextEntry( GledAction.getAction( "NewLevelData" ) ) );
        levelData.addChild( new MUIMenuSeparator() );
        levelData.addChild( new MUIMenuTextEntry( GledAction.getAction( "OpenLevelData" ) ) );
        levelData.addChild( new MUIMenuTextEntry( GledAction.getAction( "SaveLevelData" ) ) );
        levelData.addChild( new MUIMenuTextEntry( GledAction.getAction( "SaveLevelDataAs" ) ) );
        levelData.addChild( new MUIMenuSeparator() );
        levelData.addChild( new MUIMenuTextEntry( GledAction.getAction( "AddNewLevel" ) ) );
        levelData.addChild( new MUIMenuTextEntry( GledAction.getAction( "DeleteCurrentLevel" ) ) );
        levelData.addChild( new MUIMenuTextEntry( GledAction.getAction( "MoveLevelToFront" ) ) );
        levelData.addChild( new MUIMenuTextEntry( GledAction.getAction( "MoveLevelToBack" ) ) );
        levelData.addChild( new MUIMenuTextEntry( GledAction.getAction( "ShowLevelSorter" ) ) );

        MUISubMenu tileSet = new MUISubMenu( "Tile Set" );
        tileSet.addChild( new MUIMenuTextEntry( GledAction.getAction( "OpenTileSet" ) ) );
        tileSet.addChild( new MUIMenuTextEntry( GledAction.getAction( "ReloadTileSet" ) ) );
        tileSet.addChild( new MUIMenuSeparator() );
        tileSet.addChild( new MUIMenuTextEntry( GledAction.getAction( "SelectPreviousTile" ) ) );
        tileSet.addChild( new MUIMenuTextEntry( GledAction.getAction( "SelectNextTile" ) ) );
        tileSet.addChild( new MUIMenuTextEntry( GledAction.getAction( "SelectPreviousTileRow" ) ) );
        tileSet.addChild( new MUIMenuTextEntry( GledAction.getAction( "SelectNextTileRow" ) ) );

        MUIMenu menu = new MUIMenu();
        menu.addChild( project );
        menu.addChild( edit );
        menu.addChild( view );
        menu.addChild( levelData );
        menu.addChild( tileSet );
        return menu;
    }

    private MUIComponent buildToolBar() throws ConfigurationException
    {
        iToolBar = new MUIToolbarH();
        iToolBar.addChild( new MUIImageButton( GledAction.getAction( "ExitApplication" ) ) );
        iToolBar.addChild( new MUISeparatorV() );
        iToolBar.addChild( new MUILabel( "Project" ) );
        iToolBar.addChild( new MUIImageButton( GledAction.getAction( "NewProject" ) ) );
        iToolBar.addChild( new MUIImageButton( GledAction.getAction( "OpenProject" ) ) );
        iToolBar.addChild( new MUIImageButton( GledAction.getAction( "SaveProject" ) ) );
        iToolBar.addChild( new MUIImageButton( GledAction.getAction( "SaveProjectAs" ) ) );
        iToolBar.addChild( new MUISeparatorV() );
        iToolBar.addChild( new MUILabel( "Level Data" ) );
        iToolBar.addChild( new MUIImageButton( GledAction.getAction( "NewLevelData" ) ) );
        iToolBar.addChild( new MUIImageButton( GledAction.getAction( "OpenLevelData" ) ) );
        iToolBar.addChild( new MUIImageButton( GledAction.getAction( "SaveLevelData" ) ) );
        iToolBar.addChild( new MUIImageButton( GledAction.getAction( "SaveLevelDataAs" ) ) );
        iToolBar.addChild( new MUISeparatorV() );
        iToolBar.addChild( new MUILabel( "Tile Set" ) );
        iToolBar.addChild( new MUIImageButton( GledAction.getAction( "OpenTileSet" ) ) );
        iToolBar.addChild( new MUIImageButton( GledAction.getAction( "ReloadTileSet" ) ) );
        return iToolBar;
    }

    private MUIComponent buildLevelList() throws ConfigurationException
    {
        iLevelSelector = new LevelSelectorView( iApplication );

        MUIGroup commands1 = new MUIGroupH();
        commands1.getConstraints().clearInsets();
        commands1.addChild( new MUIImageButton( GledAction.getAction( "AddNewLevel" ) ) );
        commands1.addChild( new MUIImageButton( GledAction.getAction( "CloneCurrentLevel" ) ) );
        commands1.addChild( new MUIImageButton( GledAction.getAction( "DeleteCurrentLevel" ) ) );
        commands1.addChild( new MUIImageButton( GledAction.getAction( "ShowLevelNames" ) ) );

        MUIGroup commands2 = new MUIGroupH();
        commands2.getConstraints().clearInsets();
        commands2.addChild( new MUIImageButton( GledAction.getAction( "MoveLevelToFront" ) ) );
        commands2.addChild( new MUIImageButton( GledAction.getAction( "MoveLevelToBack" ) ) );
        commands2.addChild( new MUIImageButton( GledAction.getAction( "ShowLevelSorter" ) ) );

        MUIScrollView scrollView = new MUIScrollView( iLevelSelector );
        scrollView.setScrollDirections( false, true );

        MUIGroup group = new MUIGroupV();
        group.getConstraints().clearInsets();
        group.getConstraints().iWeightH = 0.0;
        group.setTitle( "Level Selector" );
        group.addChild( scrollView );
        group.addChild( commands1 );
        group.addChild( commands2 );
        return group;
    }

    private MUIComponent buildLevelEditor() throws ConfigurationException
    {
        iLayerSelection = new LayerSelectionView( iApplication );
        iLevelEditor = new LevelEditorView( iApplication );
        iTileSelection = new TileSelectionView( iApplication );

        MUIToolbar tools = new MUIToolbarH();
        tools.addChild( new MUIImageButton( GledAction.getAction( "UndoLastChange" ) ) );
        tools.addChild( new MUISeparatorH() );
        tools.addChild( new MUIImageButton( GledAction.getAction( "ScrollLevelUp" ) ) );
        tools.addChild( new MUIImageButton( GledAction.getAction( "ScrollLevelDown" ) ) );
        tools.addChild( new MUIImageButton( GledAction.getAction( "ScrollLevelLeft" ) ) );
        tools.addChild( new MUIImageButton( GledAction.getAction( "ScrollLevelRight" ) ) );
        tools.addChild( new MUISeparatorH() );
        tools.addChild( new MUIImageButton( GledAction.getAction( "FillLevel" ) ) );
//        tools.addChild( new MUIImageButton( GledAction.getAction( "FillRectangle" ) ) );
//        tools.addChild( new MUISeparatorH() );
//        tools.addChild( new MUIImageButton( GledAction.getAction( "ZoomAsNeeded" ) ) );
//        tools.addChild( new MUIImageButton( GledAction.getAction( "ZoomOriginalSize" ) ) );
        tools.addChild( new MUISpacerH() );

        MUIGroup group = new MUIGroupV();
        group.setToolTipText( "Left mouse button to draw (using currently selected tile)\nRight mouse button to select the tile under cursor as new drawing tile" );
        group.getConstraints().clearInsets();
        group.setTitle( "Level Editor" );
        group.addChild( iLayerSelection );
        group.addChild( iLevelEditor );
        group.addChild( tools );
        return group;
    }

    private MUIComponent buildTileChooser() throws ConfigurationException
    {
        iTileChooser = new TileChooserView( iApplication );

        MUIToolbar tools = new MUIToolbarH();
        tools.addChild( iTileSelection );
        tools.addChild( new MUISeparatorH() );
        tools.addChild( new MUIImageButton( GledAction.getAction( "SelectPreviousTile" ) ) );
        tools.addChild( new MUIImageButton( GledAction.getAction( "SelectNextTile" ) ) );
        tools.addChild( new MUIImageButton( GledAction.getAction( "SelectPreviousTileRow" ) ) );
        tools.addChild( new MUIImageButton( GledAction.getAction( "SelectNextTileRow" ) ) );
        tools.addChild( new MUISeparatorH() );
        tools.addChild( new MUIImageButton( GledAction.getAction( "ReloadTileSet" ) ) );
        tools.addChild( new MUISpacerH() );

        MUIGroup group = new MUIGroupV();
        group.getConstraints().clearInsets();
        group.setTitle( "Tile Chooser" );
        group.addChild( iTileChooser );
        group.addChild( tools );
        return group;
    }

    private MUIComponent buildLevelOptions()
    {
        iLevelOptions = new LevelOptionsView( iApplication, this );

        MUIGroup group = new MUIGroupH();
        group.getConstraints().clearInsets();
        group.getConstraints().setWeights( 1.0, 0.4 );
        group.setTitle( "Level Options" );
        group.addChild( iLevelOptions );
        return group;
    }

    private void restoreFramePosition()
    {
        Point position = iPreferences.getFramePosition();
        Dimension size = iPreferences.getFrameSize();

        if ( position.x == -1 || position.y == -1 )
        {
            iFrame.recenterWithPercentage( 80 );
        }
        else
        {
            iFrame.setLocation( position );
            iFrame.setSize( size.width, size.height );
        }
    }

    private void initConstraints() throws ConfigurationException
    {
        LevelDataContainer levelDataContainer = iApplication.getLevelDataContainer();
        TileProviderHandler tileContainer = iApplication.getTileContainer();

        GledConstraint ifLevelDataAvailable = new IfLevelDataAvailableConstraint( levelDataContainer );
        ifLevelDataAvailable.addTargetAction( GledAction.getAction( "SaveLevelData" ) );
        ifLevelDataAvailable.addTargetAction( GledAction.getAction( "SaveLevelDataAs" ) );

        GledConstraint ifTileSetLoaded = new IfTileSetLoadedConstraint( tileContainer );
        ifTileSetLoaded.addTargetAction( GledAction.getAction( "SelectPreviousTile" ) );
        ifTileSetLoaded.addTargetAction( GledAction.getAction( "SelectNextTile" ) );
        ifTileSetLoaded.addTargetAction( GledAction.getAction( "SelectPreviousTileRow" ) );
        ifTileSetLoaded.addTargetAction( GledAction.getAction( "SelectNextTileRow" ) );
        ifTileSetLoaded.addTargetAction( GledAction.getAction( "ReloadTileSet" ) );

        GledConstraint ifLevelSelected = new IfLevelSelectedConstraint( iApplication );
        ifLevelSelected.addTargetAction( GledAction.getAction( "UndoLastChange" ) );
        ifLevelSelected.addTargetAction( GledAction.getAction( "ZoomAsNeeded" ) );
        ifLevelSelected.addTargetAction( GledAction.getAction( "ZoomOriginalSize" ) );
        ifLevelSelected.addTargetAction( GledAction.getAction( "CloneCurrentLevel" ) );
        ifLevelSelected.addTargetAction( GledAction.getAction( "DeleteCurrentLevel" ) );
        ifLevelSelected.addTargetAction( GledAction.getAction( "MoveLevelToFront" ) );
        ifLevelSelected.addTargetAction( GledAction.getAction( "MoveLevelToBack" ) );
        ifLevelSelected.addTargetAction( GledAction.getAction( "ScrollLevelUp" ) );
        ifLevelSelected.addTargetAction( GledAction.getAction( "ScrollLevelDown" ) );
        ifLevelSelected.addTargetAction( GledAction.getAction( "ScrollLevelLeft" ) );
        ifLevelSelected.addTargetAction( GledAction.getAction( "ScrollLevelRight" ) );

        GledConstraint ifLevelAndTileSelected = new IfLevelAndTileSelectedConstraint( iApplication );
        ifLevelAndTileSelected.addTargetAction( GledAction.getAction( "FillLevel" ) );
    }
}
