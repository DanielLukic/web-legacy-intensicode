/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.util;

import de.intensicode.gled.domain.LevelOption;



/**
 *
 */
public class StringLevelOption extends AbstractLevelOption implements LevelOption.StringExtension
{
    int iMaxLength;



    public StringLevelOption()
    {
        super( KString );
    }

    public void setMaxLength( String aMaxLength )
    {
        iMaxLength = Integer.parseInt( aMaxLength );
    }

    // From LevelOption

    public void setValue( String aNewValue )
    {
        String value = ( String ) aNewValue;
        if ( value.length() > iMaxLength )
        {
            value = value.substring( 0, iMaxLength );
        }
        super.setValue( value );
    }

    public LevelOption cloned()
    {
        StringLevelOption clone = new StringLevelOption();
        clone.copyFrom( this );
        clone.iMaxLength = iMaxLength;
        return clone;
    }

    public LevelOption.StringExtension getStringExtension()
    {
        return this;
    }

    // From StringExtension

    public int getMaxLength()
    {
        return iMaxLength;
    }

    public String getStringValue()
    {
        return iValue;
    }
}
