/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.core;

import de.intensicode.gled.domain.LayerSelection;
import de.intensicode.gled.domain.LayerSelectionListener;
import de.intensicode.gled.domain.TileProviderListener;
import de.intensicode.gled.domain.TileProviderHandler;

import java.util.ArrayList;



public class LayerSelectionImpl implements LayerSelection, TileProviderListener
{
    private TileProviderHandler iTileContainer;

    private int iNumberOfLayers;

    private boolean[] iVisibility;

    private boolean[] iReducedSize;

    private int[] iSizePercentages;

    private boolean[] iTransparency;

    private int[] iTransparencyPercentages;

    private ArrayList iListeners = new ArrayList();



    public LayerSelectionImpl( TileProviderHandler aTileContainer )
    {
        iTileContainer = aTileContainer;
        iTileContainer.addListener( this );

        onTileProviderChanged();
    }

    // From LayerSelection

    public void addListener( LayerSelectionListener aLayerSelectionListener )
    {
        iListeners.add( aLayerSelectionListener );
    }

    public boolean getVisibility( int aIdx )
    {
        return iVisibility[ aIdx ];
    }

    public boolean getReducedSize( int aIdx )
    {
        return iReducedSize[ aIdx ];
    }

    public int getSizePercentage( int aIdx )
    {
        return iSizePercentages[ aIdx ];
    }

    public boolean getTransparency( int aIdx )
    {
        return iTransparency[ aIdx ];
    }

    public int getTransparencyPercentage( int aIdx )
    {
        return iTransparencyPercentages[ aIdx ];
    }

    public void setVisibility( int aIdx, boolean aSelected )
    {
        iVisibility[ aIdx ] = aSelected;
        fireLayerSelectionChanged();
    }

    public void setReducedSize( int aIdx, boolean aSelected )
    {
        iReducedSize[ aIdx ] = aSelected;
        fireLayerSelectionChanged();
    }

    public void setSizePercentage( int aIndex, int aValue )
    {
        iSizePercentages[ aIndex ] = aValue;
    }

    public void setTransparency( int aIdx, boolean aSelected )
    {
        iTransparency[ aIdx ] = aSelected;
        fireLayerSelectionChanged();
    }

    public void setTransparencyPercentage( int aIndex, int aValue )
    {
        iTransparencyPercentages[ aIndex ] = aValue;
    }

    // From TileProviderListener

    public void onTileProviderChanged()
    {
        if ( iNumberOfLayers != iTileContainer.getNumberOfLayers() )
        {
            iNumberOfLayers = iTileContainer.getNumberOfLayers();
            iVisibility = new boolean[ iNumberOfLayers ];
            iReducedSize = new boolean[ iNumberOfLayers ];
            iSizePercentages = new int[ iNumberOfLayers ];
            iTransparency = new boolean[ iNumberOfLayers ];
            iTransparencyPercentages = new int[ iNumberOfLayers ];

            for ( int idx = 0; idx < iNumberOfLayers; idx++ )
            {
                iVisibility[ idx ] = true;
                iReducedSize[ idx ] = idx > 0;
                iSizePercentages[ idx ] = 75;
                iTransparency[ idx ] = false;
                iTransparencyPercentages[ idx ] = 50;
            }
        }
    }

    // Implementation

    private void fireLayerSelectionChanged()
    {
        for ( int idx = 0; idx < iListeners.size(); idx++ )
        {
            LayerSelectionListener listener = ( LayerSelectionListener ) iListeners.get( idx );
            listener.onLayerSelectionChanged( this );
        }
    }
}
