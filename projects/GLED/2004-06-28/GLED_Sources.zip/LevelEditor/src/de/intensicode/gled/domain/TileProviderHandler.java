/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.domain;

import de.intensicode.gled.breakout.BreakOutBackgroundPainter;



public interface TileProviderHandler extends TileProvider
{
    void addListener( TileProviderListener aListener );

    void removeListener( TileProviderListener aListener );

    TileSetHandler getLayerTileSetHandler( int aLayerIndex );
}
