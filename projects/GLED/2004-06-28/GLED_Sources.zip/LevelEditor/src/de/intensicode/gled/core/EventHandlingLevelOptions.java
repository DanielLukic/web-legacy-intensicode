/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.core;

import de.intensicode.gled.domain.LevelOptions;
import de.intensicode.gled.domain.LevelOption;



/**
 *
 */
class EventHandlingLevelOptions implements LevelOptions
{
    private LevelOptions iLevelOptions;

    private int iLevelIndex;

    private LevelDataContainerImpl iContainer;



    public EventHandlingLevelOptions( LevelDataContainerImpl aContainer, LevelOptions aLevelOptions, int aLevelIndex )
    {
        iContainer = aContainer;
        iLevelOptions = aLevelOptions;
        iLevelIndex = aLevelIndex;
    }

    // From LevelOptions

    public String getLevelName()
    {
        return iLevelOptions.getLevelName();
    }

    public int getNumberOfOptions()
    {
        return iLevelOptions.getNumberOfOptions();
    }

    public LevelOption getLevelOption( int aIndex )
    {
        return new EventHandlingLevelOption( iContainer, iLevelOptions.getLevelOption( aIndex ), iLevelIndex );
    }

    public LevelOption getLevelOption( String aName )
    {
        return new EventHandlingLevelOption( iContainer, iLevelOptions.getLevelOption( aName ), iLevelIndex );
    }
}
