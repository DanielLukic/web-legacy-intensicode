/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.intensiblast;

import de.intensicode.core.config.Configuration;
import de.intensicode.core.config.ConfigurationException;
import de.intensicode.gled.domain.*;
import de.intensicode.gled.util.DefaultBackgroundPainter;



public class IntensiBlastFactory implements SystemFactory
{
    private Configuration iConfiguration;

    private DefaultBackgroundPainter iDefaultBackgroundPainter;



    public IntensiBlastFactory() throws ConfigurationException
    {
        iConfiguration = new Configuration( "/IntensiBlast.config" );
    }

    // From SystemFactory

    public LevelDataProvider createLevelDataProvider() throws ConfigurationException
    {
        return new IntensiBlastLevelDataProvider( iConfiguration );
    }

    public TileProvider createTileProvider()
    {
        return new IntensiBlastTileProvider( iConfiguration );
    }

    public BackgroundPainter createBackgroundPainter( Application aApplication )
    {
        if ( iDefaultBackgroundPainter == null )
        {
            iDefaultBackgroundPainter = new DefaultBackgroundPainter();
        }
        return iDefaultBackgroundPainter;
    }

    public void dispose()
    {
        iConfiguration.clear();
        iConfiguration = null;
        iDefaultBackgroundPainter = null;
    }
}
