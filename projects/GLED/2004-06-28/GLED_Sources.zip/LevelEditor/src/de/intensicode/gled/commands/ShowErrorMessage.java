/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.commands;

import javax.swing.JOptionPane;



public class ShowErrorMessage extends GledCommand
{
    private String iDescription;

    private Throwable iCause;



    public ShowErrorMessage( String aMessage )
    {
        iDescription = aMessage;
    }

    public ShowErrorMessage( String aDescription, Throwable aCause )
    {
        iDescription = aDescription;
        iCause = aCause;
    }

    // From Command

    public void execute() throws Throwable
    {
        StringBuffer message = new StringBuffer( iDescription );
        if ( iCause != null )
        {
            message.append( " (" );
            message.append( iCause );
            message.append( ")" );
        }
        iStatusLog.showError( message.toString(), iCause );
        JOptionPane.showConfirmDialog( iMainFrame, iDescription, "GLED Error Message", JOptionPane.DEFAULT_OPTION, JOptionPane.ERROR_MESSAGE );
    }
}
