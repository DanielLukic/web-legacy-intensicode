/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.actions;

import de.intensicode.mui.MUIUtils;

import java.awt.event.ActionEvent;

import javax.swing.Action;



public class HideStatusPaneAction extends GledAction
{
    public HideStatusPaneAction()
    {
        putValue( Action.NAME, "Hide status pane" );
        putValue( Action.SHORT_DESCRIPTION, "Hide status pane" );
        putValue( Action.SMALL_ICON, MUIUtils.getIcon( "/icons/hide.png" ) );
        setEnabled( true );
    }

    // From ActionListener

    public void actionPerformed( ActionEvent e )
    {
        iMainFrame.hideStatusPane();
    }
}
