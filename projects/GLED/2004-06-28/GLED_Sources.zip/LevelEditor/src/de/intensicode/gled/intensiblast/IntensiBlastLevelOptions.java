/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.intensiblast;

import de.intensicode.gled.util.IntensiCodeLevelOptions;
import de.intensicode.symbian.Mem;
import de.intensicode.symbian.TDes8;



/**
 *
 */
class IntensiBlastLevelOptions extends IntensiCodeLevelOptions
{
    private IntensiBlastLevelDataProvider iContainer;

    private int iLevelNumber;

    private String iLevelName;

    static final String KTagLine1 = new String( "Tagline 1" );

    static final String KTagLine2 = new String( "Tagline 2" );

    static final String KBaseSkinIndex = new String( "Base Skin Index" );



    public IntensiBlastLevelOptions( IntensiBlastLevelDataProvider aContainer, int aLevelNumber )
    {
        super( aContainer.getLevelOptions() );

        iContainer = aContainer;
        iLevelNumber = aLevelNumber;
        iLevelName = Integer.toString( iLevelNumber );
    }

    public void setLevelNumber( int aIndex )
    {
        iLevelNumber = aIndex;
        iLevelName = Integer.toString( aIndex );
    }

    public void load( TDes8 aLevelData )
    {
        loadOptions( aLevelData );
        loadTagLines( aLevelData );
    }

    public void save( TDes8 aLevelData )
    {
        saveTagLines( aLevelData );
        saveOptions( aLevelData );
    }

    public int getBaseSkinIndex()
    {
        return iOptions.getOption( KBaseSkinIndex ).getIntegerExtension().getIntegerValue();
    }

    // From LevelOptions

    public String getLevelName()
    {
        return iLevelName;
    }

    // From IntensiCodeLevelOptions

    protected void onUnknownOptionTag( int aCode )
    {
        switch ( aCode )
        {
            case '0':
            case '1':
            case '2':
            case '3':
                int baseSkinIndex = aCode - '0';
                iOptions.getOption( KBaseSkinIndex ).setValue( Integer.toString( baseSkinIndex ) );
                break;

            default:
                super.onUnknownOptionTag( aCode );
                break;
        }
    }

    // Implementation

    private void loadOptions( TDes8 aLevelData )
    {
        iOptions.resetToDefaults();

        readOptions( aLevelData.mid( iContainer.iDataBytesPerLine * 4, iContainer.iDataBytesPerLine - iContainer.iCharsAtEOL ) );
    }

    private void saveOptions( TDes8 aLevelData )
    {
        int numberOfOptions = iOptions.getNumberOfOptions();

        TDes8 options = aLevelData.mid( iContainer.iDataBytesPerLine * 4, iContainer.iDataBytesPerLine - iContainer.iCharsAtEOL );
        Mem.Fill( options, options.length(), ( byte ) ' ' );
        writeOptions( options, 0, numberOfOptions );
    }

    private void loadTagLines( TDes8 aLevelData )
    {
        loadTagLine( KTagLine1, aLevelData, iContainer.iDataBytesPerLine * 1 );
        loadTagLine( KTagLine2, aLevelData, iContainer.iDataBytesPerLine * 2 );
    }

    private void saveTagLines( TDes8 aLevelData )
    {
        saveTagLine( KTagLine1, aLevelData, iContainer.iDataBytesPerLine * 1, iContainer.iLevelTagLineLength );
        saveTagLine( KTagLine2, aLevelData, iContainer.iDataBytesPerLine * 2, iContainer.iLevelTagLineLength );
    }
}
