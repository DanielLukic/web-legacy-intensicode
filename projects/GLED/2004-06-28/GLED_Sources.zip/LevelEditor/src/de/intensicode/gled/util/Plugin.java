/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.util;

import de.intensicode.gled.domain.SystemFactory;
import de.intensicode.core.config.ConfigurationException;

import java.io.Serializable;

import javax.swing.filechooser.FileFilter;



/**
 *
 */
public interface Plugin extends Serializable
{
    String getName();

    SystemFactory getSystemFactory() throws ConfigurationException;
}
