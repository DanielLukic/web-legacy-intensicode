/************************************************************************/
/* GLED                 www.intensicode.de                December 2003 */
/************************************************************************/

package de.intensicode.gled.gui;

import de.intensicode.gled.core.GledApplication;
import de.intensicode.gled.domain.TileProviderHandler;
import de.intensicode.gled.domain.TileProviderListener;
import de.intensicode.gled.domain.LayerSelection;
import de.intensicode.gled.domain.LayerSelectionListener;
import de.intensicode.mui.*;

import java.util.ArrayList;
import java.awt.event.ActionEvent;



public class LayerSelectionView extends MUIGroupV implements TileProviderListener, LayerSelectionListener
{
    private TileProviderHandler iTileProviderHandler;

    private ArrayList iSelections = new ArrayList();

    private LayerSelection iLayerSelection;

    private boolean iAmUpdating;



    public LayerSelectionView( GledApplication aApplication )
    {
        iTileProviderHandler = aApplication.getTileContainer();
        iTileProviderHandler.addListener( this );

        iLayerSelection = aApplication.getLayerSelection();
        iLayerSelection.addListener( this );

        setTitle( "Layer Selection" );

        onTileProviderChanged();
    }

    // From TileProviderListener

    public void onTileProviderChanged()
    {
        if ( iAmUpdating )
        {
            return;
        }
        iAmUpdating = true;

        iSelections.clear();
        removeAll();

        int layers = iTileProviderHandler.getNumberOfLayers();
        for ( int idx = 0; idx < layers; idx++ )
        {
            MUIGroupH layer = new MUIGroupH();
            layer.addChild( new MUILabel( iTileProviderHandler.getLayerName( idx ) ) );

            MUICheckBox on = new MUICheckBox( "Visible" );
            on.setSelected( true );
            on.setActionForwarding( this );
            iSelections.add( on );
            layer.addChild( on );

            MUICheckBox size = new MUICheckBox( "Size" );
            size.setSelected( idx > 0 );
            size.setActionForwarding( this );
            iSelections.add( size );
            layer.addChild( size );

            MUISlider sizePercentage = new MUISlider( 1, 100, 75, false );
            sizePercentage.setActionForwarding( this );
            iSelections.add( sizePercentage );
            layer.addChild( sizePercentage );

            MUICheckBox trans = new MUICheckBox( "Transparent" );
            trans.setActionForwarding( this );
            iSelections.add( trans );
            layer.addChild( trans );

            MUISlider transPercentage = new MUISlider( 1, 100, 50, false  );
            transPercentage.setActionForwarding( this );
            iSelections.add( transPercentage );
            layer.addChild( transPercentage );

            addChild( layer );
        }

        iAmUpdating = false;
    }

    // From LayerSelectionListener

    public void onLayerSelectionChanged( LayerSelection aLayerSelection )
    {
        if ( iAmUpdating )
        {
            return;
        }
        iAmUpdating = true;

        int layers = iTileProviderHandler.getNumberOfLayers();
        layers = Math.min( layers, iSelections.size() / 3 );

        for ( int idx = 0; idx < layers; idx++ )
        {
            MUICheckBox on = ( MUICheckBox ) iSelections.get( idx * 5 + 0 );
            on.setSelected( iLayerSelection.getVisibility( idx ) );

            MUICheckBox size = ( MUICheckBox ) iSelections.get( idx * 5 + 1 );
            size.setSelected( iLayerSelection.getReducedSize( idx ) );

            MUISlider sizePercentage = ( MUISlider ) iSelections.get( idx * 5 + 2 );
            sizePercentage.setValue( iLayerSelection.getSizePercentage( idx ) );

            MUICheckBox trans = ( MUICheckBox ) iSelections.get( idx * 5 + 3 );
            trans.setSelected( iLayerSelection.getTransparency( idx ) );

            MUISlider transPercentage = ( MUISlider ) iSelections.get( idx * 5 + 4 );
            transPercentage.setValue( iLayerSelection.getTransparencyPercentage( idx ) );
        }

        iAmUpdating = false;
    }

    // From ActionListener

    public void actionPerformed( ActionEvent aEvent )
    {
        if ( iAmUpdating )
        {
            return;
        }
        iAmUpdating = true;

        int layers = iTileProviderHandler.getNumberOfLayers();
        layers = Math.min( layers, iSelections.size() / 3 );

        for ( int idx = 0; idx < layers; idx++ )
        {
            MUICheckBox on = ( MUICheckBox ) iSelections.get( idx * 5 + 0 );
            iLayerSelection.setVisibility( idx, on.isSelected() );

            MUICheckBox size = ( MUICheckBox ) iSelections.get( idx * 5 + 1 );
            iLayerSelection.setReducedSize( idx, size.isSelected() );

            MUISlider sizePercentage = ( MUISlider ) iSelections.get( idx * 5 + 2 );
            iLayerSelection.setSizePercentage( idx, sizePercentage.getValue() );

            MUICheckBox trans = ( MUICheckBox ) iSelections.get( idx * 5 + 3 );
            iLayerSelection.setTransparency( idx, trans.isSelected() );

            MUISlider transPercentage = ( MUISlider ) iSelections.get( idx * 5 + 4 );
            iLayerSelection.setTransparencyPercentage( idx, transPercentage.getValue() );
        }

        iAmUpdating = false;
    }
}
