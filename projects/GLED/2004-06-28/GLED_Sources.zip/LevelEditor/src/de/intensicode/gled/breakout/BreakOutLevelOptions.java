/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.breakout;

import de.intensicode.gled.util.IntensiCodeLevelOptions;
import de.intensicode.symbian.Mem;
import de.intensicode.symbian.TDes8;



/**
 * Handles loading and saving of the BreakOut specific option set.
 */
class BreakOutLevelOptions extends IntensiCodeLevelOptions
{
    private BreakOutLevelDataProvider iContainer;

    private int iLevelNumber;

    private String iLevelName;

    static final String KTagLine1 = new String( "Tagline 1" );

    static final String KTagLine2 = new String( "Tagline 2" );

    static final String KBackgroundStyle = new String( "Background Style" );

    static final String KDrawShadows = new String( "Draw Shadows" );

    static final String KDrawStars = new String( "Draw Stars" );

    static final String KGradientColor = new String( "Gradient Color" );

    static final String KBackgroundTileIndex = new String( "Background Tile Index" );

    static final String KShadowIntensity = new String( "Shadow Intensity" );

    static final String KShadowDistance = new String( "Shadow Distance" );

    static final String KBackgroundColorR = new String( "Background Color R" );

    static final String KBackgroundColorG = new String( "Background Color G" );

    static final String KBackgroundColorB = new String( "Background Color B" );

    private final int iDataBytesPerLine;



    public BreakOutLevelOptions( BreakOutLevelDataProvider aContainer, int aLevelNumber )
    {
        super( aContainer.getLevelOptions() );

        iContainer = aContainer;
        iLevelNumber = aLevelNumber;
        iLevelName = Integer.toString( iLevelNumber );
        iDataBytesPerLine = iContainer.iDataBytesPerLine - iContainer.iCharsAtEOL;
    }

    public void setLevelNumber( int aIndex )
    {
        iLevelNumber = aIndex;
        iLevelName = Integer.toString( aIndex );
    }

    public void load( TDes8 aLevelData )
    {
        loadOptions( aLevelData );
        loadTagLines( aLevelData );
    }

    public void save( TDes8 aLevelData )
    {
        saveTagLines( aLevelData );
        saveOptions( aLevelData );
    }

    // From LevelOptions

    public String getLevelName()
    {
        return iLevelName;
    }

    // Implementation

    private void loadOptions( TDes8 aLevelData )
    {
        iOptions.resetToDefaults();

        readOptions( aLevelData.mid( iContainer.iDataBytesPerLine * 4, iDataBytesPerLine ) );
        readOptions( aLevelData.mid( iContainer.iDataBytesPerLine * 5, iDataBytesPerLine ) );
    }

    private void saveOptions( TDes8 aLevelData )
    {
        int numberOfOptions = iOptions.getNumberOfOptions();
        int halfNumberOfOptions = numberOfOptions * 2 / 3;

        TDes8 line1 = aLevelData.mid( iContainer.iDataBytesPerLine * 4, iDataBytesPerLine );
        Mem.Fill( line1, line1.length(), ( byte ) ' ' );
        writeOptions( line1, 0, halfNumberOfOptions );

        TDes8 line2 = aLevelData.mid( iContainer.iDataBytesPerLine * 5, iDataBytesPerLine );
        Mem.Fill( line2, line2.length(), ( byte ) ' ' );
        writeOptions( line2, halfNumberOfOptions, numberOfOptions );
    }

    private void loadTagLines( TDes8 aLevelData )
    {
        loadTagLine( KTagLine1, aLevelData, iContainer.iDataBytesPerLine * 1 );
        loadTagLine( KTagLine2, aLevelData, iContainer.iDataBytesPerLine * 2 );
    }

    private void saveTagLines( TDes8 aLevelData )
    {
        saveTagLine( KTagLine1, aLevelData, iContainer.iDataBytesPerLine * 1, iContainer.iLevelTagLineLength );
        saveTagLine( KTagLine2, aLevelData, iContainer.iDataBytesPerLine * 2, iContainer.iLevelTagLineLength );
    }
}
