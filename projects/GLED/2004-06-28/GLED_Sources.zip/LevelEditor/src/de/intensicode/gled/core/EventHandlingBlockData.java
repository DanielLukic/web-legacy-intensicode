/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.core;

import de.intensicode.gled.domain.BlockData;
import de.intensicode.gled.domain.TileSelection;



/**
 *
 */
class EventHandlingBlockData implements BlockData
{
    private EventHandlingLevelData iLevelData;

    private BlockData iBlockData;



    public EventHandlingBlockData( EventHandlingLevelData aEventHandlingLevelData, BlockData aBlockData )
    {
        iLevelData = aEventHandlingLevelData;
        iBlockData = aBlockData;
    }

    // From BlockData

    public boolean isEmpty( int aLayerIndex )
    {
        return iBlockData.isEmpty( aLayerIndex );
    }

    public boolean matches( TileSelection aTileSelection )
    {
        return iBlockData.matches( aTileSelection );
    }

    public int getTileIndex( int aLayerIndex )
    {
        return iBlockData.getTileIndex( aLayerIndex );
    }

    public void setTileIndex( int aLayerIndex, int aSelectedTile )
    {
        iBlockData.setTileIndex( aLayerIndex, aSelectedTile );
        iLevelData.iContainer.fireLevelDataChanged( iLevelData.iLevelIndex );
    }

    public void setFrom( TileSelection aTileSelection )
    {
        iBlockData.setFrom( aTileSelection );
        iLevelData.iContainer.fireLevelDataChanged( iLevelData.iLevelIndex );
    }

    public void setFrom( BlockData aData )
    {
        iBlockData.setFrom( aData );
        iLevelData.iContainer.fireLevelDataChanged( iLevelData.iLevelIndex );
    }

    public BlockData cloned()
    {
        return new EventHandlingBlockData( iLevelData, iBlockData.cloned() );
    }
}
