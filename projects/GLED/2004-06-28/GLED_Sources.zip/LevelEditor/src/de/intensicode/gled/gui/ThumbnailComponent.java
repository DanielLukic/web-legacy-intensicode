/************************************************************************/
/* GLED                 www.intensicode.de                December 2003 */
/************************************************************************/

package de.intensicode.gled.gui;

import de.intensicode.gled.domain.LevelOptions;
import de.intensicode.mui.MUICanvas;
import de.intensicode.mui.MUIGroupV;
import de.intensicode.mui.Paintable;

import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;



public class ThumbnailComponent extends MUIGroupV
{
    private LevelOptions iLevelOptions;

    private ThumbnailRenderer iRenderer;



    public ThumbnailComponent( LevelOptions alevelOptions, BufferedImage aThumbnail, boolean aShowTitleFlag )
    {
        iLevelOptions = alevelOptions;
        iRenderer = new ThumbnailRenderer( aThumbnail );

        setToolTipText( "Level " + iLevelOptions.getLevelName() );
        if ( aShowTitleFlag )
        {
            setTitle( iLevelOptions.getLevelName() );
        }
        else
        {
            setTitle( null );
        }
        addChild( iRenderer );
    }

    public void setImage( BufferedImage aBufferedImage )
    {
        iRenderer.setImage( aBufferedImage );
    }

    public void showTitle()
    {
        setTitle( iLevelOptions.getLevelName() );
    }

    public void hideTitle()
    {
        setTitle( null );
    }



    private /*inner*/ class ThumbnailRenderer extends MUICanvas implements Paintable
    {
        private BufferedImage iThumbnail;

        public ThumbnailRenderer( BufferedImage aThumbnail )
        {
            iThumbnail = aThumbnail;
            addPaintable( this );
        }

        public void setImage( BufferedImage aThumbnail )
        {
            iThumbnail = aThumbnail;
        }

        // From Paintable

        public void paintInto( Graphics2D aGc, Dimension aTargetSize )
        {
            int width = aTargetSize.width;
            int height = aTargetSize.height;
            int size = Math.min( width, height );
            int xOffset = ( width - size ) / 2;
            int yOffset = ( height - size ) / 2;
            aGc.drawImage( iThumbnail, xOffset, yOffset, size, size, null );
        }
    }
}
