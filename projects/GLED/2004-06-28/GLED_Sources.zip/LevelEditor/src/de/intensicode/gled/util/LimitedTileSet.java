/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.util;

import de.intensicode.core.logging.Log;
import de.intensicode.gled.core.ImageBasedTile;
import de.intensicode.gled.domain.BlockData;
import de.intensicode.gled.domain.Tile;
import de.intensicode.gled.domain.TileSet;

import java.awt.Dimension;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.awt.image.WritableRaster;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;



public class LimitedTileSet implements TileSet
{
    private Log iLog = Log.getLog();

    private Dimension iTileSize;

    private BufferedImage iImage;

    private Tile[] iTileSet = new Tile[ 0 ];

    private int iWidth;

    private int iHeight;



    public LimitedTileSet( Dimension aTileSize )
    {
        iTileSize = aTileSize;
    }

    // From TileSet

    public void load( File aTileSetFile ) throws IOException
    {
        iLog.info( "Loading " + aTileSetFile );

        iImage = ImageIO.read( aTileSetFile );

        iWidth = iImage.getWidth( null );
        iHeight = iImage.getHeight( null );

        if ( iWidth <= 0 || iHeight <= 0 )
        {
            throw new IllegalArgumentException( "Empty image?" );
        }
        if ( ( iWidth % iTileSize.width ) != 0 )
        {
            throw new IOException( "Tile width does not fit image width" );
        }
        if ( ( iHeight % iTileSize.height ) != 0 )
        {
            throw new IOException( "Tile height does not fit image height" );
        }

        iTileSet = new Tile[ iWidth * iHeight ];

        maskOutBackground();
    }

    public int getNumberOfTiles()
    {
        return getTilesPerRow() * getTilesPerColumn();
    }

    public int getTilesPerRow() throws IllegalStateException
    {
        if ( iImage == null )
        {
            return 0;
        }

        int imageWidth = iImage.getWidth();
        int width = iTileSize.width;
        if ( ( imageWidth % width ) != 0 )
        {
            throw new IllegalStateException( "Tile width does not fit image width" );
        }
        return imageWidth / width;
    }

    public int getTilesPerColumn() throws IllegalStateException
    {
        if ( iImage == null )
        {
            return 0;
        }

        int imageHeight = iImage.getHeight();
        int tileHeight = iTileSize.height;
        if ( ( imageHeight % tileHeight ) != 0 )
        {
            throw new IllegalStateException( "Tile height does not fit image height" );
        }
        return imageHeight / tileHeight;
    }

    public Tile getTile( int aIdx )
    {
        if ( iTileSet[ aIdx ] == null )
        {
            Rectangle tileRect = getTileRect( aIdx );
            iTileSet[ aIdx ] = new ImageBasedTile( iImage, tileRect );
        }
        return iTileSet[ aIdx ];
    }

    public Tile getTile( BlockData aBlockData )
    {
        throw new UnsupportedOperationException();
    }

    public boolean isEmpty( BlockData aBlockData )
    {
        throw new UnsupportedOperationException();
    }

    public boolean needsAlphaBlit()
    {
        return true;
    }

    // Implementation

    private Rectangle getTileRect( int aIdx )
    {
        int tilesPerRow = getTilesPerRow();
        int xPos = aIdx % tilesPerRow;
        int yPos = aIdx / tilesPerRow;

        int x = xPos * iTileSize.width;
        int y = yPos * iTileSize.height;

        Point pos = new Point( x, y );
        return new Rectangle( pos, iTileSize );
    }

    private void maskOutBackground()
    {
        iLog.info( "Masking out background pixels" );

        WritableRaster alpha = iImage.getAlphaRaster();
        if ( alpha == null )
        {
            alpha = createAlphaRaster();
        }
        int[] pixels = new int[ iWidth ];

        for ( int y = 0; y < iHeight; y++ )
        {
            iImage.getRGB( 0, y, iWidth, 1, pixels, 0, iWidth );

            for ( int x = 0; x < iWidth; x++ )
            {
                int color = pixels[ x ] & 0x00ffffff;
                pixels[ x ] = color != 0 ? 255 : 0;
            }

            alpha.setPixels( 0, y, iWidth, 1, pixels );
        }
    }

    private WritableRaster createAlphaRaster()
    {
        if ( iWidth < 1 || iHeight < 1 )
        {
            throw new IllegalArgumentException( "Invalid image size: " + iWidth + " " + iHeight );
        }

        BufferedImage withAlpha = new BufferedImage( iWidth, iHeight, BufferedImage.TYPE_INT_ARGB );

        Graphics2D g2d = withAlpha.createGraphics();
        g2d.drawImage( iImage, 0, 0, null );

        iImage = withAlpha;

        return withAlpha.getAlphaRaster();
    }
}
