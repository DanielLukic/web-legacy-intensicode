/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.commands;

import de.intensicode.core.logging.Log;
import de.intensicode.gled.gui.LevelOptionsView;



public class UpdateLevelOptions extends GledCommand
{
    private Log iLog = Log.getLog();

    private LevelOptionsView iLevelOptionsView;



    public UpdateLevelOptions( LevelOptionsView aLevelOptionsView )
    {
        iLevelOptionsView = aLevelOptionsView;

        // This has to be synchronous. Otherwise the update would happen
        // "delayed", after {@link LevelOptionsView#iAmUpdating iAmUpdating}
        // has already been resetToDefault to <code>false</code>.
        iAmAsync = false;
    }

    // From Command

    public void execute() throws Throwable
    {
        iLog.info( "Executing options update" );

        iLevelOptionsView.updateLevelOptions();
    }
}
