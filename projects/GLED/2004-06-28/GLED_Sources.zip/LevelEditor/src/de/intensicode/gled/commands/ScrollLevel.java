/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.commands;

import de.intensicode.gled.domain.LevelData;
import de.intensicode.gled.domain.LevelDataContainer;
import de.intensicode.gled.domain.LevelSelection;



public class ScrollLevel extends GledCommand
{
    private int iDeltaX;

    private int iDeltaY;



    public ScrollLevel( int aDeltaX, int aDeltaY )
    {
        iDeltaX = aDeltaX;
        iDeltaY = aDeltaY;
    }

    // From Command

    public void execute() throws Throwable
    {
        LevelDataContainer container = iApplication.getLevelDataContainer();

        LevelSelection levelSelection = iApplication.getLevelSelection();
        if ( levelSelection.isValid() == false )
        {
            return;
        }

        int selectedLevel = levelSelection.getLevelIndex();

        LevelData level = container.getLevelData( selectedLevel );
        level.scrollData( iDeltaX, iDeltaY );
    }
}
