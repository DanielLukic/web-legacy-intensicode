/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.util;

import de.intensicode.gled.domain.LevelOption;



/**
 * Represents a boolean level option.
 */
public class BooleanLevelOption extends AbstractLevelOption implements LevelOption.BooleanExtension
{
    public BooleanLevelOption()
    {
        super( KBoolean );
    }

    // From LevelOption

    public LevelOption cloned()
    {
        BooleanLevelOption clone = new BooleanLevelOption();
        clone.copyFrom( this );
        return clone;
    }

    public LevelOption.BooleanExtension getBooleanExtension()
    {
        return this;
    }

    // From BooleanExtension

    public boolean getBooleanValue()
    {
        return iValue.equalsIgnoreCase( "true" );
    }
}
