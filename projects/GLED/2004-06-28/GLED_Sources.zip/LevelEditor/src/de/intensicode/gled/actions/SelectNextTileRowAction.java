/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.actions;

import de.intensicode.gled.domain.TileSelection;
import de.intensicode.gled.domain.TileSet;
import de.intensicode.mui.MUIUtils;

import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

import javax.swing.Action;
import javax.swing.KeyStroke;



public class SelectNextTileRowAction extends GledAction
{
    public SelectNextTileRowAction()
    {
        putValue( Action.NAME, "Select next tile row" );
        putValue( Action.SHORT_DESCRIPTION, "Select next tile row" );
        putValue( Action.SMALL_ICON, MUIUtils.getIcon( "/icons/down.png" ) );
        putValue( Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke( KeyEvent.VK_DOWN, KeyEvent.ALT_DOWN_MASK ) );
    }

    // From ActionListener

    public void actionPerformed( ActionEvent e )
    {
        TileSelection tileSelection = iApplication.getTileSelection();
        if ( tileSelection.isValid() )
        {
            int layer = tileSelection.getLayerIndex();
            TileSet tileSet = iApplication.getTileProvider().getLayerTileSet( layer );
            int numberOfTiles = tileSet.getNumberOfTiles();
            int tileIndex = tileSelection.getTileIndex() + tileSet.getTilesPerRow();
            if ( tileIndex >= numberOfTiles )
            {
                tileIndex = 0;
            }
            tileSelection.setTo( layer, tileIndex );
        }
    }
}
