/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.domain;

import java.awt.Graphics2D;
import java.awt.Dimension;
import java.awt.Rectangle;



/**
 *
 */
public interface BackgroundPainter
{
    void paintInto( Graphics2D aGc, Dimension aSize, LevelData aLevelData );

    void paintRestricted( Graphics2D aGc, Dimension aSize, LevelData aLevelData, Rectangle aClipRect );
}
