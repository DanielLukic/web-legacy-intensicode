/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.commands;

import java.io.File;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;



public class SaveProject extends GledCommand
{
    // From Command

    public void execute()
    {
        File file = iApplication.getProjectFile();
        if ( file != null )
        {
            makeBackupIfNecessary( file );
            saveProject();
        }
        else
        {
            iCommandable.execute( new SaveProjectAs() );
        }
    }

    private void makeBackupIfNecessary( File aFile )
    {
        if ( aFile.exists() )
        {
            File backup = new File( aFile.getPath() + ".bak" );
            if ( backup.exists() )
            {
                backup.delete();
            }
            aFile.renameTo( backup );
        }
    }

    private void saveProject()
    {
        iUserInterface.showStatus( "Saving project.." );

        File file = iApplication.getProjectFile();

        FileOutputStream fileStream;
        ObjectOutputStream output;
        try
        {
            fileStream = new FileOutputStream( file );
            output = new ObjectOutputStream( fileStream );
            try
            {
                iUserInterface.showStatus( "Saving level data.." );
                new SaveLevelData().execute();

                iUserInterface.showStatus( "Saving project data.." );
                output.writeObject( iApplication.getDataForOutput() );
                output.flush();
                output.close();
            }
            finally
            {
                if ( output != null )
                {
                    output.close();
                }
                if ( fileStream != null )
                {
                    fileStream.close();
                }
            }
            iUserInterface.showStatus( "Project saved to " + file.getName() );
            iCommandable.execute( new ShowStatusMessage( "Project saved to " + file.getName() ) );
        }
        catch ( Throwable t )
        {
            iUserInterface.showStatus( "Failed saving project" );
            iCommandable.execute( new ShowErrorMessage( "Failed saving project", t ) );
        }
    }
}
