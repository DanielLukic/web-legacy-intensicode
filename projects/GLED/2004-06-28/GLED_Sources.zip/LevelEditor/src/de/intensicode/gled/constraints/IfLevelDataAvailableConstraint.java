/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.constraints;

import de.intensicode.gled.domain.LevelDataContainer;
import de.intensicode.gled.domain.LevelDataContainerListener;



public class IfLevelDataAvailableConstraint extends GledConstraint implements LevelDataContainerListener
{
    private LevelDataContainer iContainer;



    public IfLevelDataAvailableConstraint( LevelDataContainer aContainer )
    {
        iContainer = aContainer;
        aContainer.addListener( this );
    }

    // LevelDataContainerListener

    public void onLevelDataChanged()
    {
        setEnabled( iContainer.getNumberOfLevels() > 0 );
    }

    public void onLevelDataChanged( int aLevelIndex )
    {
        onLevelDataChanged();
    }
}
