/************************************************************************/
/* PROJECT_NAME            AUTHOR_OR_COMPANY           DATE_OF_CREATION */
/************************************************************************/

package de.intensicode.gled.util;

import de.intensicode.gled.domain.LevelOption;
import de.intensicode.gled.domain.LevelOptions;
import de.intensicode.symbian.TDes8;

import java.util.NoSuchElementException;



/**
 * Handles loading and saving of the BreakOut specific option set.
 */
public abstract class IntensiCodeLevelOptions implements LevelOptions
{
    protected ExternalLevelOptions iOptions;



    public IntensiCodeLevelOptions( ExternalLevelOptions aLevelOptions )
    {
        iOptions = aLevelOptions;
        iOptions.resetToDefaults();
    }

    // From LevelOptions

    public int getNumberOfOptions()
    {
        return iOptions.getNumberOfOptions();
    }

    public LevelOption getLevelOption( int aIndex )
    {
        return iOptions.getOption( aIndex );
    }

    public LevelOption getLevelOption( String aName )
    {
        return iOptions.getOption( aName );
    }

    // Protected Interface for Overriding

    protected void onUnknownOptionType( LevelOption aOption )
    {
        throw new RuntimeException( "Unknown level option type for " + aOption.getName() );
    }

    protected void onUnknownOptionTag( int aCode )
    {
        throw new RuntimeException( "Unknown level option tag " + ( char ) aCode );
    }

    // Protected Interface

    protected void readOptions( TDes8 aOptions )
    {
        for ( int idx = 0; idx < aOptions.length(); idx++ )
        {
            int code = aOptions.at( idx );
            if ( code == ' ' || code == '-' )
            {
                continue;
            }
            else if ( code == '|' )
            {
                break;
            }

            try
            {
                LevelOption option = iOptions.getOptionByTag( code );

                switch ( option.getType() )
                {
                    case LevelOption.KBoolean:
                        option.setValue( "true" );
                        break;

                    case LevelOption.KInteger:
                        idx = readIntegerOption( option, aOptions, idx );
                        break;

                    case LevelOption.KChoosable:
                        idx = readChoosableOption( option, aOptions, idx );
                        break;

                    default:
                        onUnknownOptionType( option );
                }
            }
            catch ( NoSuchElementException nseEx )
            {
                onUnknownOptionTag( code );
                continue;
            }
        }
    }

    protected void writeOptions( TDes8 aOptionsLine, int aStartIndex, int aExclusiveEndIndex )
    {
        int writeIndex = 0;
        for ( int idx = aStartIndex; idx < aExclusiveEndIndex; idx++ )
        {
            LevelOption option = iOptions.getOption( idx );
            String optionTag = option.getOptionTag();
            if ( optionTag == null )
            {
                continue;
            }
            if ( option.getValue().equals( option.getDefault() ) )
            {
                continue;
            }

            byte tag = ( byte ) optionTag.charAt( 0 );

            switch ( option.getType() )
            {
                case LevelOption.KBoolean:
                    if ( option.getBooleanExtension().getBooleanValue() )
                    {
                        aOptionsLine.set( writeIndex++, tag );
                        aOptionsLine.set( writeIndex++, ( byte ) ' ' );
                    }
                    break;

                case LevelOption.KInteger:
                    aOptionsLine.set( writeIndex++, tag );
                    writeIndex = appendNumber( aOptionsLine, writeIndex, option.getIntegerExtension().getIntegerValue() );
                    break;

                case LevelOption.KChoosable:
                    aOptionsLine.set( writeIndex++, tag );
                    writeIndex = appendNumber( aOptionsLine, writeIndex, option.getChoosableExtension().getSelectedItem() );
                    break;

                default:
                    throw new RuntimeException( "Unknown level option type for " + option.getName() );
            }
        }
    }

    protected String extractString( TDes8 aDataLine, int aStartIndex, String aDelimeterList )
    {
        StringBuffer buffer = new StringBuffer();
        for ( ; ; )
        {
            int code = aDataLine.at( aStartIndex );
            if ( aDelimeterList.indexOf( code ) != -1 )
            {
                break;
            }
            else if ( buffer.length() == aDataLine.length() )
            {
                break;
            }
            buffer.append( ( char ) code );
            ++aStartIndex;
        }
        return buffer.toString();
    }

    protected int appendNumber( TDes8 aBuffer, int aStartIndex, int aNumber )
    {
        String number = Integer.toString( aNumber );
        for ( int idx = 0; idx < number.length(); ++idx )
        {
            aBuffer.set( aStartIndex++, ( byte ) number.charAt( idx ) );
        }
        aBuffer.set( aStartIndex++, ( byte ) ' ' );
        return aStartIndex;
    }

    protected void loadTagLine( String aOptionID, TDes8 aLevelData, int aOffset )
    {
        String value = extractString( aLevelData, aOffset, "|" ).trim();
        iOptions.getOption( aOptionID ).setValue( value );
    }

    protected void saveTagLine( String aOptionID, TDes8 aLevelData, int aOffset, int aMaxLength )
    {
        String tagLine = padTagLineWithSpaces( iOptions.getOption( aOptionID ).getValue(), aMaxLength );

        TDes8 buffer = new TDes8( aLevelData, aOffset, aMaxLength );
        for ( int idx = 0; idx < aMaxLength; ++idx )
        {
            buffer.set( idx, ( byte ) tagLine.charAt( idx ) );
        }
        buffer.set( aMaxLength, ( byte ) '|' );
    }

    protected String padTagLineWithSpaces( String aTagLine, int aLength )
    {
        StringBuffer temp = new StringBuffer( aTagLine );
        while ( temp.length() < aLength )
        {
            temp.append( ' ' );
        }

        String result = temp.toString();
        return result.substring( 0, aLength );
    }

    // Implementation

    private int readChoosableOption( LevelOption aOption, TDes8 aOptions, int aIdx )
    {
        String value = extractString( aOptions, aIdx + 1, " -|" );
        aOption.getChoosableExtension().setSelectedItem( Integer.parseInt( value ) );
        return aIdx + value.length();
    }

    private int readIntegerOption( LevelOption aOption, TDes8 aOptions, int aIdx )
    {
        String value = extractString( aOptions, aIdx + 1, " -|" );
        aOption.setValue( value );
        return aIdx + value.length();
    }
}
