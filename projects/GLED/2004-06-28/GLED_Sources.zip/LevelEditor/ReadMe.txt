GLED ReadMe
~~~~~~~~~~~

1. Installation / Running

Make sure you have a decent (1.4 or later) JDK or JRE installed. If not,
grab one here: http://www.java.com/en/download/windows_automatic.jsp

If you have Java installed, please make sure the path to your java.exe
(or javaw.exe if you're using a JRE release only) is set correctly in
the GLED.bat.

Then start GLED by double-clicking/running the GLED.bat.

See the Manual.txt for information on the usage.


2. Credits

Icons grabbed from http://primates.ximian.com/~tigert/new_stock_project/
