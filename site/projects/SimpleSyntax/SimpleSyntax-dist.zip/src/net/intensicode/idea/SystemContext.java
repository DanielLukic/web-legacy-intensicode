package net.intensicode.idea;

import com.intellij.openapi.editor.colors.TextAttributesKey;
import com.intellij.openapi.editor.markup.TextAttributes;
import com.intellij.openapi.fileTypes.FileTypeManager;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;

import javax.swing.Icon;



/**
 * TODO: Describe this!
 */
public interface SystemContext
{
    SystemErrorHandler getErrorHandler();


    String getConfigurationFolder();

    FileTypeManager getFileTypeManager();

    TextAttributes getHighlighterDefaults( String aTokenID );

    TextAttributesKey createTextAttributesKey( String aTokenID, TextAttributes aAttributes );


    Icon loadIcon( String aIconFileName );

    byte[] loadFile( String aResourceName ) throws IOException;

    InputStream streamFile( String aFileName );

    BufferedReader readFile( String aFileName );

    String readFileIntoString( String aFileName ) throws IOException;


    void copyResource( String aResourceName, String aTargetFolder ) throws IOException;
}
