package net.intensicode.idea.core;

import com.intellij.openapi.diagnostic.Logger;
import com.intellij.openapi.editor.markup.TextAttributes;
import net.intensicode.idea.util.LoggerFactory;

import java.awt.Color;
import java.awt.Font;
import java.util.regex.Pattern;



/**
 * TODO: Describe this!
 */
final class ConfigurableTextAttributes extends TextAttributes
{
    static final ConfigurableTextAttributes newInstance( final String aAttributesSpec )
    {
        final ConfigurableTextAttributes attributes = new ConfigurableTextAttributes();
        final String[] parts = aAttributesSpec.split( "," );
        for ( final String part : parts )
        {
            if ( isColor( part ) ) attributes.setColor( part );
            else if ( isBold( part ) ) attributes.setFontType( Font.BOLD );
            else if ( isItalic( part ) ) attributes.setFontType( Font.ITALIC );
            else LOG.error( "Unknown attribute tag: " + part + " in " + aAttributesSpec );
        }
        return attributes;
    }

    // From TextAttributes

    public final void setFontType( final int type )
    {
        super.setFontType( getFontType() | type );
    }

    // Implementation

    private ConfigurableTextAttributes()
    {
    }

    private final void setColor( final String aColorSpec )
    {
        final Color color = Color.decode( aColorSpec );
        if ( getForegroundColor() == null ) setForegroundColor( color );
        else if ( getBackgroundColor() == null ) setBackgroundColor( color );
        else if ( getEffectColor() == null ) setEffectColor( color );
        else if ( getErrorStripeColor() == null ) setErrorStripeColor( color );
    }

    private static final boolean isColor( final String aPart )
    {
        return Pattern.matches( COLOR_PATTERN, aPart );
    }

    private static final boolean isBold( final String aPart )
    {
        return aPart.equalsIgnoreCase( "BOLD" );
    }

    private static final boolean isItalic( final String aPart )
    {
        return aPart.equalsIgnoreCase( "ITALIC" );
    }



    private static final Logger LOG = LoggerFactory.getLogger();

    private static final String COLOR_PATTERN = "#[0-9a-fA-F]{6}";
}
