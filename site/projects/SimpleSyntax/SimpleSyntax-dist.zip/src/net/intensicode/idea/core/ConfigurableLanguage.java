package net.intensicode.idea.core;

import com.intellij.lang.Commenter;
import com.intellij.lang.Language;
import com.intellij.lang.PairedBraceMatcher;
import com.intellij.openapi.editor.colors.TextAttributesKey;
import com.intellij.openapi.editor.markup.TextAttributes;
import com.intellij.openapi.fileTypes.SyntaxHighlighter;
import com.intellij.openapi.project.Project;
import com.intellij.psi.tree.IElementType;
import net.intensicode.idea.SystemContext;
import net.intensicode.idea.config.InstanceConfiguration;
import net.intensicode.idea.syntax.RecognizedToken;
import net.intensicode.idea.syntax.SimpleSyntaxHighlighter;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;



/**
 * TODO: Describe this!
 */
public final class ConfigurableLanguage extends Language implements LanguageConfiguration
{
    public static final ConfigurableLanguage getOrCreate( final SystemContext aSystemContext, InstanceConfiguration aConfiguration )
    {
        final String name = aConfiguration.getName();
        for ( final Language language : Language.getRegisteredLanguages() )
        {
            if ( language.getID().equals( name ) == false ) continue;
            if ( language instanceof ConfigurableLanguage == false )
            {
                throw new RuntimeException( "Incompatible language registered for " + name );
            }

            final ConfigurableLanguage oldLanguage = ( ConfigurableLanguage ) language;
            oldLanguage.reset( aSystemContext, aConfiguration );
            return oldLanguage;
        }
        return new ConfigurableLanguage( aSystemContext, aConfiguration );
    }

    // From LanguageConfiguration

    public final IElementType getToken( final String aTokenId )
    {
        if ( myTokens.containsKey( aTokenId ) == false )
        {
            myTokens.put( aTokenId, new GenericElementType( aTokenId, this ) );
        }
        return myTokens.get( aTokenId );
    }

    public final SyntaxHighlighter getSyntaxHighlighter()
    {
        return mySyntaxHighlighter;
    }

    public final List<RecognizedToken> getRecognizedTokens()
    {
        return myRecognizedTokens;
    }

    public final TextAttributesKey getTextAttributesKey( final String aTokenID )
    {
        if ( myTextAttributesKeys.containsKey( aTokenID ) == false )
        {
            final TextAttributes attributes = createTextAttributes( aTokenID );
            final TextAttributesKey attributesKey = mySystemContext.createTextAttributesKey( aTokenID, attributes );
            myTextAttributesKeys.put( aTokenID, attributesKey );
        }
        return myTextAttributesKeys.get( aTokenID );
    }

    public final TextAttributesKey[] getTokenHighlights( final IElementType tokenType )
    {
        final TextAttributesKey[] keys = myTokenHighlights.get( tokenType );
        if ( keys == null ) return NO_TEXT_ATTRIBUTES;
        return keys;
    }

    // From Language

    @NotNull
    public final SyntaxHighlighter getSyntaxHighlighter( final Project project )
    {
        return getSyntaxHighlighter();
    }

    @Nullable
    public final PairedBraceMatcher getPairedBraceMatcher()
    {
        return myConfigurableBraceMatcher;
    }

    @Nullable
    public final Commenter getCommenter()
    {
        return myCommenter;
    }

    // Implementation

    private ConfigurableLanguage( final SystemContext aSystemContext, final InstanceConfiguration aConfiguration )
    {
        super( aConfiguration.getName() );
        reset( aSystemContext, aConfiguration );
    }

    private final void reset( final SystemContext aSystemContext, final InstanceConfiguration aConfiguration )
    {
        mySystemContext = aSystemContext;
        myConfiguration = aConfiguration;

        myRecognizedTokens.clear();
        myTokenHighlights.clear();
        myTextAttributesKeys.clear();
        for ( final RecognizedToken token : aConfiguration.getRecognizedTokens() )
        {
            addRecognizedToken( token );
        }

        myCommenter = new ConfigurableCommenter( aConfiguration.getCommentConfiguration() );
        mySyntaxHighlighter = new SimpleSyntaxHighlighter( mySystemContext, this );
        myConfigurableBraceMatcher = new ConfigurableBraceMatcher( this, aConfiguration.getBracesConfiguration() );
    }

    private final void addRecognizedToken( final RecognizedToken aToken )
    {
        final String id = aToken.getTokenID();
        final IElementType elementType = getToken( id );
        final TextAttributesKey attributesKey = getTextAttributesKey( id );
        myTokenHighlights.put( elementType, new TextAttributesKey[]{attributesKey} );

        myRecognizedTokens.add( aToken );
    }

    private final TextAttributes createTextAttributes( final String aTokenID )
    {
        final String attributes = myConfiguration.getTokenAttributes( aTokenID );
        if ( attributes == null || attributes.length() == 0 ) return new TextAttributes();
        return ConfigurableTextAttributes.newInstance( attributes );
    }



    private Commenter myCommenter;

    private SystemContext mySystemContext;

    private InstanceConfiguration myConfiguration;

    private SimpleSyntaxHighlighter mySyntaxHighlighter;

    private ConfigurableBraceMatcher myConfigurableBraceMatcher;

    private final ArrayList<RecognizedToken> myRecognizedTokens = new ArrayList<RecognizedToken>();

    private final HashMap<String, TextAttributesKey> myTextAttributesKeys = new HashMap<String, TextAttributesKey>();

    private final HashMap<IElementType, TextAttributesKey[]> myTokenHighlights = new HashMap<IElementType, TextAttributesKey[]>();

    private final HashMap<String, IElementType> myTokens = new HashMap<String, IElementType>();

    private static final TextAttributesKey[] NO_TEXT_ATTRIBUTES = new TextAttributesKey[0];
}
