package net.intensicode.idea.util;

import com.intellij.openapi.diagnostic.Logger;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

import javax.swing.Icon;



/**
 * TODO: Describe this!
 */
public final class ResourceLoader
{
    public ResourceLoader()
    {
        this( null );
    }

    public ResourceLoader( final String aBaseFolder )
    {
        myBaseFolder = aBaseFolder;
    }

    public final String getFilePath( final String aRelativeFileName )
    {
        if ( baseFolderGiven() == false ) return aRelativeFileName;
        return new File( myBaseFolder, aRelativeFileName ).toString();
    }

    public final Icon getIcon( final String aIconResourcePath )
    {
        return IconFactory.getIcon( getFilePath( aIconResourcePath ) );
    }

    public final InputStream getResource( final String aResourcePath )
    {
        final String fullPathName = getFilePath( aResourcePath );
        System.out.println( fullPathName );
        
        try
        {
            final InputStream stream = ResourceLoader.class.getResourceAsStream( fullPathName );
            if ( stream != null ) return stream;
        }
        catch ( final Throwable t )
        {
        }
        try
        {
            final InputStream stream = new FileInputStream( fullPathName );
            if ( stream != null ) return stream;
        }
        catch ( final Throwable t )
        {
        }
        ResourceLoader.LOG.info( "Failed loading resource " + aResourcePath );
        return null;
    }

    // Implementation

    private final boolean baseFolderGiven()
    {
        if ( myBaseFolder == null ) return false;
        if ( myBaseFolder.length() == 0 ) return false;
        return true;
    }



    private final String myBaseFolder;

    private static final Logger LOG = LoggerFactory.getLogger();
}
