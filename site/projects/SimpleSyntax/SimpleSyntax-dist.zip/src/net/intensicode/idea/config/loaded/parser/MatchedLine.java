package net.intensicode.idea.config.loaded.parser;

/**
 * TODO: Describe this!
 */
public interface MatchedLine
{
    String getValue( int aIndex );
}
