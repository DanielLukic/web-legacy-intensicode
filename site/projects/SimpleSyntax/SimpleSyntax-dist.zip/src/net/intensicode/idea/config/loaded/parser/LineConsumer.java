package net.intensicode.idea.config.loaded.parser;

/**
 * TODO: Describe this!
 */
public interface LineConsumer
{
    void consume( int aLineType, MatchedLine aMatchedLine );
}
