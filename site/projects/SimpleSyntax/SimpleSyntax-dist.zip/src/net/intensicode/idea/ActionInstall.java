package net.intensicode.idea;

import com.intellij.openapi.actionSystem.AnAction;
import com.intellij.openapi.actionSystem.AnActionEvent;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;



/**
 * TODO: Describe this!
 */
public final class ActionInstall extends AnAction
{
    public ActionInstall()
    {
        myContext = new ProductionSystemContext();
    }

    // From AnAction

    public final void actionPerformed( final AnActionEvent aEvent )
    {
        try
        {
            copyResource( SIMPLESYNTAX_RUBY_CONFIG );
            copyResource( "simplesyntax_ruby.png" );
            copyResource( "simplesyntax_ruby.rb" );

            final BufferedReader reader = myContext.readFile( SIMPLESYNTAX_RUBY_CONFIG );
            while ( true )
            {
                final String line = reader.readLine();
                if ( line == null ) break;
                if ( isExternalRuleSpec( line ) ) copyResource( myRuleMatcher.group( 1 ) );
            }
        }
        catch ( final IOException e )
        {
            myContext.getErrorHandler().onSimpleSyntaxInstallFailed( e );
        }
    }

    // Implementation

    private final void copyResource( final String aResourceName ) throws IOException
    {
        myContext.copyResource( aResourceName, myContext.getConfigurationFolder() );
    }

    private final boolean isExternalRuleSpec( final String aLine )
    {
        return myRuleMatcher.reset( aLine ).matches();
    }




    private final SystemContext myContext;

    private final Matcher myRuleMatcher = Pattern.compile( RULE_PATTERN ).matcher( EMPTY_INPUT );


    private static final String EMPTY_INPUT = "";

    private static final String RULE_PATTERN = "\\w+\\s+[A-Z_]+\\s*=>\\s*(tags\\/.+)";

    private static final String SIMPLESYNTAX_RUBY_CONFIG = "simplesyntax_ruby.config";
}
