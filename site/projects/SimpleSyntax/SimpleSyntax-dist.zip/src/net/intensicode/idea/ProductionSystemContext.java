package net.intensicode.idea;

import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.application.PathManager;
import com.intellij.openapi.diagnostic.Logger;
import com.intellij.openapi.editor.colors.TextAttributesKey;
import com.intellij.openapi.editor.markup.TextAttributes;
import com.intellij.openapi.fileTypes.FileTypeManager;
import com.intellij.openapi.ui.Messages;
import net.intensicode.idea.syntax.RecognizedToken;
import net.intensicode.idea.util.LoggerFactory;

import java.io.*;
import java.util.HashMap;

import javax.swing.Icon;
import javax.swing.ImageIcon;



/**
 * TODO: Describe this!
 */
final class ProductionSystemContext implements SystemContext, SystemErrorHandler
{
    ProductionSystemContext()
    {
    }

    // From SystemContext

    public final SystemErrorHandler getErrorHandler()
    {
        return this;
    }

    public final String getConfigurationFolder()
    {
        return PathManager.getOptionsPath();
    }

    public final FileTypeManager getFileTypeManager()
    {
        return FileTypeManager.getInstance();
    }

    public final TextAttributesKey createTextAttributesKey( final String aTokenID, final TextAttributes aAttributes )
    {
        return TextAttributesKey.createTextAttributesKey( aTokenID, aAttributes );
    }

    public synchronized final Icon loadIcon( final String aIconFileName )
    {
        if ( myLoadedIcons.containsKey( aIconFileName ) ) return myLoadedIcons.get( aIconFileName );

        InputStream stream = streamFile( aIconFileName );
        if ( stream == null )
        {
            stream = streamFile( "icons/" + aIconFileName );
            if ( stream == null ) return null;
        }

        try
        {
            final byte[] data = loadStream( stream );
            final ImageIcon icon = new ImageIcon( data );
            myLoadedIcons.put( aIconFileName, icon );
            return icon;
        }
        catch ( final IOException e )
        {
        }

        return null;
    }

    public final byte[] loadFile( final String aResourceName ) throws IOException
    {
        final InputStream stream = streamFile( aResourceName );
        if ( stream == null ) throw new FileNotFoundException( aResourceName );
        return loadStream( stream );
    }

    public final InputStream streamFile( final String aResourceName )
    {
        try
        {
            final String fileName = makeAbsolute( aResourceName );
            return new FileInputStream( fileName );
        }
        catch ( final FileNotFoundException e )
        {
        }

        final InputStream resourceStream = getClass().getResourceAsStream( "/" + aResourceName );
        if ( resourceStream != null ) return resourceStream;

        LOG.error( "Loading failed for resource " + aResourceName );

        return null;
    }

    public final BufferedReader readFile( final String aFileName )
    {
        final InputStream stream = streamFile( aFileName );
        if ( stream == null ) return null;
        return new BufferedReader( new InputStreamReader( stream ) );
    }

    public final String readFileIntoString( final String aFileName ) throws IOException
    {
        final BufferedReader reader = readFile( aFileName );
        if ( reader == null ) return null;

        try
        {
            final StringBuilder result = new StringBuilder();
            while ( true )
            {
                final String line = reader.readLine();
                if ( line == null ) break;
                result.append( line );
                result.append( '\n' );
            }
            return result.toString();
        }
        finally
        {
            reader.close();
        }
    }

    public void copyResource( String aResourceName, String aTargetFolder ) throws IOException
    {
        final byte[] data = loadFile( aResourceName );
        final File target = new File( aTargetFolder, aResourceName );
        prepareFolder( target );

        final FileOutputStream output = new FileOutputStream( target );
        output.write( data );
        output.close();
    }

    // From SystemErrorHandler

    public final void onTokenRecognizerFailed( final RecognizedToken aToken, final Throwable aThrowable )
    {
        ApplicationManager.getApplication().runReadAction( new Runnable()
        {
            public final void run()
            {
                final StringBuilder messageBuilder = new StringBuilder();
                messageBuilder.append( "Token recognizer failed.\n" );
                messageBuilder.append( "Error message is: " );
                messageBuilder.append( aThrowable.getMessage() );
                messageBuilder.append( '\n' );
                messageBuilder.append( "Token recognizer ID: " );
                messageBuilder.append( aToken.getTokenID() );
                messageBuilder.append( '\n' );
                messageBuilder.append( "Removing recognizer and continuing.." );

                displayError( messageBuilder );
            }
        } );
    }

    public final void onSimpleSyntaxInstallFailed( final Throwable aThrowable )
    {
        ApplicationManager.getApplication().runReadAction( new Runnable()
        {
            public final void run()
            {
                final StringBuilder messageBuilder = new StringBuilder();
                messageBuilder.append( "Installation failed.\n" );
                messageBuilder.append( "Error message is: " );
                messageBuilder.append( aThrowable.getMessage() );

                displayError( messageBuilder );
            }
        } );
    }

    // Implementation

    private final byte[] loadStream( final InputStream aStream ) throws IOException
    {
        final ByteArrayOutputStream bytes = new ByteArrayOutputStream();

        final byte[] buffer = new byte[ 4096 ];
        while ( true )
        {
            final int newBytes = aStream.read( buffer );
            if ( newBytes == -1 ) break;
            bytes.write( buffer, 0, newBytes );
        }
        aStream.close();
        bytes.close();

        return bytes.toByteArray();
    }

    private final String makeAbsolute( final String aFileName )
    {
        if ( new File( aFileName ).isAbsolute() ) return aFileName;
        final String baseFolder = getConfigurationFolder();
        return new File( baseFolder, aFileName ).getPath();
    }

    private final void prepareFolder( final File aTarget )
    {
        final File target = aTarget.getParentFile();
        if ( target.exists() && target.isDirectory() ) return;
        target.mkdirs();
    }

    private final void displayError( final StringBuilder aMessageBuilder )
    {
        final String message = aMessageBuilder.toString();
        Messages.showErrorDialog( message, "Simple Syntax Plugin Error" );
        LOG.error( message );
    }



    private static final Logger LOG = LoggerFactory.getLogger();

    private static final HashMap<String, ImageIcon> myLoadedIcons = new HashMap<String, ImageIcon>();
}
