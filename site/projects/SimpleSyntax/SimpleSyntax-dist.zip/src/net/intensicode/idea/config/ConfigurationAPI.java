package net.intensicode.idea.config;

import net.intensicode.idea.syntax.RecognizedToken;



/**
 * TODO: Describe this!
 */
public interface ConfigurationAPI
{
    void addRecognizedToken( final RecognizedToken aRecognizedToken );
}
