package net.intensicode.idea.config;

import javax.swing.Icon;



/**
 * TODO: Describe this!
 */
public interface FileTypeConfiguration
{
    Icon getIcon();

    String[] getExtensions();

    String getDefaultExtension();
}
