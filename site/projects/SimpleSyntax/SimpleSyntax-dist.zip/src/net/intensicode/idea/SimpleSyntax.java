package net.intensicode.idea;

import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.components.ApplicationComponent;
import com.intellij.openapi.diagnostic.Logger;
import com.intellij.openapi.options.ConfigurationException;
import net.intensicode.idea.config.FileTypeConfiguration;
import net.intensicode.idea.config.InstanceConfiguration;
import net.intensicode.idea.config.loaded.LoadedConfiguration;
import net.intensicode.idea.util.LoggerFactory;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.Nullable;

import java.io.File;
import java.io.FilenameFilter;
import java.util.ArrayList;

import javax.swing.Icon;
import javax.swing.JComponent;



/**
 * TODO: Describe this!
 */
public final class SimpleSyntax implements ApplicationComponent, /*Configurable,*/ FilenameFilter
{
    public SimpleSyntax()
    {
    }

    // From ApplicationComponent

    public final void initComponent()
    {
        if ( initialize() == false ) return;

        ApplicationManager.getApplication().runWriteAction( new Runnable()
        {
            public final void run()
            {
                for ( final SimpleSyntaxInstance instance : myInstances )
                {
                    instance.init( mySystemContext );
                }
            }
        } );
    }

    public final void disposeComponent()
    {
        if ( myInitStatus == false ) return;

        ApplicationManager.getApplication().runWriteAction( new Runnable()
        {
            public final void run()
            {
                if ( myInitStatus == false ) return;

                for ( final SimpleSyntaxInstance instance : myInstances )
                {
                    instance.dispose( mySystemContext );
                }

                myInstances.clear();
                myInitStatus = false;
            }
        } );
    }

    public final String getComponentName()
    {
        return "net.intensicode.idea.SimpleSyntax";
    }

    // From Configurable

    public final String getDisplayName()
    {
        return myUI.getDisplayName();
    }

    @Nullable
    @NonNls
    public final String getHelpTopic()
    {
        return myUI.getHelpTopic();
    }

    public final Icon getIcon()
    {
        return myUI.getIcon();
    }

    // From UnnamedConfigurable

    public final void apply() throws ConfigurationException
    {
        myUI.apply();
    }

    public final JComponent createComponent()
    {
        return myUI.createComponent();
    }

    public final void disposeUIResources()
    {
        myUI.disposeUIResources();
    }

    public final boolean isModified()
    {
        return myUI.isModified();
    }

    public final void reset()
    {
        myUI.reset();
    }

    // From FileNameFilter

    public final boolean accept( final File dir, final String name )
    {
        return name.startsWith( CONFIG_FILE_NAME_PREFIX ) && name.endsWith( CONFIG_FILE_NAME_SUFFIX );
    }

    // Implementation

    private synchronized final boolean initialize()
    {
        if ( myInitStatus ) return true;
        try
        {
            final ArrayList<InstanceConfiguration> configurations = loadConfigurations();
            for ( final InstanceConfiguration config : configurations )
            {
                myInstances.add( new SimpleSyntaxInstance( config ) );
            }

            return myInitStatus = true;
        }
        catch ( final Throwable t )
        {
            LOG.error( getComponentName(), t );
            return myInitStatus = false;
        }
    }

    private final ArrayList<InstanceConfiguration>  loadConfigurations()
    {
        final String aConfigFolder = mySystemContext.getConfigurationFolder();
        final String[] fileNames = findConfigFileNames( aConfigFolder );

        final ArrayList<InstanceConfiguration> configurations = new ArrayList<InstanceConfiguration>();
        for ( final String fileName : fileNames )
        {
            final File configFile = new File( aConfigFolder, fileName );
            LOG.info( "Reading configuration file " + configFile.getName() );

            final InstanceConfiguration config = LoadedConfiguration.tryLoading( mySystemContext, configFile.getPath() );
            if ( config == null )
            {
                LOG.error( "Failed reading configuration from " + configFile.toString() );
                continue;
            }
            if ( isAlreadyDefined( config, configurations ) )
            {
                LOG.error( "Ignoring duplicate configuration for " + config.getName() );
                continue;
            }

            LOG.info( "Adding configuration for " + config.getName() );
            configurations.add( config );
        }
        return configurations;
    }

    private final String[] findConfigFileNames( final String aConfigFolderPath )
    {
        LOG.info( "Scanning for SimpleSyntax config files in " + aConfigFolderPath );
        final File configFolder = new File( aConfigFolderPath );
        return configFolder.list( this );
    }

    private final boolean isAlreadyDefined( final InstanceConfiguration aNewConfig, final ArrayList<InstanceConfiguration> aResult )
    {
        for ( final InstanceConfiguration config : aResult )
        {
            if ( aNewConfig.getName().equals( config.getName() ) ) return true;

            final FileTypeConfiguration newFileType = aNewConfig.getFileTypeConfiguration();
            final FileTypeConfiguration oldFileType = config.getFileTypeConfiguration();
            if ( newFileType.getDefaultExtension().equals( oldFileType.getDefaultExtension() ) )
            {
                return true;
            }
        }
        return false;
    }



    private boolean myInitStatus = false;

    private final SystemContext mySystemContext = new ProductionSystemContext();

    private final ArrayList<SimpleSyntaxInstance> myInstances = new ArrayList<SimpleSyntaxInstance>();

    private final SimpleSyntaxUI myUI = new SimpleSyntaxUI( mySystemContext, myInstances );

    private static final Logger LOG = LoggerFactory.getLogger();

    private static final String CONFIG_FILE_NAME_SUFFIX = ".config";

    private static final String CONFIG_FILE_NAME_PREFIX = "simplesyntax_";
}
