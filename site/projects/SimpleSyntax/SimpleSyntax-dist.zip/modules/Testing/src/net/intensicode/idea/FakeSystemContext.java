package net.intensicode.idea;

import com.intellij.openapi.editor.colors.TextAttributesKey;
import com.intellij.openapi.editor.markup.TextAttributes;
import com.intellij.openapi.fileTypes.FileTypeManager;
import net.intensicode.idea.syntax.RecognizedToken;
import net.intensicode.idea.util.FileEx;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import javax.swing.Icon;
import javax.swing.ImageIcon;



/**
 * TODO: Describe this!
 */
public final class FakeSystemContext implements SystemContext, SystemErrorHandler
{
    public FakeSystemContext( final Object aReferenceObject )
    {
        myReferenceObject = aReferenceObject;
    }

    // From SystemContext

    public SystemErrorHandler getErrorHandler()
    {
        return this;
    }

    public TextAttributesKey createTextAttributesKey( String aTokenID, TextAttributes aAttributes )
    {
        throw new RuntimeException( "NYI" );
    }

    public String getConfigurationFolder()
    {
        throw new RuntimeException( "NYI" );
    }

    public FileTypeManager getFileTypeManager()
    {
        throw new RuntimeException( "NYI" );
    }

    public TextAttributes getHighlighterDefaults( String aTokenID )
    {
        throw new RuntimeException( "NYI" );
    }

    public Icon loadIcon( String aIconFileName )
    {
        return new ImageIcon( myReferenceObject.getClass().getResource( aIconFileName ) );
    }

    public byte[] loadFile( String aResourceName ) throws IOException
    {
        return new byte[0];
    }

    public final InputStream streamFile( final String aFileName )
    {
        return null;
    }

    public BufferedReader readFile( String aFileName )
    {
        return new BufferedReader( new InputStreamReader( myReferenceObject.getClass().getResourceAsStream( aFileName ) ) );
    }

    public String readFileIntoString( String aFileName ) throws IOException
    {
        return FileEx.readFileIntoString( readFile( aFileName ) );
    }

    public void copyResource( String aResourceName, String aTargetFolder ) throws IOException
    {
        throw new RuntimeException( "NYI" );
    }

    // From SystemErrorHandler

    public void onTokenRecognizerFailed( RecognizedToken aToken, Throwable aThrowable )
    {
        throw new RuntimeException( aToken.getTokenID(), aThrowable );
    }

    public void onSimpleSyntaxInstallFailed( Throwable aThrowable )
    {
        throw new RuntimeException( "NYI" );
    }

    private final Object myReferenceObject;
}
