
def find_in( segment, start_offset, end_offset )
    return start_offset, end_offset
end
