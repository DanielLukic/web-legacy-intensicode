=begin
    some dox
=end

# comment line
# comment line

class Toast # comment line

    # comment line
    # comment line

    def cheese( args )
        @mogg = args
        schlupp = 'rupp'
        schnuff = "hussle #{hummel}"
    end

    def huzzle
        %Q{ rumsel #{pumsel} }
    end

end
