package net.intensicode.idea.config;

/**
 * TODO: Describe this!
 */
public interface CommentConfiguration
{
    String getLineCommentPrefix();

    String getBlockCommentPrefix();

    String getBlockCommentSuffix();
}
