package net.intensicode.idea.config;

/**
 * TODO: Describe this!
 */
public interface BracesConfiguration
{
    String[] getBracePairs();

    String[] getStructuralPairs();
}
