package net.intensicode.idea.syntax;

/**
 * TODO: Describe this!
 */
interface TokenFinderErrorHandler
{
    void onRecognizerFailed( Throwable aThrowable );
}
