package net.intensicode.idea.core;

/**
 * TODO: Describe this!
 */
public final class Confirmation
{
    public static final Confirmation ALL = new Confirmation();

    public static final Confirmation YES = new Confirmation();

    public static final Confirmation NO = new Confirmation();

    public static final Confirmation CANCEL = new Confirmation();

    // Implementation

    private Confirmation()
    {
    }
}
